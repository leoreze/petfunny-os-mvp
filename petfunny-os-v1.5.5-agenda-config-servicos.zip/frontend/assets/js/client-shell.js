import { getClientUser, clientLogout, requireClientFrontendAuth } from './client-auth.js';
import { finishPageLoading } from './loading.js';

export function buildClientApp({ title = 'Meu PetFunny', subtitle = 'O app do seu pet dentro do PetFunny.', content = '' } = {}) {
  if (!requireClientFrontendAuth()) return;
  const payload = getClientUser();
  const tutor = payload?.tutor || {};
  document.body.innerHTML = `
    <main class="client-app-shell">
      <header class="client-topbar">
        <a class="client-brand" href="/app/home"><span class="client-postit"></span><img src="/assets/img/logo-petfunny-full.png" alt="PetFunny"></a>
        <button class="btn btn-secondary" id="client-logout" type="button">Sair</button>
      </header>
      <section class="client-hero">
        <p class="eyebrow">Aplicativo do cliente</p>
        <h1>${title}</h1>
        <p>${subtitle}</p>
        <div class="client-profile-chip">🐾 ${tutor.name || 'Tutor PetFunny'}</div>
      </section>
      <section class="client-content">${content}</section>
      <footer class="client-footer">© ${new Date().getFullYear()} PetFunny - Banho e Tosa · Ribeirão Preto / SP</footer>
    </main>
  `;
  document.getElementById('client-logout')?.addEventListener('click', clientLogout);
  window.requestAnimationFrame(() => window.setTimeout(() => finishPageLoading(), 320));
}

export function clientCards() {
  return `
    <div class="client-card-grid">
      <article class="client-card"><span>📅</span><h3>Minha agenda</h3><p>Em breve, seus próximos banhos, tosas e check-ins.</p></article>
      <article class="client-card"><span>🐶</span><h3>Meus pets</h3><p>Histórico, preferências, observações e documentos.</p></article>
      <article class="client-card"><span>🎁</span><h3>Mimos</h3><p>Cupons, roleta e benefícios para clientes recorrentes.</p></article>
      <article class="client-card"><span>💬</span><h3>WhatsApp</h3><p>Atalho para falar com a equipe PetFunny.</p></article>
    </div>
  `;
}
