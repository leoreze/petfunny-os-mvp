let loadingTimer = null;
let pageLoadingStarted = false;
let pageLoadingClosed = false;
let trackedFetches = 0;
let idleTimer = null;

const DOG_GIF = '/assets/img/loading-dog.gif';
const LOGO = '/assets/img/logo-petfunny-full.png';

function canShowPageLoader() {
  return typeof window !== 'undefined' && typeof document !== 'undefined' && document.body;
}

function ensureLoading() {
  let el = document.getElementById('safe-loading');
  if (!el) {
    el = document.createElement('div');
    el.id = 'safe-loading';
    el.className = 'page-loading-modal';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    el.innerHTML = `
      <div class="page-loading-card postit-loading-card">
        <span class="postit-tape"></span>
        <div class="page-loading-visual">
          <img class="page-loading-dog" src="${DOG_GIF}" alt="Carregando PetFunny" />
          <img class="page-loading-logo" src="${LOGO}" alt="PetFunny" />
        </div>
        <div class="page-loading-copy">
          <strong id="safe-loading-title">Preparando tudo...</strong>
          <small id="safe-loading-subtitle">Carregando informações do PetFunny.</small>
        </div>
        <div class="page-loading-progress" aria-hidden="true"><span></span></div>
      </div>
    `;
    document.body.appendChild(el);
  }
  return el;
}

function updateLoadingText(message = 'Preparando tudo...', subtitle = 'Carregando informações do PetFunny.') {
  const el = ensureLoading();
  const title = el.querySelector('#safe-loading-title');
  const sub = el.querySelector('#safe-loading-subtitle');
  if (title) title.textContent = message;
  if (sub) sub.textContent = subtitle;
  return el;
}

export function showLoading(message = 'Preparando tudo...', subtitle = 'Operação segura com timeout automático.') {
  const el = updateLoadingText(message, subtitle);
  el.hidden = false;
  el.classList.remove('is-hiding');
  document.body.classList.add('has-page-loading');
  window.clearTimeout(loadingTimer);
  loadingTimer = window.setTimeout(() => hideLoading(), 9000);
}

export function hideLoading() {
  window.clearTimeout(loadingTimer);
  const el = document.getElementById('safe-loading');
  if (!el || el.hidden) return;
  el.classList.add('is-hiding');
  window.setTimeout(() => {
    el.hidden = true;
    el.classList.remove('is-hiding');
    document.body.classList.remove('has-page-loading');
  }, 180);
}

export async function withLoading(callback, message = 'Preparando tudo...') {
  showLoading(message);
  try { return await callback(); }
  finally { hideLoading(); }
}

function safeRequestIdleClose() {
  if (pageLoadingClosed || trackedFetches > 0) return;
  window.clearTimeout(idleTimer);
  idleTimer = window.setTimeout(async () => {
    if (trackedFetches > 0 || pageLoadingClosed) return;
    await waitForPagePaintAndImages();
    finishPageLoading();
  }, 260);
}

async function waitForPagePaintAndImages() {
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  const images = Array.from(document.images || []).filter((img) => !img.complete && typeof img.decode === 'function');
  if (images.length) {
    await Promise.race([
      Promise.allSettled(images.slice(0, 12).map((img) => img.decode())),
      new Promise((resolve) => setTimeout(resolve, 850))
    ]);
  }
}

export function startPageLoading(message = 'Abrindo página...', subtitle = 'Carregando dados e montando a tela.') {
  if (!canShowPageLoader() || pageLoadingClosed || pageLoadingStarted) return;
  pageLoadingStarted = true;
  showLoading(message, subtitle);
  window.setTimeout(() => finishPageLoading(), 11000);
  if (document.readyState === 'complete' || document.readyState === 'interactive') safeRequestIdleClose();
  else document.addEventListener('DOMContentLoaded', safeRequestIdleClose, { once: true });
  window.addEventListener('load', safeRequestIdleClose, { once: true });
}

export function finishPageLoading() {
  if (pageLoadingClosed) return;
  pageLoadingClosed = true;
  window.clearTimeout(idleTimer);
  hideLoading();
}

function patchFetchForPageLoading() {
  if (window.__petfunnyFetchTracked) return;
  window.__petfunnyFetchTracked = true;
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    trackedFetches += 1;
    try {
      return await originalFetch(...args);
    } finally {
      trackedFetches = Math.max(0, trackedFetches - 1);
      safeRequestIdleClose();
    }
  };
}

if (typeof window !== 'undefined') {
  patchFetchForPageLoading();
  window.addEventListener('petfunny:page-ready', finishPageLoading);
  if (document.body) startPageLoading();
  else document.addEventListener('DOMContentLoaded', () => startPageLoading(), { once: true });
}
