export const routes = [
  ['Dashboard', '/dashboard'],
  ['Agenda', '/pages/agenda/'],
  ['Tutores', '/pages/tutores/'],
  ['Pets', '/pages/pets/'],
  ['Serviços', '/pages/servicos/'],
  ['Pacotes', '/pages/pacotes/'],
  ['Assinaturas', '/pages/assinaturas/'],
  ['Financeiro', '/pages/financeiro/'],
  ['CRM & Marketing', '/pages/crm/'],
  ['Roleta de Mimos', '/pages/roleta-de-mimos/'],
  ['Configurações', '/pages/configuracoes/']
];
