import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { env } from './config/env.js';
import { healthcheckDb, query } from './config/db.js';
import { errorMiddleware, notFoundMiddleware } from './middlewares/errorMiddleware.js';
import { requireAuth } from './middlewares/authMiddleware.js';
import { getPetFunnyAiSystemPrompt, getPetFunnyAiPromptMetadata } from './modules/assistente-ia/systemPrompt.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function resolveFrontendRoot() {
  const candidates = [
    process.env.FRONTEND_DIR,
    path.resolve(__dirname, '../../frontend'),
    path.resolve(__dirname, '../../../frontend'),
    path.resolve(process.cwd(), 'frontend'),
    path.resolve(process.cwd(), '../frontend')
  ].filter(Boolean);

  const found = candidates.find((candidate) => {
    try {
      return fs.existsSync(path.resolve(candidate, 'index.html'));
    } catch {
      return false;
    }
  });

  if (!found) {
    console.warn('[frontend] index.html não encontrado. Caminhos testados:');
    candidates.forEach((candidate) => console.warn(`- ${candidate}`));
    return path.resolve(__dirname, '../../../frontend');
  }

  console.log(`[frontend] servindo arquivos de: ${found}`);
  return found;
}

const frontendRoot = resolveFrontendRoot();

function normalizePermissions(value) {
  if (Array.isArray(value)) return value;
  if (!value) return ['full_access'];
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return Array.isArray(parsed) ? parsed : ['full_access'];
  } catch {
    return ['full_access'];
  }
}

async function getBusinessPayload() {
  const result = await query(`
    SELECT business_name, whatsapp, address_city, address_state
    FROM business_settings
    ORDER BY created_at ASC
    LIMIT 1
  `);

  const business = result.rows[0] || {};
  return {
    name: business.business_name || env.petfunnyName,
    city: business.address_city || env.petfunnyCity,
    state: business.address_state || env.petfunnyState,
    whatsapp: business.whatsapp || env.petfunnyWhatsapp
  };
}


function sanitizeSystemNotification(row = {}) {
  return {
    id: row.id,
    type: row.type || 'info',
    priority: row.priority || 'medium',
    title: row.title,
    message: row.message,
    module: row.module,
    actionUrl: row.action_url,
    entityType: row.entity_type,
    entityId: row.entity_id,
    sourceKey: row.source_key,
    read: Boolean(row.is_read),
    readAt: row.read_at,
    createdAt: row.created_at
  };
}

async function upsertSystemNotification({ sourceKey, type = 'info', priority = 'medium', title, message, module = 'dashboard', actionUrl = null, entityType = null, entityId = null }) {
  if (!sourceKey || !title || !message) return null;
  const result = await query(`
    INSERT INTO system_notifications (source_key, type, priority, title, message, module, action_url, entity_type, entity_id)
    VALUES ($1::text, $2::text, $3::text, $4::text, $5::text, $6::text, $7::text, $8::text, NULLIF($9::text,'')::uuid)
    ON CONFLICT (source_key) DO UPDATE SET
      type = EXCLUDED.type,
      priority = EXCLUDED.priority,
      title = EXCLUDED.title,
      message = EXCLUDED.message,
      module = EXCLUDED.module,
      action_url = EXCLUDED.action_url,
      entity_type = EXCLUDED.entity_type,
      entity_id = EXCLUDED.entity_id,
      deleted_at = NULL,
      updated_at = NOW()
    RETURNING *
  `, [sourceKey, type, priority, title, message, module, actionUrl || null, entityType || null, entityId || '']);
  return result.rows[0];
}

async function generateRealtimeNotifications() {
  const overdue = await query(`
    SELECT ft.id, ft.description, ft.amount_cents, ft.due_date, t.name AS tutor_name
    FROM financial_transactions ft
    LEFT JOIN tutors t ON t.id = ft.tutor_id
    WHERE ft.deleted_at IS NULL
      AND ft.type = 'income'
      AND ft.status <> 'paid'
      AND ft.due_date < CURRENT_DATE
    ORDER BY ft.due_date ASC
    LIMIT 20
  `);
  for (const row of overdue.rows) {
    const amount = (Number(row.amount_cents || 0) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    await upsertSystemNotification({
      sourceKey: `financeiro-inadimplente-${row.id}`,
      type: 'warning',
      priority: 'high',
      title: 'Cliente inadimplente',
      message: `${row.tutor_name || 'Cliente'} possui cobrança vencida de ${amount}.`,
      module: 'financeiro',
      actionUrl: '/admin/financeiro?tab=inadimplentes',
      entityType: 'financial_transaction',
      entityId: row.id
    });
  }

  const todayOpen = await query(`
    SELECT COUNT(*)::int AS total
    FROM appointments a
    INNER JOIN appointment_statuses s ON s.code = a.status AND s.blocks_slot = TRUE
    WHERE a.deleted_at IS NULL
      AND a.starts_at::date = CURRENT_DATE
  `);
  if (Number(todayOpen.rows[0]?.total || 0) > 0) {
    await upsertSystemNotification({
      sourceKey: `agenda-confirmacao-${new Date().toISOString().slice(0,10)}`,
      type: 'info',
      priority: 'medium',
      title: 'Confirmar agenda do dia',
      message: `Há ${todayOpen.rows[0].total} atendimento(s) ativos hoje. Vale confirmar presença pelo WhatsApp.`,
      module: 'agenda',
      actionUrl: '/admin/agenda'
    });
  }

  const packages = await query(`
    SELECT cp.id, t.name AS tutor_name, p.name AS pet_name, cp.total_sessions, cp.used_sessions
    FROM customer_packages cp
    LEFT JOIN tutors t ON t.id = cp.tutor_id
    LEFT JOIN pets p ON p.id = cp.pet_id
    WHERE cp.deleted_at IS NULL
      AND cp.status = 'active'
      AND (cp.total_sessions - cp.used_sessions) <= 1
    ORDER BY cp.updated_at DESC
    LIMIT 20
  `);
  for (const row of packages.rows) {
    await upsertSystemNotification({
      sourceKey: `pacote-renovacao-${row.id}`,
      type: 'opportunity',
      priority: 'medium',
      title: 'Pacote perto do fim',
      message: `${row.pet_name || 'Pet'} de ${row.tutor_name || 'tutor'} tem ${Number(row.total_sessions || 0) - Number(row.used_sessions || 0)} sessão restante.`,
      module: 'pacotes',
      actionUrl: '/admin/pacotes',
      entityType: 'customer_package',
      entityId: row.id
    });
  }
}

function normalizeWhatsapp(value = '') {
  const digits = String(value || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 11) return `55${digits}`;
  if (digits.length === 13 && digits.startsWith('55')) return digits;
  if (digits.length === 12 && digits.startsWith('55')) return digits;
  return digits;
}

function sanitizeTutor(tutor = {}) {
  return {
    id: tutor.id,
    name: tutor.name,
    whatsapp: tutor.whatsapp,
    email: tutor.email,
    city: tutor.city,
    state: tutor.state,
    photoUrl: tutor.photo_url || tutor.photoUrl || null,
    tags: tutor.tags || []
  };
}

function makeSixDigitCode() {
  if (env.nodeEnv !== 'production') return '123456';
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function getClientAppPayload(accountId) {
  const result = await query(`
    SELECT ca.id AS account_id, ca.status, ca.is_active, ca.whatsapp,
           t.id AS tutor_id, t.name, t.email, t.city, t.state, t.tags
    FROM client_accounts ca
    INNER JOIN tutors t ON t.id = ca.tutor_id
    WHERE ca.id = $1
      AND ca.deleted_at IS NULL
      AND t.deleted_at IS NULL
    LIMIT 1
  `, [accountId]);

  const row = result.rows[0];
  if (!row || !row.is_active) return null;
  return {
    account: {
      id: row.account_id,
      status: row.status,
      whatsapp: row.whatsapp
    },
    tutor: sanitizeTutor(row)
  };
}

async function requireClientAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice('Bearer '.length).trim() : '';
    if (!token) return res.status(401).json({ error: 'Token do aplicativo ausente.' });

    let payload;
    try {
      payload = jwt.verify(token, env.jwtSecret);
    } catch {
      return res.status(401).json({ error: 'Token do aplicativo inválido ou expirado.' });
    }

    if (payload.scope !== 'client_app') {
      return res.status(401).json({ error: 'Token não pertence ao aplicativo do cliente.' });
    }

    const appUser = await getClientAppPayload(payload.sub);
    if (!appUser) return res.status(401).json({ error: 'Conta do aplicativo inativa ou não encontrada.' });

    req.clientApp = appUser;
    next();
  } catch (error) {
    next(error);
  }
}

function sanitizeUser(user, business) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    permissions: normalizePermissions(user.permissions),
    business
  };
}

async function getDashboardSummary() {
  const metricsResult = await query(`
    WITH today_appointments AS (
      SELECT * FROM appointments
      WHERE starts_at::date = CURRENT_DATE
        AND deleted_at IS NULL
    ), week_appointments AS (
      SELECT * FROM appointments
      WHERE starts_at >= date_trunc('week', NOW())
        AND starts_at < date_trunc('week', NOW()) + INTERVAL '7 days'
        AND deleted_at IS NULL
    ), pending_financial AS (
      SELECT COALESCE(SUM(amount_cents), 0) AS total, COUNT(*) AS count
      FROM financial_transactions
      WHERE type = 'income'
        AND status <> 'paid'
        AND deleted_at IS NULL
    ), revenue_today AS (
      SELECT COALESCE(SUM(amount_cents), 0) AS total
      FROM payments
      WHERE paid_at::date = CURRENT_DATE
    ), revenue_week AS (
      SELECT COALESCE(SUM(amount_cents), 0) AS total
      FROM payments
      WHERE paid_at >= date_trunc('week', NOW())
        AND paid_at < date_trunc('week', NOW()) + INTERVAL '7 days'
    )
    SELECT
      (SELECT COUNT(*) FROM today_appointments) AS appointments_today,
      (SELECT COUNT(*) FROM today_appointments WHERE status = 'em_atendimento') AS active_checkins,
      (SELECT COUNT(*) FROM today_appointments WHERE status = 'finalizado') AS finished_today,
      (SELECT COUNT(DISTINCT pet_id) FROM today_appointments WHERE status IN ('em_atendimento','finalizado') AND pet_id IS NOT NULL) AS pets_served_today,
      (SELECT COUNT(*) FROM week_appointments) AS appointments_week,
      (SELECT total FROM pending_financial) AS pending_payments_total_cents,
      (SELECT count FROM pending_financial) AS pending_payments_count,
      (SELECT total FROM revenue_today) AS revenue_today_cents,
      (SELECT total FROM revenue_week) AS revenue_week_cents,
      (SELECT COUNT(*) FROM tutors WHERE deleted_at IS NULL) AS tutors_total,
      (SELECT COUNT(*) FROM pets WHERE deleted_at IS NULL) AS pets_total,
      (SELECT COUNT(*) FROM customer_packages WHERE status = 'active' AND deleted_at IS NULL) AS active_packages,
      (SELECT COUNT(*) FROM tutors WHERE deleted_at IS NULL AND ('recorrente' = ANY(tags) OR id IN (SELECT tutor_id FROM customer_packages WHERE status = 'active' AND deleted_at IS NULL))) AS recurring_clients,
      (SELECT COUNT(*) FROM gifts WHERE status = 'active' AND deleted_at IS NULL) AS active_gifts
  `);

  const agendaResult = await query(`
    SELECT a.id,
           a.starts_at,
           a.ends_at,
           a.status,
           a.total_cents,
           a.discount_percent,
           a.package_session_label,
           a.notes,
           t.name AS tutor_name,
           t.whatsapp AS tutor_whatsapp,
           p.name AS pet_name,
           p.size AS pet_size,
           c.name AS collaborator_name,
           COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services
    FROM appointments a
    LEFT JOIN tutors t ON t.id = a.tutor_id
    LEFT JOIN pets p ON p.id = a.pet_id
    LEFT JOIN collaborators c ON c.id = a.collaborator_id
    LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
    WHERE a.starts_at::date = CURRENT_DATE
      AND a.deleted_at IS NULL
    GROUP BY a.id, t.name, t.whatsapp, p.name, p.size, c.name
    ORDER BY a.starts_at ASC
    LIMIT 16
  `);

  const statusResult = await query(`
    SELECT s.code AS status,
           s.name AS label,
           s.color,
           s.sort_order,
           COALESCE(COUNT(a.id), 0)::int AS total
    FROM appointment_statuses s
    LEFT JOIN appointments a ON a.status = s.code
      AND a.starts_at::date = CURRENT_DATE
      AND a.deleted_at IS NULL
    WHERE s.deleted_at IS NULL
      AND s.is_active = TRUE
    GROUP BY s.code, s.name, s.color, s.sort_order
    ORDER BY s.sort_order ASC, s.name ASC
  `);

  const upcomingResult = await query(`
    SELECT a.id, a.starts_at, a.status, t.name AS tutor_name, p.name AS pet_name, COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services
    FROM appointments a
    LEFT JOIN tutors t ON t.id = a.tutor_id
    LEFT JOIN pets p ON p.id = a.pet_id
    LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
    WHERE a.starts_at > NOW()
      AND a.starts_at < NOW() + INTERVAL '7 days'
      AND a.deleted_at IS NULL
      AND a.status NOT IN ('cancelado','finalizado','nao_compareceu')
    GROUP BY a.id, t.name, p.name
    ORDER BY a.starts_at ASC
    LIMIT 8
  `);

  const row = metricsResult.rows[0] || {};
  const n = (value) => Number(value || 0);
  const money = (value) => n(value);
  const appointmentStatus = Object.fromEntries(statusResult.rows.map((item) => [item.status, n(item.total)]));

  const alerts = [];
  if (n(row.pending_payments_count) > 0) {
    alerts.push({ type: 'warning', title: 'Recebimentos pendentes', message: `${n(row.pending_payments_count)} cobrança(s) aguardando baixa no financeiro.` });
  }
  if (n(row.appointments_today) === 0) {
    alerts.push({ type: 'info', title: 'Agenda livre hoje', message: 'Nenhum atendimento agendado para hoje. Use CRM e WhatsApp para reativar clientes.' });
  }
  if (n(row.active_checkins) > 0) {
    alerts.push({ type: 'success', title: 'Atendimentos em andamento', message: `${n(row.active_checkins)} pet(s) estão em atendimento agora.` });
  }
  if (!alerts.length) {
    alerts.push({ type: 'success', title: 'Operação estável', message: 'Nenhum alerta crítico identificado para o dia.' });
  }

  const insights = [
    n(row.appointments_today) > 0
      ? `Hoje existem ${n(row.appointments_today)} agendamento(s). Priorize confirmação pelo WhatsApp antes dos horários de pico.`
      : 'A agenda de hoje está vazia. Vale disparar mensagem para clientes recorrentes e pacotes ativos.',
    money(row.revenue_today_cents) > 0
      ? `Faturamento registrado hoje: ${money(row.revenue_today_cents)} centavos em pagamentos baixados.`
      : 'Ainda não há pagamento baixado hoje. O dashboard não depende de IA nem API externa para carregar.',
    n(row.active_packages) > 0
      ? `${n(row.active_packages)} pacote(s) ativo(s). Acompanhe uso de sessões para evitar perda de recorrência.`
      : 'Nenhum pacote ativo encontrado. Pacotes entram como alavanca de recorrência nas próximas versões.'
  ];

  return {
    metrics: {
      appointmentsToday: n(row.appointments_today),
      appointmentsWeek: n(row.appointments_week),
      activeCheckins: n(row.active_checkins),
      finishedToday: n(row.finished_today),
      petsServedToday: n(row.pets_served_today),
      pendingPaymentsTotalCents: money(row.pending_payments_total_cents),
      pendingPaymentsCount: n(row.pending_payments_count),
      revenueTodayCents: money(row.revenue_today_cents),
      revenueWeekCents: money(row.revenue_week_cents),
      tutorsTotal: n(row.tutors_total),
      petsTotal: n(row.pets_total),
      activePackages: n(row.active_packages),
      recurringClients: n(row.recurring_clients),
      activeGifts: n(row.active_gifts)
    },
    agendaToday: agendaResult.rows.map((item) => ({
      id: item.id,
      startsAt: item.starts_at,
      endsAt: item.ends_at,
      status: item.status,
      tutorName: item.tutor_name || 'Tutor não informado',
      tutorWhatsapp: item.tutor_whatsapp || '',
      petName: item.pet_name || 'Pet não informado',
      petSize: item.pet_size || '',
      collaboratorName: item.collaborator_name || 'Equipe PetFunny',
      services: item.services || 'Serviço não informado',
      totalCents: n(item.total_cents),
      discountPercent: Number(item.discount_percent || 0),
      packageSessionLabel: item.package_session_label,
      notes: item.notes
    })),
    upcomingAppointments: upcomingResult.rows.map((item) => ({
      id: item.id,
      startsAt: item.starts_at,
      status: item.status,
      tutorName: item.tutor_name || 'Tutor não informado',
      petName: item.pet_name || 'Pet não informado',
      services: item.services || 'Serviço não informado'
    })),
    appointmentStatuses: statusResult.rows.map((item) => ({ code: item.status, name: item.label, color: item.color, total: n(item.total) })),
    statusBreakdown: appointmentStatus,
    alerts,
    insights,
    source: 'postgresql',
    generatedAt: new Date().toISOString()
  };
}

function sendFrontendFile(res, relativePath) {
  const filePath = path.resolve(frontendRoot, relativePath);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'Arquivo de frontend não encontrado.',
      file: relativePath,
      frontendRoot
    });
  }
  return res.sendFile(filePath);
}

const app = express();
app.disable('etag');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '8mb' }));
app.use(express.urlencoded({ extended: true, limit: '8mb' }));

app.use('/api', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    const startedAt = Date.now();
    res.on('finish', () => {
      console.log(`[api] ${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - startedAt}ms`);
    });
  }
  next();
});

app.get('/api/health', async (req, res) => {
  const database = await healthcheckDb();
  res.json({
    status: 'ok',
    service: 'PetFunny OS API',
    mode: env.appMode,
    tenant: false,
    database,
    frontend: {
      root: frontendRoot,
      available: fs.existsSync(path.resolve(frontendRoot, 'index.html'))
    },
    business: {
      name: env.petfunnyName,
      city: env.petfunnyCity,
      state: env.petfunnyState,
      whatsapp: env.petfunnyWhatsapp
    },
    timestamp: new Date().toISOString()
  });
});


app.post('/api/auth/login', async (req, res, next) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    if (!email || !password) {
      return res.status(400).json({ error: 'Informe email e senha.' });
    }

    const result = await query(`
      SELECT id, name, email, password_hash, role, permissions, is_active
      FROM users
      WHERE lower(email) = lower($1)
        AND deleted_at IS NULL
      LIMIT 1
    `, [email]);

    const user = result.rows[0];
    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'Email ou senha inválidos.' });
    }

    const passwordOk = await bcrypt.compare(password, user.password_hash);
    if (!passwordOk) {
      return res.status(401).json({ error: 'Email ou senha inválidos.' });
    }

    await query('UPDATE users SET last_login_at = NOW(), updated_at = NOW() WHERE id = $1', [user.id]);

    const token = jwt.sign(
      { sub: user.id, email: user.email, role: user.role, mode: env.appMode, tenant: false },
      env.jwtSecret,
      { expiresIn: env.jwtExpiresIn }
    );

    const business = await getBusinessPayload();
    res.json({
      token,
      tokenType: 'Bearer',
      expiresIn: env.jwtExpiresIn,
      user: sanitizeUser(user, business)
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/auth/me', requireAuth, async (req, res, next) => {
  try {
    const business = await getBusinessPayload();
    res.json({ user: { ...req.user, business } });
  } catch (error) {
    next(error);
  }
});

app.post('/api/auth/logout', requireAuth, async (req, res) => {
  res.json({ ok: true, message: 'Sessão encerrada no cliente.' });
});


function parseLimit(value, fallback = 20, max = 100) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return Math.min(n, max);
}

function parseOffset(page, limit) {
  const n = Number.parseInt(page, 10);
  if (!Number.isFinite(n) || n <= 1) return 0;
  return (n - 1) * limit;
}

function parseTags(value) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function cleanText(value) {
  const text = String(value || '').trim();
  return text || null;
}

function cleanJsonObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return value;
}

function cleanPhotoDataUrl(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  if (text.startsWith('/assets/') || text.startsWith('http://') || text.startsWith('https://')) return text.slice(0, 900000);
  const ok = /^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(text);
  if (!ok) return null;
  // limite aproximado de 700 KB para manter o banco leve nesta fase sem storage externo
  if (text.length > 950000) throw new Error('A foto deve ter até aproximadamente 700 KB. Use uma imagem menor.');
  return text;
}

function parseBool(value, fallback = true) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  return ['true', '1', 'yes', 'sim', 'active', 'ativo'].includes(String(value).toLowerCase());
}

function normalizeCode(value = '') {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 48);
}

function sanitizeBusiness(row = {}) {
  const social = cleanJsonObject(row.social_links);
  const seo = cleanJsonObject(row.seo_settings);
  return {
    id: row.id,
    businessName: row.business_name,
    legalName: row.legal_name,
    documentNumber: row.document_number,
    whatsapp: row.whatsapp,
    phone: row.phone,
    email: row.email,
    addressStreet: row.address_street,
    addressNumber: row.address_number,
    addressNeighborhood: row.address_neighborhood,
    addressCity: row.address_city,
    addressState: row.address_state,
    addressZipcode: row.address_zipcode,
    websiteUrl: row.website_url,
    instagramUrl: row.instagram_url || social.instagram || '',
    facebookUrl: row.facebook_url || social.facebook || '',
    tiktokUrl: row.tiktok_url || social.tiktok || '',
    googleBusinessUrl: row.google_business_url || social.googleBusiness || '',
    mapsUrl: row.maps_url || social.maps || '',
    seoTitle: row.seo_title || seo.title || '',
    seoDescription: row.seo_description || seo.description || '',
    seoKeywords: row.seo_keywords || seo.keywords || '',
    seoImageUrl: row.seo_image_url || seo.imageUrl || '',
    landingHeadline: row.landing_headline,
    landingSubheadline: row.landing_subheadline,
    theme: cleanJsonObject(row.theme),
    documentPreferences: cleanJsonObject(row.document_preferences),
    updatedAt: row.updated_at
  };
}

async function getBusinessSettingsRow() {
  const result = await query('SELECT * FROM business_settings ORDER BY created_at ASC LIMIT 1');
  return result.rows[0] || null;
}

function sanitizePetType(row = {}) {
  return { id: row.id, code: row.code, name: row.name, description: row.description, sortOrder: Number(row.sort_order || 0), isActive: Boolean(row.is_active) };
}
function sanitizePetSize(row = {}) {
  return { id: row.id, code: row.code, name: row.name, description: row.description, minWeightKg: row.min_weight_kg === null ? null : Number(row.min_weight_kg), maxWeightKg: row.max_weight_kg === null ? null : Number(row.max_weight_kg), sortOrder: Number(row.sort_order || 0), isActive: Boolean(row.is_active) };
}
function sanitizePetBreed(row = {}) {
  return { id: row.id, petTypeId: row.pet_type_id, petTypeName: row.pet_type_name, petTypeCode: row.pet_type_code, name: row.name, suggestedSizeCode: row.suggested_size_code, coatType: row.coat_type, sortOrder: Number(row.sort_order || 0), isActive: Boolean(row.is_active) };
}


function sanitizeServiceType(row = {}) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    petTypeCode: row.pet_type_code || null,
    petTypeName: row.pet_type_name || null,
    petSizeCode: row.pet_size_code || null,
    petSizeName: row.pet_size_name || null,
    sortOrder: Number(row.sort_order || 0),
    isActive: Boolean(row.is_active)
  };
}

function sanitizeAppointmentStatus(row = {}) {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description,
    color: row.color || '#00A9B7',
    sortOrder: Number(row.sort_order || 0),
    isActive: Boolean(row.is_active),
    isFinal: Boolean(row.is_final),
    blocksSlot: Boolean(row.blocks_slot)
  };
}

function sanitizePaymentStatus(row = {}) {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description,
    color: row.color || '#00A9B7',
    sortOrder: Number(row.sort_order || 0),
    isActive: Boolean(row.is_active)
  };
}

function sanitizePaymentMethod(row = {}) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    sortOrder: Number(row.sort_order || 0),
    isActive: Boolean(row.is_active)
  };
}

function weekdayName(value) {
  return ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'][Number(value)] || 'Dia';
}

function cleanTime(value, fallback = null) {
  const text = String(value || '').trim();
  if (!text) return fallback;
  const match = text.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (!match) return fallback;
  const hh = Math.max(0, Math.min(23, Number(match[1])));
  const mm = Math.max(0, Math.min(59, Number(match[2])));
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:00`;
}

function normalizeHour(value) {
  const time = cleanTime(value, null);
  if (!time) return null;
  return `${time.slice(0, 2)}:00:00`;
}

function sanitizeBusinessHour(row = {}) {
  return {
    id: row.id,
    weekday: Number(row.weekday),
    weekdayName: weekdayName(row.weekday),
    opensAt: row.opens_at ? String(row.opens_at).slice(0, 5) : '',
    closesAt: row.closes_at ? String(row.closes_at).slice(0, 5) : '',
    isOpen: Boolean(row.is_open)
  };
}

function sanitizeTimeSlot(row = {}) {
  return {
    id: row.id,
    weekday: Number(row.weekday),
    weekdayName: weekdayName(row.weekday),
    slotTime: row.slot_time ? String(row.slot_time).slice(0, 5) : '',
    capacity: Number(row.capacity || 0)
  };
}

async function getOperationalSettingsPayload() {
  const serviceTypes = await query(`
    SELECT sc.*, pt.name AS pet_type_name, ps.name AS pet_size_name
    FROM service_categories sc
    LEFT JOIN pet_types pt ON pt.code = sc.pet_type_code
    LEFT JOIN pet_sizes ps ON ps.code = sc.pet_size_code
    WHERE sc.deleted_at IS NULL
    ORDER BY sc.sort_order ASC, sc.name ASC
  `);
  const appointmentStatuses = await query(`SELECT * FROM appointment_statuses WHERE deleted_at IS NULL ORDER BY sort_order ASC, name ASC`);
  const paymentStatuses = await query(`SELECT * FROM payment_statuses WHERE deleted_at IS NULL ORDER BY sort_order ASC, name ASC`);
  const paymentMethods = await query(`SELECT * FROM payment_methods WHERE deleted_at IS NULL ORDER BY sort_order ASC, name ASC`);
  const hours = await query(`SELECT * FROM business_hours ORDER BY weekday ASC`);
  const slots = await query(`
    SELECT tsc.*
    FROM time_slot_capacities tsc
    INNER JOIN business_hours bh ON bh.weekday = tsc.weekday
    WHERE bh.is_open = TRUE
      AND tsc.slot_time >= bh.opens_at
      AND tsc.slot_time < bh.closes_at
      AND EXTRACT(MINUTE FROM tsc.slot_time)::int = 0
    ORDER BY tsc.weekday ASC, tsc.slot_time ASC
  `);
  return {
    serviceTypes: serviceTypes.rows.map(sanitizeServiceType),
    appointmentStatuses: appointmentStatuses.rows.map(sanitizeAppointmentStatus),
    paymentStatuses: paymentStatuses.rows.map(sanitizePaymentStatus),
    paymentMethods: paymentMethods.rows.map(sanitizePaymentMethod),
    businessHours: hours.rows.map(sanitizeBusinessHour),
    timeSlotCapacities: slots.rows.map(sanitizeTimeSlot),
    slotPolicy: { intervalMinutes: 60, unit: 'hour', description: 'Limite de agendamentos por hora e por dia da semana.' }
  };
}

async function getPetOptionsPayload({ activeOnly = false } = {}) {
  const activeClause = activeOnly ? 'WHERE is_active = TRUE' : '';
  const types = await query(`SELECT * FROM pet_types ${activeClause} ORDER BY sort_order ASC, name ASC`);
  const sizes = await query(`SELECT * FROM pet_sizes ${activeClause} ORDER BY sort_order ASC, name ASC`);
  const breeds = await query(`
    SELECT b.*, pt.name AS pet_type_name, pt.code AS pet_type_code
    FROM pet_breeds b
    LEFT JOIN pet_types pt ON pt.id = b.pet_type_id
    ${activeOnly ? 'WHERE b.is_active = TRUE' : ''}
    ORDER BY COALESCE(pt.sort_order, 999), b.sort_order ASC, b.name ASC
  `);
  return { types: types.rows.map(sanitizePetType), sizes: sizes.rows.map(sanitizePetSize), breeds: breeds.rows.map(sanitizePetBreed) };
}

function sanitizePet(pet = {}) {
  return {
    id: pet.id,
    tutorId: pet.tutor_id,
    tutorName: pet.tutor_name,
    tutorWhatsapp: pet.tutor_whatsapp,
    name: pet.name,
    photoUrl: pet.photo_url || pet.photoUrl || null,
    species: pet.species,
    breed: pet.breed,
    size: pet.size,
    coatType: pet.coat_type,
    birthDate: pet.birth_date,
    weightKg: pet.weight_kg === null || pet.weight_kg === undefined ? null : Number(pet.weight_kg),
    preferences: pet.preferences,
    restrictions: pet.restrictions,
    notes: pet.notes,
    status: pet.status,
    createdAt: pet.created_at,
    updatedAt: pet.updated_at
  };
}

async function getTutorById(id) {
  const result = await query(`
    SELECT t.*,
           COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL)::int AS pets_count,
           COALESCE(MAX(a.starts_at), NULL) AS last_appointment_at
    FROM tutors t
    LEFT JOIN pets p ON p.tutor_id = t.id AND p.deleted_at IS NULL
    LEFT JOIN appointments a ON a.tutor_id = t.id AND a.deleted_at IS NULL
    WHERE t.id = $1
      AND t.deleted_at IS NULL
    GROUP BY t.id
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}

async function getPetById(id) {
  const result = await query(`
    SELECT p.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp
    FROM pets p
    INNER JOIN tutors t ON t.id = p.tutor_id AND t.deleted_at IS NULL
    WHERE p.id = $1
      AND p.deleted_at IS NULL
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}


app.get('/api/public/site', async (req, res, next) => {
  try {
    const business = await getBusinessSettingsRow();
    if (!business) return res.status(404).json({ error: 'Configurações da loja não encontradas.' });
    const payload = sanitizeBusiness(business);
    res.json({
      business: payload,
      seo: {
        title: payload.seoTitle || `${payload.businessName} em ${payload.addressCity} · Banho e Tosa`,
        description: payload.seoDescription || 'Banho e tosa com carinho, agenda prática e atendimento pelo WhatsApp.',
        keywords: payload.seoKeywords || 'banho e tosa, pet shop, Ribeirão Preto, PetFunny',
        imageUrl: payload.seoImageUrl || '/assets/img/logo-petfunny-full.png'
      },
      generatedAt: new Date().toISOString()
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/configuracoes', requireAuth, async (req, res, next) => {
  try {
    const business = await getBusinessSettingsRow();
    const petOptions = await getPetOptionsPayload();
    const operational = await getOperationalSettingsPayload();
    res.json({ business: business ? sanitizeBusiness(business) : null, petOptions, operational });
  } catch (error) {
    next(error);
  }
});

app.put('/api/configuracoes/business', requireAuth, async (req, res, next) => {
  try {
    const body = req.body || {};
    const socialLinks = {
      instagram: cleanText(body.instagramUrl),
      facebook: cleanText(body.facebookUrl),
      tiktok: cleanText(body.tiktokUrl),
      googleBusiness: cleanText(body.googleBusinessUrl),
      maps: cleanText(body.mapsUrl)
    };
    const seoSettings = {
      title: cleanText(body.seoTitle),
      description: cleanText(body.seoDescription),
      keywords: cleanText(body.seoKeywords),
      imageUrl: cleanText(body.seoImageUrl)
    };

    const result = await query(`
      UPDATE business_settings
      SET business_name = COALESCE($1::text, business_name),
          legal_name = $2::text,
          document_number = $3::text,
          whatsapp = COALESCE($4::text, whatsapp),
          phone = $5::text,
          email = $6::text,
          address_street = $7::text,
          address_number = $8::text,
          address_neighborhood = $9::text,
          address_city = COALESCE($10::text, address_city),
          address_state = COALESCE($11::text, address_state),
          address_zipcode = $12::text,
          website_url = $13::text,
          instagram_url = $14::text,
          facebook_url = $15::text,
          tiktok_url = $16::text,
          google_business_url = $17::text,
          maps_url = $18::text,
          social_links = $19::jsonb,
          seo_title = $20::text,
          seo_description = $21::text,
          seo_keywords = $22::text,
          seo_image_url = $23::text,
          seo_settings = $24::jsonb,
          landing_headline = $25::text,
          landing_subheadline = $26::text,
          updated_at = NOW()
      WHERE id = (SELECT id FROM business_settings ORDER BY created_at ASC LIMIT 1)
      RETURNING *
    `, [
      cleanText(body.businessName), cleanText(body.legalName), cleanText(body.documentNumber), normalizeWhatsapp(body.whatsapp), cleanText(body.phone), cleanText(body.email),
      cleanText(body.addressStreet), cleanText(body.addressNumber), cleanText(body.addressNeighborhood), cleanText(body.addressCity), cleanText(body.addressState), cleanText(body.addressZipcode),
      cleanText(body.websiteUrl), cleanText(body.instagramUrl), cleanText(body.facebookUrl), cleanText(body.tiktokUrl), cleanText(body.googleBusinessUrl), cleanText(body.mapsUrl), JSON.stringify(socialLinks),
      cleanText(body.seoTitle), cleanText(body.seoDescription), cleanText(body.seoKeywords), cleanText(body.seoImageUrl), JSON.stringify(seoSettings), cleanText(body.landingHeadline), cleanText(body.landingSubheadline)
    ]);

    if (!result.rows[0]) return res.status(404).json({ error: 'Configurações do comércio não encontradas.' });
    await query('INSERT INTO audit_logs (user_id, action, entity, entity_id, metadata) VALUES ($1, $2, $3, $4, $5::jsonb)', [req.user.id, 'config.business.update', 'business_settings', result.rows[0].id, JSON.stringify({ source: 'admin' })]);
    res.json({ business: sanitizeBusiness(result.rows[0]) });
  } catch (error) {
    next(error);
  }
});


app.get('/api/configuracoes/operational', requireAuth, async (req, res, next) => {
  try {
    res.json(await getOperationalSettingsPayload());
  } catch (error) { next(error); }
});

app.post('/api/configuracoes/service-types', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tipo de serviço.' });
    const result = await query(`
      INSERT INTO service_categories (name, description, sort_order, is_active, pet_type_code, pet_size_code)
      VALUES ($1::text, $2::text, $3::integer, $4::boolean, NULLIF($5::text, ''), NULLIF($6::text, ''))
      ON CONFLICT (name) DO UPDATE
      SET description = EXCLUDED.description,
          sort_order = EXCLUDED.sort_order,
          is_active = EXCLUDED.is_active,
          pet_type_code = EXCLUDED.pet_type_code,
          pet_size_code = EXCLUDED.pet_size_code,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    res.status(201).json({ serviceType: sanitizeServiceType(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/service-types/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tipo de serviço.' });
    const result = await query(`
      UPDATE service_categories
      SET name = $1::text,
          description = $2::text,
          sort_order = $3::integer,
          is_active = $4::boolean,
          pet_type_code = NULLIF($5::text, ''),
          pet_size_code = NULLIF($6::text, ''),
          updated_at = NOW()
      WHERE id = $7::uuid
        AND deleted_at IS NULL
      RETURNING *
    `, [name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Tipo de serviço não encontrado.' });
    res.json({ serviceType: sanitizeServiceType(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/service-types/:id', requireAuth, async (req, res, next) => {
  try {
    await query('UPDATE service_categories SET is_active = FALSE, deleted_at = NOW(), updated_at = NOW() WHERE id = $1::uuid', [req.params.id]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});


app.post('/api/configuracoes/appointment-statuses', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const code = normalizeCode(req.body?.code || name);
    if (!name || !code) return res.status(400).json({ error: 'Informe o nome e o código do status da agenda.' });
    const result = await query(`
      INSERT INTO appointment_statuses (code, name, description, color, sort_order, is_active, is_final, blocks_slot)
      VALUES ($1::text, $2::text, $3::text, $4::text, $5::integer, $6::boolean, $7::boolean, $8::boolean)
      ON CONFLICT (code) DO UPDATE
      SET name = EXCLUDED.name,
          description = EXCLUDED.description,
          color = EXCLUDED.color,
          sort_order = EXCLUDED.sort_order,
          is_active = EXCLUDED.is_active,
          is_final = EXCLUDED.is_final,
          blocks_slot = EXCLUDED.blocks_slot,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [code, name, cleanText(req.body?.description), cleanText(req.body?.color) || '#00A9B7', Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), parseBool(req.body?.isFinal, false), parseBool(req.body?.blocksSlot, true)]);
    res.status(201).json({ appointmentStatus: sanitizeAppointmentStatus(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/appointment-statuses/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const code = normalizeCode(req.body?.code || name);
    if (!name || !code) return res.status(400).json({ error: 'Informe o nome e o código do status da agenda.' });
    const result = await query(`
      UPDATE appointment_statuses
      SET code = $1::text,
          name = $2::text,
          description = $3::text,
          color = $4::text,
          sort_order = $5::integer,
          is_active = $6::boolean,
          is_final = $7::boolean,
          blocks_slot = $8::boolean,
          updated_at = NOW()
      WHERE id = $9::uuid
        AND deleted_at IS NULL
      RETURNING *
    `, [code, name, cleanText(req.body?.description), cleanText(req.body?.color) || '#00A9B7', Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), parseBool(req.body?.isFinal, false), parseBool(req.body?.blocksSlot, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Status da agenda não encontrado.' });
    res.json({ appointmentStatus: sanitizeAppointmentStatus(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/appointment-statuses/:id', requireAuth, async (req, res, next) => {
  try {
    await query('UPDATE appointment_statuses SET is_active = FALSE, deleted_at = NOW(), updated_at = NOW() WHERE id = $1::uuid', [req.params.id]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});


app.post('/api/configuracoes/payment-statuses', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const code = normalizeCode(req.body?.code || name);
    if (!name || !code) return res.status(400).json({ error: 'Informe o nome e o código do status de pagamento.' });
    const result = await query(`
      INSERT INTO payment_statuses (code, name, description, color, sort_order, is_active)
      VALUES ($1::text, $2::text, $3::text, $4::text, $5::integer, $6::boolean)
      ON CONFLICT (code) DO UPDATE
      SET name = EXCLUDED.name,
          description = EXCLUDED.description,
          color = EXCLUDED.color,
          sort_order = EXCLUDED.sort_order,
          is_active = EXCLUDED.is_active,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [code, name, cleanText(req.body?.description), cleanText(req.body?.color) || '#00A9B7', Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    res.status(201).json({ paymentStatus: sanitizePaymentStatus(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/payment-statuses/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const code = normalizeCode(req.body?.code || name);
    if (!name || !code) return res.status(400).json({ error: 'Informe o nome e o código do status de pagamento.' });
    const result = await query(`
      UPDATE payment_statuses
      SET code = $1::text,
          name = $2::text,
          description = $3::text,
          color = $4::text,
          sort_order = $5::integer,
          is_active = $6::boolean,
          updated_at = NOW()
      WHERE id = $7::uuid
        AND deleted_at IS NULL
      RETURNING *
    `, [code, name, cleanText(req.body?.description), cleanText(req.body?.color) || '#00A9B7', Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Status de pagamento não encontrado.' });
    res.json({ paymentStatus: sanitizePaymentStatus(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/payment-statuses/:id', requireAuth, async (req, res, next) => {
  try {
    await query('UPDATE payment_statuses SET is_active = FALSE, deleted_at = NOW(), updated_at = NOW() WHERE id = $1::uuid', [req.params.id]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/configuracoes/payment-methods', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome da forma de pagamento.' });
    const result = await query(`
      INSERT INTO payment_methods (name, description, sort_order, is_active)
      VALUES ($1::text, $2::text, $3::integer, $4::boolean)
      ON CONFLICT (name) DO UPDATE
      SET description = EXCLUDED.description,
          sort_order = EXCLUDED.sort_order,
          is_active = EXCLUDED.is_active,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    res.status(201).json({ paymentMethod: sanitizePaymentMethod(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/payment-methods/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome da forma de pagamento.' });
    const result = await query(`
      UPDATE payment_methods
      SET name = $1::text,
          description = $2::text,
          sort_order = $3::integer,
          is_active = $4::boolean,
          updated_at = NOW()
      WHERE id = $5::uuid
        AND deleted_at IS NULL
      RETURNING *
    `, [name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Forma de pagamento não encontrada.' });
    res.json({ paymentMethod: sanitizePaymentMethod(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/payment-methods/:id', requireAuth, async (req, res, next) => {
  try {
    await query('UPDATE payment_methods SET is_active = FALSE, deleted_at = NOW(), updated_at = NOW() WHERE id = $1::uuid', [req.params.id]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/business-hours', requireAuth, async (req, res, next) => {
  try {
    const days = Array.isArray(req.body?.days) ? req.body.days : [];
    if (!days.length) return res.status(400).json({ error: 'Envie os dias de funcionamento.' });

    await query('BEGIN');
    try {
      for (const day of days) {
        const weekday = Number(day.weekday);
        if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) continue;
        const isOpen = parseBool(day.isOpen, true);
        const opensAt = isOpen ? cleanTime(day.opensAt, '08:00:00') : null;
        const closesAt = isOpen ? cleanTime(day.closesAt, '18:00:00') : null;
        await query(`
          INSERT INTO business_hours (weekday, opens_at, closes_at, is_open)
          VALUES ($1::smallint, $2::time, $3::time, $4::boolean)
          ON CONFLICT (weekday) DO UPDATE
          SET opens_at = EXCLUDED.opens_at,
              closes_at = EXCLUDED.closes_at,
              is_open = EXCLUDED.is_open,
              updated_at = NOW()
        `, [weekday, opensAt, closesAt, isOpen]);
      }
      await query('COMMIT');
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }

    res.json(await getOperationalSettingsPayload());
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/time-slots', requireAuth, async (req, res, next) => {
  try {
    const slots = Array.isArray(req.body?.slots) ? req.body.slots : [];
    if (!slots.length) return res.status(400).json({ error: 'Envie os slots por hora.' });

    await query('BEGIN');
    try {
      for (const slot of slots) {
        const weekday = Number(slot.weekday);
        const slotTime = normalizeHour(slot.slotTime);
        const capacity = Math.max(0, Number.parseInt(slot.capacity, 10) || 0);
        if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6 || !slotTime) continue;
        await query(`
          INSERT INTO time_slot_capacities (weekday, slot_time, capacity)
          VALUES ($1::smallint, $2::time, $3::integer)
          ON CONFLICT (weekday, slot_time) DO UPDATE
          SET capacity = EXCLUDED.capacity,
              updated_at = NOW()
        `, [weekday, slotTime, capacity]);
      }
      await query('COMMIT');
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }

    res.json(await getOperationalSettingsPayload());
  } catch (error) { next(error); }
});

app.get('/api/configuracoes/pet-options', requireAuth, async (req, res, next) => {
  try {
    res.json(await getPetOptionsPayload({ activeOnly: req.query.activeOnly === 'true' }));
  } catch (error) { next(error); }
});

app.post('/api/configuracoes/pet-types', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tipo de pet.' });
    const code = normalizeCode(req.body?.code || name);
    const result = await query(`
      INSERT INTO pet_types (code, name, description, sort_order, is_active)
      VALUES ($1, $2, $3, $4::int, $5::boolean)
      ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name, description = EXCLUDED.description, sort_order = EXCLUDED.sort_order, is_active = EXCLUDED.is_active, updated_at = NOW()
      RETURNING *
    `, [code, name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    res.status(201).json({ item: sanitizePetType(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/pet-types/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tipo de pet.' });
    const code = normalizeCode(req.body?.code || name);
    const result = await query(`UPDATE pet_types SET code=$1, name=$2, description=$3, sort_order=$4::int, is_active=$5::boolean, updated_at=NOW() WHERE id=$6 RETURNING *`, [code, name, cleanText(req.body?.description), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Tipo de pet não encontrado.' });
    res.json({ item: sanitizePetType(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/pet-types/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query('UPDATE pet_types SET is_active = FALSE, updated_at = NOW() WHERE id = $1 RETURNING *', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Tipo de pet não encontrado.' });
    res.json({ item: sanitizePetType(result.rows[0]) });
  } catch (error) { next(error); }
});

app.post('/api/configuracoes/pet-sizes', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do porte.' });
    const code = normalizeCode(req.body?.code || name);
    const result = await query(`
      INSERT INTO pet_sizes (code, name, description, min_weight_kg, max_weight_kg, sort_order, is_active)
      VALUES ($1, $2, $3, $4::numeric, $5::numeric, $6::int, $7::boolean)
      ON CONFLICT (code) DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description, min_weight_kg=EXCLUDED.min_weight_kg, max_weight_kg=EXCLUDED.max_weight_kg, sort_order=EXCLUDED.sort_order, is_active=EXCLUDED.is_active, updated_at=NOW()
      RETURNING *
    `, [code, name, cleanText(req.body?.description), req.body?.minWeightKg || null, req.body?.maxWeightKg || null, Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    res.status(201).json({ item: sanitizePetSize(result.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/pet-sizes/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do porte.' });
    const code = normalizeCode(req.body?.code || name);
    const result = await query(`UPDATE pet_sizes SET code=$1, name=$2, description=$3, min_weight_kg=$4::numeric, max_weight_kg=$5::numeric, sort_order=$6::int, is_active=$7::boolean, updated_at=NOW() WHERE id=$8 RETURNING *`, [code, name, cleanText(req.body?.description), req.body?.minWeightKg || null, req.body?.maxWeightKg || null, Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Porte não encontrado.' });
    res.json({ item: sanitizePetSize(result.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/pet-sizes/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query('UPDATE pet_sizes SET is_active = FALSE, updated_at = NOW() WHERE id = $1 RETURNING *', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Porte não encontrado.' });
    res.json({ item: sanitizePetSize(result.rows[0]) });
  } catch (error) { next(error); }
});

app.post('/api/configuracoes/pet-breeds', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome da raça.' });
    const result = await query(`
      INSERT INTO pet_breeds (pet_type_id, name, suggested_size_code, coat_type, sort_order, is_active)
      VALUES ($1::uuid, $2, $3, $4, $5::int, $6::boolean)
      ON CONFLICT (pet_type_id, name) DO UPDATE SET suggested_size_code=EXCLUDED.suggested_size_code, coat_type=EXCLUDED.coat_type, sort_order=EXCLUDED.sort_order, is_active=EXCLUDED.is_active, updated_at=NOW()
      RETURNING *
    `, [req.body?.petTypeId, name, cleanText(req.body?.suggestedSizeCode), cleanText(req.body?.coatType), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true)]);
    const enriched = await query('SELECT b.*, pt.name AS pet_type_name, pt.code AS pet_type_code FROM pet_breeds b LEFT JOIN pet_types pt ON pt.id=b.pet_type_id WHERE b.id=$1', [result.rows[0].id]);
    res.status(201).json({ item: sanitizePetBreed(enriched.rows[0]) });
  } catch (error) { next(error); }
});

app.put('/api/configuracoes/pet-breeds/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome da raça.' });
    const result = await query(`UPDATE pet_breeds SET pet_type_id=$1::uuid, name=$2, suggested_size_code=$3, coat_type=$4, sort_order=$5::int, is_active=$6::boolean, updated_at=NOW() WHERE id=$7 RETURNING *`, [req.body?.petTypeId, name, cleanText(req.body?.suggestedSizeCode), cleanText(req.body?.coatType), Number(req.body?.sortOrder || 0), parseBool(req.body?.isActive, true), req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Raça não encontrada.' });
    const enriched = await query('SELECT b.*, pt.name AS pet_type_name, pt.code AS pet_type_code FROM pet_breeds b LEFT JOIN pet_types pt ON pt.id=b.pet_type_id WHERE b.id=$1', [result.rows[0].id]);
    res.json({ item: sanitizePetBreed(enriched.rows[0]) });
  } catch (error) { next(error); }
});

app.delete('/api/configuracoes/pet-breeds/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query('UPDATE pet_breeds SET is_active = FALSE, updated_at = NOW() WHERE id = $1 RETURNING *', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Raça não encontrada.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/tutores', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const status = cleanText(req.query.status) || 'active';
    const limit = parseLimit(req.query.limit, 20);
    const offset = parseOffset(req.query.page, limit);
    const params = [];
    const where = ['t.deleted_at IS NULL'];

    if (status !== 'all') {
      params.push(status);
      where.push(`t.status = $${params.length}`);
    }

    if (search) {
      params.push(`%${search.replace(/\s+/g, '%')}%`);
      params.push(`%${normalizeWhatsapp(search)}%`);
      where.push(`(unaccent(lower(t.name)) ILIKE unaccent(lower($${params.length - 1})) OR t.whatsapp ILIKE $${params.length} OR lower(COALESCE(t.email,'')) ILIKE lower($${params.length - 1}))`);
    }

    params.push(limit);
    params.push(offset);

    const result = await query(`
      SELECT t.id, t.name, t.whatsapp, t.phone, t.email, t.document_number, t.address, t.city, t.state, t.photo_url,
             t.tags, t.notes, t.status, t.created_at, t.updated_at,
             COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL)::int AS pets_count,
             COALESCE(MAX(a.starts_at), NULL) AS last_appointment_at
      FROM tutors t
      LEFT JOIN pets p ON p.tutor_id = t.id AND p.deleted_at IS NULL
      LEFT JOIN appointments a ON a.tutor_id = t.id AND a.deleted_at IS NULL
      WHERE ${where.join(' AND ')}
      GROUP BY t.id
      ORDER BY t.updated_at DESC, t.name ASC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `, params);

    const totalResult = await query(`SELECT COUNT(*)::int AS total FROM tutors t WHERE ${where.join(' AND ')}`, params.slice(0, -2));

    res.json({
      items: result.rows.map((row) => ({
        ...sanitizeTutor(row),
        phone: row.phone,
        documentNumber: row.document_number,
        address: row.address,
        status: row.status,
        notes: row.notes,
        petsCount: Number(row.pets_count || 0),
        lastAppointmentAt: row.last_appointment_at,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      })),
      page: Number(req.query.page || 1),
      limit,
      total: Number(totalResult.rows[0]?.total || 0)
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/tutores/:id', requireAuth, async (req, res, next) => {
  try {
    const tutor = await getTutorById(req.params.id);
    if (!tutor) return res.status(404).json({ error: 'Tutor não encontrado.' });
    const pets = await query(`
      SELECT p.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp
      FROM pets p
      INNER JOIN tutors t ON t.id = p.tutor_id
      WHERE p.tutor_id = $1 AND p.deleted_at IS NULL
      ORDER BY p.name ASC
    `, [req.params.id]);
    res.json({
      tutor: {
        ...sanitizeTutor(tutor),
        phone: tutor.phone,
        documentNumber: tutor.document_number,
        address: tutor.address,
        status: tutor.status,
        notes: tutor.notes,
        petsCount: Number(tutor.pets_count || 0),
        lastAppointmentAt: tutor.last_appointment_at,
        createdAt: tutor.created_at,
        updatedAt: tutor.updated_at
      },
      pets: pets.rows.map(sanitizePet)
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/tutores', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body.name);
    const whatsapp = normalizeWhatsapp(req.body.whatsapp);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tutor.' });
    if (!whatsapp) return res.status(400).json({ error: 'Informe o WhatsApp do tutor.' });

    const result = await query(`
      INSERT INTO tutors (name, whatsapp, phone, email, document_number, address, city, state, tags, notes, status, photo_url)
      VALUES ($1, $2, $3, $4, $5, $6, COALESCE($7, 'Ribeirão Preto'), COALESCE($8, 'SP'), $9::text[], $10, COALESCE($11, 'active'), $12)
      ON CONFLICT (whatsapp) DO UPDATE
      SET name = EXCLUDED.name,
          phone = EXCLUDED.phone,
          email = EXCLUDED.email,
          document_number = EXCLUDED.document_number,
          address = EXCLUDED.address,
          city = EXCLUDED.city,
          state = EXCLUDED.state,
          tags = EXCLUDED.tags,
          notes = EXCLUDED.notes,
          status = EXCLUDED.status,
          photo_url = EXCLUDED.photo_url,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [
      name,
      whatsapp,
      cleanText(req.body.phone),
      cleanText(req.body.email),
      cleanText(req.body.documentNumber || req.body.document_number),
      cleanText(req.body.address),
      cleanText(req.body.city),
      cleanText(req.body.state),
      parseTags(req.body.tags),
      cleanText(req.body.notes),
      cleanText(req.body.status),
      cleanPhotoDataUrl(req.body.photoDataUrl || req.body.photoUrl)
    ]);

    res.status(201).json({ tutor: sanitizeTutor(result.rows[0]), message: 'Tutor salvo com sucesso.' });
  } catch (error) {
    next(error);
  }
});

app.put('/api/tutores/:id', requireAuth, async (req, res, next) => {
  try {
    const current = await getTutorById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Tutor não encontrado.' });

    const name = cleanText(req.body.name);
    const whatsapp = normalizeWhatsapp(req.body.whatsapp);
    if (!name) return res.status(400).json({ error: 'Informe o nome do tutor.' });
    if (!whatsapp) return res.status(400).json({ error: 'Informe o WhatsApp do tutor.' });

    const result = await query(`
      UPDATE tutors
      SET name = $2,
          whatsapp = $3,
          phone = $4,
          email = $5,
          document_number = $6,
          address = $7,
          city = COALESCE($8, 'Ribeirão Preto'),
          state = COALESCE($9, 'SP'),
          tags = $10::text[],
          notes = $11,
          status = COALESCE($12, 'active'),
          photo_url = $13,
          updated_at = NOW()
      WHERE id = $1 AND deleted_at IS NULL
      RETURNING *
    `, [
      req.params.id,
      name,
      whatsapp,
      cleanText(req.body.phone),
      cleanText(req.body.email),
      cleanText(req.body.documentNumber || req.body.document_number),
      cleanText(req.body.address),
      cleanText(req.body.city),
      cleanText(req.body.state),
      parseTags(req.body.tags),
      cleanText(req.body.notes),
      cleanText(req.body.status),
      cleanPhotoDataUrl(req.body.photoDataUrl || req.body.photoUrl)
    ]);

    res.json({ tutor: sanitizeTutor(result.rows[0]), message: 'Tutor atualizado com sucesso.' });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Já existe outro tutor com este WhatsApp.' });
    next(error);
  }
});

app.delete('/api/tutores/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      UPDATE tutors
      SET deleted_at = NOW(), status = 'inactive', updated_at = NOW()
      WHERE id = $1 AND deleted_at IS NULL
      RETURNING id
    `, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Tutor não encontrado.' });
    await query(`UPDATE pets SET deleted_at = NOW(), status = 'inactive', updated_at = NOW() WHERE tutor_id = $1 AND deleted_at IS NULL`, [req.params.id]);
    res.json({ ok: true, message: 'Tutor e pets vinculados foram inativados.' });
  } catch (error) {
    next(error);
  }
});

app.get('/api/tutores/:id/pets', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      SELECT p.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp
      FROM pets p
      INNER JOIN tutors t ON t.id = p.tutor_id
      WHERE p.tutor_id = $1
        AND p.deleted_at IS NULL
      ORDER BY p.name ASC
    `, [req.params.id]);
    res.json({ items: result.rows.map(sanitizePet) });
  } catch (error) {
    next(error);
  }
});


app.get('/api/tutores/:id/historico', requireAuth, async (req, res, next) => {
  try {
    const tutor = await getTutorById(req.params.id);
    if (!tutor) return res.status(404).json({ error: 'Tutor não encontrado.' });
    const result = await query(`
      SELECT a.*, p.name AS pet_name, p.size AS pet_size,
             s.name AS status_name, s.color AS status_color,
             pm.name AS payment_method_name,
             COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services,
             ft.id AS financial_transaction_id,
             ft.status AS financial_status,
             r.public_token AS receipt_token,
             r.document_number AS receipt_number
      FROM appointments a
      LEFT JOIN pets p ON p.id = a.pet_id
      LEFT JOIN appointment_statuses s ON s.code = a.status
      LEFT JOIN payment_methods pm ON pm.id = a.payment_method_id
      LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
      LEFT JOIN financial_transactions ft ON ft.appointment_id = a.id AND ft.deleted_at IS NULL
      LEFT JOIN receipts r ON r.appointment_id = a.id
      WHERE a.tutor_id = $1::uuid AND a.deleted_at IS NULL
      GROUP BY a.id, p.name, p.size, s.name, s.color, pm.name, ft.id, ft.status, r.public_token, r.document_number
      ORDER BY a.starts_at DESC
      LIMIT 120
    `, [req.params.id]);
    res.json({
      tutor: sanitizeTutor(tutor),
      items: result.rows.map((row) => ({
        ...sanitizeAppointment({ ...row, tutor_name: tutor.name, tutor_whatsapp: tutor.whatsapp }),
        financialTransactionId: row.financial_transaction_id || null,
        financialStatus: row.financial_status || null,
        receiptToken: row.receipt_token || null,
        receiptNumber: row.receipt_number || null,
        commandUrl: `/admin/comandas-recibos?appointmentId=${row.id}`,
        receiptUrl: row.receipt_token ? `/documentos/recibo/${row.receipt_token}` : null
      }))
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/pets', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const status = cleanText(req.query.status) || 'active';
    const size = cleanText(req.query.size);
    const tutorId = cleanText(req.query.tutorId || req.query.tutor_id);
    const limit = parseLimit(req.query.limit, 24);
    const offset = parseOffset(req.query.page, limit);
    const params = [];
    const where = ['p.deleted_at IS NULL', 't.deleted_at IS NULL'];

    if (status !== 'all') {
      params.push(status);
      where.push(`p.status = $${params.length}`);
    }
    if (size && size !== 'all') {
      params.push(size);
      where.push(`p.size = $${params.length}`);
    }
    if (tutorId) {
      params.push(tutorId);
      where.push(`p.tutor_id = $${params.length}`);
    }
    if (search) {
      params.push(`%${search.replace(/\s+/g, '%')}%`);
      params.push(`%${normalizeWhatsapp(search)}%`);
      where.push(`(unaccent(lower(p.name)) ILIKE unaccent(lower($${params.length - 1})) OR unaccent(lower(COALESCE(p.breed,''))) ILIKE unaccent(lower($${params.length - 1})) OR unaccent(lower(t.name)) ILIKE unaccent(lower($${params.length - 1})) OR t.whatsapp ILIKE $${params.length})`);
    }

    params.push(limit);
    params.push(offset);

    const result = await query(`
      SELECT p.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp
      FROM pets p
      INNER JOIN tutors t ON t.id = p.tutor_id
      WHERE ${where.join(' AND ')}
      ORDER BY p.updated_at DESC, p.name ASC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `, params);
    const totalResult = await query(`
      SELECT COUNT(*)::int AS total
      FROM pets p
      INNER JOIN tutors t ON t.id = p.tutor_id
      WHERE ${where.join(' AND ')}
    `, params.slice(0, -2));

    res.json({
      items: result.rows.map(sanitizePet),
      page: Number(req.query.page || 1),
      limit,
      total: Number(totalResult.rows[0]?.total || 0)
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/pets/:id', requireAuth, async (req, res, next) => {
  try {
    const pet = await getPetById(req.params.id);
    if (!pet) return res.status(404).json({ error: 'Pet não encontrado.' });
    res.json({ pet: sanitizePet(pet) });
  } catch (error) {
    next(error);
  }
});

app.post('/api/pets', requireAuth, async (req, res, next) => {
  try {
    const tutorId = cleanText(req.body.tutorId || req.body.tutor_id);
    const name = cleanText(req.body.name);
    if (!tutorId) return res.status(400).json({ error: 'Informe o tutor do pet.' });
    if (!name) return res.status(400).json({ error: 'Informe o nome do pet.' });

    const tutor = await getTutorById(tutorId);
    if (!tutor) return res.status(404).json({ error: 'Tutor não encontrado para vincular o pet.' });

    const result = await query(`
      INSERT INTO pets (tutor_id, name, species, breed, size, coat_type, birth_date, weight_kg, preferences, restrictions, notes, status, photo_url)
      VALUES ($1, $2, COALESCE($3, 'dog'), $4, COALESCE($5, 'pequeno'), $6, $7::date, $8::numeric, $9, $10, $11, COALESCE($12, 'active'), $13)
      RETURNING *
    `, [
      tutorId,
      name,
      cleanText(req.body.species),
      cleanText(req.body.breed),
      cleanText(req.body.size),
      cleanText(req.body.coatType || req.body.coat_type),
      cleanText(req.body.birthDate || req.body.birth_date),
      cleanText(req.body.weightKg || req.body.weight_kg),
      cleanText(req.body.preferences),
      cleanText(req.body.restrictions),
      cleanText(req.body.notes),
      cleanText(req.body.status),
      cleanPhotoDataUrl(req.body.photoDataUrl || req.body.photoUrl)
    ]);

    const pet = await getPetById(result.rows[0].id);
    res.status(201).json({ pet: sanitizePet(pet), message: 'Pet salvo com sucesso.' });
  } catch (error) {
    next(error);
  }
});

app.put('/api/pets/:id', requireAuth, async (req, res, next) => {
  try {
    const current = await getPetById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Pet não encontrado.' });

    const tutorId = cleanText(req.body.tutorId || req.body.tutor_id);
    const name = cleanText(req.body.name);
    if (!tutorId) return res.status(400).json({ error: 'Informe o tutor do pet.' });
    if (!name) return res.status(400).json({ error: 'Informe o nome do pet.' });

    const tutor = await getTutorById(tutorId);
    if (!tutor) return res.status(404).json({ error: 'Tutor não encontrado para vincular o pet.' });

    await query(`
      UPDATE pets
      SET tutor_id = $2,
          name = $3,
          species = COALESCE($4, 'dog'),
          breed = $5,
          size = COALESCE($6, 'pequeno'),
          coat_type = $7,
          birth_date = $8::date,
          weight_kg = $9::numeric,
          preferences = $10,
          restrictions = $11,
          notes = $12,
          status = COALESCE($13, 'active'),
          photo_url = $14,
          updated_at = NOW()
      WHERE id = $1 AND deleted_at IS NULL
    `, [
      req.params.id,
      tutorId,
      name,
      cleanText(req.body.species),
      cleanText(req.body.breed),
      cleanText(req.body.size),
      cleanText(req.body.coatType || req.body.coat_type),
      cleanText(req.body.birthDate || req.body.birth_date),
      cleanText(req.body.weightKg || req.body.weight_kg),
      cleanText(req.body.preferences),
      cleanText(req.body.restrictions),
      cleanText(req.body.notes),
      cleanText(req.body.status),
      cleanPhotoDataUrl(req.body.photoDataUrl || req.body.photoUrl)
    ]);

    const pet = await getPetById(req.params.id);
    res.json({ pet: sanitizePet(pet), message: 'Pet atualizado com sucesso.' });
  } catch (error) {
    next(error);
  }
});

app.delete('/api/pets/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      UPDATE pets
      SET deleted_at = NOW(), status = 'inactive', updated_at = NOW()
      WHERE id = $1 AND deleted_at IS NULL
      RETURNING id
    `, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Pet não encontrado.' });
    res.json({ ok: true, message: 'Pet inativado com sucesso.' });
  } catch (error) {
    next(error);
  }
});


app.post('/api/app/first-access/request', async (req, res, next) => {
  try {
    const whatsapp = normalizeWhatsapp(req.body?.whatsapp);
    if (!whatsapp) return res.status(400).json({ error: 'Informe o WhatsApp do tutor.' });

    const tutorResult = await query(`
      SELECT id, name, whatsapp, email, city, state, tags
      FROM tutors
      WHERE whatsapp = $1
        AND deleted_at IS NULL
      LIMIT 1
    `, [whatsapp]);

    const tutor = tutorResult.rows[0];
    if (!tutor) {
      return res.status(404).json({ error: 'WhatsApp não encontrado. Fale com o PetFunny para liberar seu acesso.' });
    }

    const code = makeSixDigitCode();
    const codeHash = await bcrypt.hash(code, 10);

    await query(`
      INSERT INTO client_accounts (tutor_id, whatsapp, first_access_code_hash, first_access_expires_at, status, is_active)
      VALUES ($1, $2, $3, NOW() + INTERVAL '20 minutes', 'pending_first_access', FALSE)
      ON CONFLICT (whatsapp) DO UPDATE
      SET tutor_id = EXCLUDED.tutor_id,
          first_access_code_hash = EXCLUDED.first_access_code_hash,
          first_access_expires_at = EXCLUDED.first_access_expires_at,
          status = CASE WHEN client_accounts.password_hash IS NULL THEN 'pending_first_access' ELSE client_accounts.status END,
          updated_at = NOW()
    `, [tutor.id, whatsapp, codeHash]);

    res.json({
      ok: true,
      message: 'Código de primeiro acesso gerado. Em produção ele será enviado pelo WhatsApp.',
      channel: 'whatsapp',
      tutor: sanitizeTutor(tutor),
      devCode: env.nodeEnv === 'production' ? undefined : code
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/app/first-access/confirm', async (req, res, next) => {
  try {
    const whatsapp = normalizeWhatsapp(req.body?.whatsapp);
    const code = String(req.body?.code || '').replace(/\D/g, '');
    const password = String(req.body?.password || '');

    if (!whatsapp || !code || !password) {
      return res.status(400).json({ error: 'Informe WhatsApp, código e senha.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'A senha precisa ter pelo menos 8 caracteres.' });
    }

    const result = await query(`
      SELECT ca.id, ca.tutor_id, ca.first_access_code_hash, ca.first_access_expires_at,
             t.name, t.email, t.city, t.state, t.tags, t.whatsapp
      FROM client_accounts ca
      INNER JOIN tutors t ON t.id = ca.tutor_id
      WHERE ca.whatsapp = $1
        AND ca.deleted_at IS NULL
      LIMIT 1
    `, [whatsapp]);

    const account = result.rows[0];
    if (!account?.first_access_code_hash) {
      return res.status(401).json({ error: 'Solicite um novo código de primeiro acesso.' });
    }

    if (new Date(account.first_access_expires_at).getTime() < Date.now()) {
      return res.status(401).json({ error: 'Código expirado. Solicite um novo código.' });
    }

    const codeOk = await bcrypt.compare(code, account.first_access_code_hash);
    if (!codeOk) return res.status(401).json({ error: 'Código inválido.' });

    const passwordHash = await bcrypt.hash(password, 12);
    await query(`
      UPDATE client_accounts
      SET password_hash = $2,
          first_access_code_hash = NULL,
          first_access_expires_at = NULL,
          first_access_confirmed_at = NOW(),
          is_active = TRUE,
          status = 'active',
          updated_at = NOW()
      WHERE id = $1
    `, [account.id, passwordHash]);

    const token = jwt.sign(
      { sub: account.id, tutorId: account.tutor_id, scope: 'client_app', channel: 'whatsapp', tenant: false },
      env.jwtSecret,
      { expiresIn: env.jwtExpiresIn }
    );

    res.json({
      token,
      tokenType: 'Bearer',
      expiresIn: env.jwtExpiresIn,
      account: { id: account.id, status: 'active', whatsapp },
      tutor: sanitizeTutor({ ...account, id: account.tutor_id, whatsapp })
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/app/login', async (req, res, next) => {
  try {
    const whatsapp = normalizeWhatsapp(req.body?.whatsapp);
    const password = String(req.body?.password || '');
    if (!whatsapp || !password) return res.status(400).json({ error: 'Informe WhatsApp e senha.' });

    const result = await query(`
      SELECT ca.id, ca.tutor_id, ca.password_hash, ca.status, ca.is_active,
             t.name, t.email, t.city, t.state, t.tags, t.whatsapp
      FROM client_accounts ca
      INNER JOIN tutors t ON t.id = ca.tutor_id
      WHERE ca.whatsapp = $1
        AND ca.deleted_at IS NULL
        AND t.deleted_at IS NULL
      LIMIT 1
    `, [whatsapp]);

    const account = result.rows[0];
    if (!account?.password_hash || !account.is_active) {
      return res.status(401).json({ error: 'Acesso não liberado. Faça o primeiro acesso ou fale com o PetFunny.' });
    }

    const passwordOk = await bcrypt.compare(password, account.password_hash);
    if (!passwordOk) return res.status(401).json({ error: 'WhatsApp ou senha inválidos.' });

    await query('UPDATE client_accounts SET last_login_at = NOW(), updated_at = NOW() WHERE id = $1', [account.id]);

    const token = jwt.sign(
      { sub: account.id, tutorId: account.tutor_id, scope: 'client_app', channel: 'whatsapp', tenant: false },
      env.jwtSecret,
      { expiresIn: env.jwtExpiresIn }
    );

    res.json({
      token,
      tokenType: 'Bearer',
      expiresIn: env.jwtExpiresIn,
      account: { id: account.id, status: account.status, whatsapp },
      tutor: sanitizeTutor({ ...account, id: account.tutor_id, whatsapp })
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/app/me', requireClientAuth, async (req, res) => {
  res.json(req.clientApp);
});

app.post('/api/app/logout', requireClientAuth, async (req, res) => {
  res.json({ ok: true, message: 'Sessão encerrada no aplicativo do cliente.' });
});



function moneyToCents(value) {
  if (value === undefined || value === null || value === '') return 0;
  if (typeof value === 'number') return Math.max(0, Math.round(value));
  const text = String(value).trim();
  if (!text) return 0;
  // Aceita tanto centavos diretos quanto formato brasileiro: R$ 55,90 / 55,90
  if (/^\d+$/.test(text)) return Math.max(0, Number(text));
  const normalized = text.replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.');
  const amount = Number.parseFloat(normalized);
  if (!Number.isFinite(amount)) return 0;
  return Math.max(0, Math.round(amount * 100));
}

function sanitizeService(row = {}) {
  return {
    id: row.id,
    categoryId: row.category_id,
    categoryName: row.category_name,
    categoryPetTypeCode: row.category_pet_type_code || row.pet_type_code || null,
    categoryPetTypeName: row.category_pet_type_name || row.pet_type_name || null,
    categoryPetSizeCode: row.category_pet_size_code || row.pet_size_code || null,
    categoryPetSizeName: row.category_pet_size_name || row.pet_size_name || null,
    name: row.name,
    description: row.description,
    petSize: row.pet_size,
    petSizeName: row.pet_size_name || row.pet_size,
    priceCents: Number(row.price_cents || 0),
    durationMinutes: Number(row.duration_minutes || 0),
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

async function getServiceById(id) {
  const result = await query(`
    SELECT s.*, sc.name AS category_name, sc.pet_type_code AS category_pet_type_code, pt.name AS category_pet_type_name, sc.pet_size_code AS category_pet_size_code, cps.name AS category_pet_size_name, ps.name AS pet_size_name
    FROM services s
    LEFT JOIN service_categories sc ON sc.id = s.category_id
    LEFT JOIN pet_types pt ON pt.code = sc.pet_type_code
    LEFT JOIN pet_sizes cps ON cps.code = sc.pet_size_code
    LEFT JOIN pet_sizes ps ON ps.code = s.pet_size
    WHERE s.id = $1::uuid
      AND s.deleted_at IS NULL
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}

app.get('/api/servicos/options', requireAuth, async (req, res, next) => {
  try {
    const serviceTypes = await query(`
      SELECT sc.*, pt.name AS pet_type_name, ps.name AS pet_size_name
      FROM service_categories sc
      LEFT JOIN pet_types pt ON pt.code = sc.pet_type_code
      LEFT JOIN pet_sizes ps ON ps.code = sc.pet_size_code
      WHERE sc.deleted_at IS NULL AND sc.is_active = TRUE
      ORDER BY sc.sort_order ASC, sc.name ASC
    `);
    const petSizes = await query(`
      SELECT * FROM pet_sizes
      WHERE is_active = TRUE
      ORDER BY sort_order ASC, name ASC
    `);
    res.json({
      serviceTypes: serviceTypes.rows.map(sanitizeServiceType),
      petSizes: petSizes.rows.map(sanitizePetSize)
    });
  } catch (error) { next(error); }
});

app.get('/api/servicos', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const status = cleanText(req.query.status) || 'active';
    const categoryId = cleanText(req.query.categoryId);
    const petSize = cleanText(req.query.petSize);
    const limit = parseLimit(req.query.limit, 20, 100);
    const offset = parseOffset(req.query.page, limit);
    const params = [];
    const where = ['s.deleted_at IS NULL'];

    if (status !== 'all') {
      params.push(status === 'active');
      where.push(`s.is_active = $${params.length}::boolean`);
    }
    if (categoryId && categoryId !== 'all') {
      params.push(categoryId);
      where.push(`s.category_id = $${params.length}::uuid`);
    }
    if (petSize && petSize !== 'all') {
      params.push(petSize);
      where.push(`s.pet_size = $${params.length}::text`);
    }
    if (search) {
      params.push(`%${search.replace(/\s+/g, '%')}%`);
      where.push(`(unaccent(lower(s.name)) ILIKE unaccent(lower($${params.length})) OR unaccent(lower(COALESCE(s.description,''))) ILIKE unaccent(lower($${params.length})) OR unaccent(lower(COALESCE(sc.name,''))) ILIKE unaccent(lower($${params.length})))`);
    }

    params.push(limit);
    params.push(offset);
    const result = await query(`
      SELECT s.*, sc.name AS category_name, sc.pet_type_code AS category_pet_type_code, pt.name AS category_pet_type_name, sc.pet_size_code AS category_pet_size_code, cps.name AS category_pet_size_name, ps.name AS pet_size_name
      FROM services s
      LEFT JOIN service_categories sc ON sc.id = s.category_id
      LEFT JOIN pet_types pt ON pt.code = sc.pet_type_code
      LEFT JOIN pet_sizes cps ON cps.code = sc.pet_size_code
      LEFT JOIN pet_sizes ps ON ps.code = s.pet_size
      WHERE ${where.join(' AND ')}
      ORDER BY sc.sort_order ASC NULLS LAST, s.name ASC, ps.sort_order ASC NULLS LAST, s.updated_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `, params);
    const totalResult = await query(`
      SELECT COUNT(*)::int AS total
      FROM services s
      LEFT JOIN service_categories sc ON sc.id = s.category_id
      WHERE ${where.join(' AND ')}
    `, params.slice(0, -2));

    const summary = await query(`
      SELECT
        COUNT(*) FILTER (WHERE s.deleted_at IS NULL)::int AS total,
        COUNT(*) FILTER (WHERE s.deleted_at IS NULL AND s.is_active = TRUE)::int AS active,
        COUNT(DISTINCT s.category_id) FILTER (WHERE s.deleted_at IS NULL AND s.category_id IS NOT NULL)::int AS categories,
        COALESCE(ROUND(AVG(s.price_cents))::int, 0) AS average_price_cents
      FROM services s
    `);

    res.json({
      items: result.rows.map(sanitizeService),
      page: Number(req.query.page || 1),
      limit,
      total: Number(totalResult.rows[0]?.total || 0),
      summary: summary.rows[0] || {}
    });
  } catch (error) { next(error); }
});

app.get('/api/servicos/:id', requireAuth, async (req, res, next) => {
  try {
    const service = await getServiceById(req.params.id);
    if (!service) return res.status(404).json({ error: 'Serviço não encontrado.' });
    res.json({ service: sanitizeService(service) });
  } catch (error) { next(error); }
});

app.post('/api/servicos', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const categoryId = cleanText(req.body?.categoryId);
    const petSize = cleanText(req.body?.petSize) || 'todos';
    const priceCents = moneyToCents(req.body?.priceCents ?? req.body?.price);
    const durationMinutes = Math.max(1, Number.parseInt(req.body?.durationMinutes || '60', 10));
    if (!name) return res.status(400).json({ error: 'Informe o nome do serviço.' });
    if (!categoryId) return res.status(400).json({ error: 'Selecione o tipo de serviço cadastrado em Configurações.' });
    if (!petSize) return res.status(400).json({ error: 'Selecione o porte cadastrado em Configurações.' });

    const sizeExists = await query('SELECT 1 FROM pet_sizes WHERE code = $1::text AND is_active = TRUE LIMIT 1', [petSize]);
    if (!sizeExists.rowCount) return res.status(400).json({ error: 'Porte inválido. Cadastre ou ative o porte em Configurações.' });
    const categoryExists = await query('SELECT 1 FROM service_categories WHERE id = $1::uuid AND deleted_at IS NULL AND is_active = TRUE LIMIT 1', [categoryId]);
    if (!categoryExists.rowCount) return res.status(400).json({ error: 'Tipo de serviço inválido. Cadastre ou ative em Configurações.' });

    const result = await query(`
      INSERT INTO services (category_id, name, description, pet_size, price_cents, duration_minutes, is_active)
      VALUES ($1::uuid, $2::text, $3::text, $4::text, $5::integer, $6::integer, $7::boolean)
      ON CONFLICT (name, pet_size) DO UPDATE
      SET category_id = EXCLUDED.category_id,
          description = EXCLUDED.description,
          price_cents = EXCLUDED.price_cents,
          duration_minutes = EXCLUDED.duration_minutes,
          is_active = EXCLUDED.is_active,
          deleted_at = NULL,
          updated_at = NOW()
      RETURNING *
    `, [categoryId, name, cleanText(req.body?.description), petSize, priceCents, durationMinutes, parseBool(req.body?.isActive, true)]);
    const enriched = await getServiceById(result.rows[0].id);
    res.status(201).json({ service: sanitizeService(enriched), message: 'Serviço salvo com sucesso.' });
  } catch (error) { next(error); }
});

app.put('/api/servicos/:id', requireAuth, async (req, res, next) => {
  try {
    const current = await getServiceById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Serviço não encontrado.' });

    const name = cleanText(req.body?.name);
    const categoryId = cleanText(req.body?.categoryId);
    const petSize = cleanText(req.body?.petSize) || 'todos';
    const priceCents = moneyToCents(req.body?.priceCents ?? req.body?.price);
    const durationMinutes = Math.max(1, Number.parseInt(req.body?.durationMinutes || '60', 10));
    if (!name) return res.status(400).json({ error: 'Informe o nome do serviço.' });
    if (!categoryId) return res.status(400).json({ error: 'Selecione o tipo de serviço cadastrado em Configurações.' });

    const sizeExists = await query('SELECT 1 FROM pet_sizes WHERE code = $1::text AND is_active = TRUE LIMIT 1', [petSize]);
    if (!sizeExists.rowCount) return res.status(400).json({ error: 'Porte inválido. Cadastre ou ative o porte em Configurações.' });
    const categoryExists = await query('SELECT 1 FROM service_categories WHERE id = $1::uuid AND deleted_at IS NULL AND is_active = TRUE LIMIT 1', [categoryId]);
    if (!categoryExists.rowCount) return res.status(400).json({ error: 'Tipo de serviço inválido. Cadastre ou ative em Configurações.' });

    const result = await query(`
      UPDATE services
      SET category_id = $2::uuid,
          name = $3::text,
          description = $4::text,
          pet_size = $5::text,
          price_cents = $6::integer,
          duration_minutes = $7::integer,
          is_active = $8::boolean,
          updated_at = NOW()
      WHERE id = $1::uuid
        AND deleted_at IS NULL
      RETURNING *
    `, [req.params.id, categoryId, name, cleanText(req.body?.description), petSize, priceCents, durationMinutes, parseBool(req.body?.isActive, true)]);
    const enriched = await getServiceById(result.rows[0].id);
    res.json({ service: sanitizeService(enriched), message: 'Serviço atualizado com sucesso.' });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Já existe serviço com este nome e porte.' });
    next(error);
  }
});

app.delete('/api/servicos/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      UPDATE services
      SET is_active = FALSE,
          deleted_at = NOW(),
          updated_at = NOW()
      WHERE id = $1::uuid
        AND deleted_at IS NULL
      RETURNING id
    `, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Serviço não encontrado.' });
    res.json({ ok: true, message: 'Serviço inativado.' });
  } catch (error) { next(error); }
});


function toIsoOrNull(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
}

function centsFromServices(items = [], discountPercent = 0) {
  const subtotal = items.reduce((sum, item) => sum + Number(item.unitPriceCents || item.priceCents || 0) * Number(item.quantity || 1), 0);
  const discount = Math.round(subtotal * Math.max(0, Math.min(100, Number(discountPercent || 0))) / 100);
  return { subtotalCents: subtotal, discountCents: discount, totalCents: Math.max(0, subtotal - discount) };
}

function sanitizeAppointment(row = {}) {
  return {
    id: row.id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name,
    tutorWhatsapp: row.tutor_whatsapp,
    petId: row.pet_id,
    petName: row.pet_name,
    petSize: row.pet_size,
    collaboratorId: row.collaborator_id,
    collaboratorName: row.collaborator_name,
    startsAt: row.starts_at,
    endsAt: row.ends_at,
    status: row.status,
    statusName: row.status_name,
    statusColor: row.status_color,
    source: row.source,
    subtotalCents: Number(row.subtotal_cents || 0),
    discountPercent: Number(row.discount_percent || 0),
    discountCents: Number(row.discount_cents || 0),
    totalCents: Number(row.total_cents || 0),
    packageSessionLabel: row.package_session_label,
    notes: row.notes,
    paymentStatus: row.payment_status || 'pending',
    paymentMethodId: row.payment_method_id || null,
    paymentMethodName: row.payment_method_name || null,
    checkedInAt: row.checked_in_at,
    checkedOutAt: row.checked_out_at,
    services: row.services || '',
    items: Array.isArray(row.items) ? row.items : []
  };
}

async function getAppointmentById(id) {
  const result = await query(`
    SELECT a.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, p.size AS pet_size,
           c.name AS collaborator_name, s.name AS status_name, s.color AS status_color, pm.name AS payment_method_name,
           COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services,
           COALESCE(json_agg(json_build_object('id', ai.id, 'serviceId', ai.service_id, 'petId', ai.pet_id, 'description', ai.description, 'quantity', ai.quantity, 'unitPriceCents', ai.unit_price_cents, 'discountPercent', ai.discount_percent, 'totalCents', ai.total_cents) ORDER BY ai.created_at) FILTER (WHERE ai.id IS NOT NULL), '[]'::json) AS items
    FROM appointments a
    LEFT JOIN tutors t ON t.id = a.tutor_id
    LEFT JOIN pets p ON p.id = a.pet_id
    LEFT JOIN collaborators c ON c.id = a.collaborator_id
    LEFT JOIN appointment_statuses s ON s.code = a.status
    LEFT JOIN payment_methods pm ON pm.id = a.payment_method_id
    LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
    WHERE a.id = $1::uuid AND a.deleted_at IS NULL
    GROUP BY a.id, t.name, t.whatsapp, p.name, p.size, c.name, s.name, s.color, pm.name
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}

function getLocalSlotParts(startsAtValue) {
  const text = String(startsAtValue || '').trim();
  const match = text.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
  if (match) {
    const weekday = new Date(`${match[1]}T12:00:00`).getDay();
    return { date: match[1], time: match[2], weekday };
  }
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return null;
  const localDate = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
  const localTime = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit', hour12: false }).format(date);
  const weekday = new Date(`${localDate}T12:00:00`).getDay();
  return { date: localDate, time: localTime, weekday };
}

async function assertSlotAvailable(startsAtValue, statusCode, excludeAppointmentId = null) {
  const statusResult = await query('SELECT blocks_slot FROM appointment_statuses WHERE code = $1::text AND deleted_at IS NULL LIMIT 1', [statusCode]);
  const blocksSlot = statusResult.rows[0]?.blocks_slot !== false;
  if (!blocksSlot) return;

  const parts = getLocalSlotParts(startsAtValue);
  if (!parts?.date || !parts?.time) throw new Error('Data/hora inválida para o agendamento.');

  const slotResult = await query(`
    SELECT bh.is_open,
           bh.opens_at,
           bh.closes_at,
           COALESCE(tsc.capacity, 0)::int AS capacity,
           $2::time AS slot_time
    FROM business_hours bh
    LEFT JOIN time_slot_capacities tsc ON tsc.weekday = bh.weekday AND tsc.slot_time = $2::time
    WHERE bh.weekday = $1::integer
    LIMIT 1
  `, [parts.weekday, parts.time]);
  const slot = slotResult.rows[0];
  if (!slot || !slot.is_open) throw new Error('O dia selecionado está fechado nas Configurações.');
  const hhmm = String(slot.slot_time || parts.time).slice(0, 5);
  if (hhmm < String(slot.opens_at).slice(0, 5) || hhmm >= String(slot.closes_at).slice(0, 5)) {
    throw new Error('Horário fora do funcionamento configurado.');
  }
  if (Number(slot.capacity || 0) <= 0) throw new Error('Este horário está sem vagas configuradas.');

  const countResult = await query(`
    SELECT COUNT(a.id)::int AS total
    FROM appointments a
    INNER JOIN appointment_statuses s ON s.code = a.status AND s.blocks_slot = TRUE
    WHERE a.deleted_at IS NULL
      AND TO_CHAR(a.starts_at AT TIME ZONE 'America/Sao_Paulo', 'YYYY-MM-DD') = $1::text
      AND TO_CHAR(date_trunc('hour', a.starts_at AT TIME ZONE 'America/Sao_Paulo'), 'HH24:MI') = $2::text
      AND ($3::uuid IS NULL OR a.id <> $3::uuid)
  `, [parts.date, parts.time, excludeAppointmentId]);
  if (Number(countResult.rows[0]?.total || 0) >= Number(slot.capacity || 0)) {
    throw new Error('Limite de agendamentos atingido para este dia e horário. Ajuste os slots em Configurações ou escolha outro horário.');
  }
}

app.get('/api/agenda/options', requireAuth, async (req, res, next) => {
  try {
    const [statuses, collaborators, operational, paymentStatuses, paymentMethods, petOptions] = await Promise.all([
      query('SELECT * FROM appointment_statuses WHERE deleted_at IS NULL AND is_active = TRUE ORDER BY sort_order ASC, name ASC'),
      query('SELECT id, name, role, color FROM collaborators WHERE deleted_at IS NULL AND is_active = TRUE ORDER BY name ASC'),
      getOperationalSettingsPayload(),
      query('SELECT * FROM payment_statuses WHERE deleted_at IS NULL AND is_active = TRUE ORDER BY sort_order ASC, name ASC'),
      query('SELECT * FROM payment_methods WHERE deleted_at IS NULL AND is_active = TRUE ORDER BY sort_order ASC, name ASC'),
      getPetOptionsPayload({ activeOnly: true })
    ]);
    res.json({
      statuses: statuses.rows.map(sanitizeAppointmentStatus),
      collaborators: collaborators.rows.map((row) => ({ id: row.id, name: row.name, role: row.role, color: row.color })),
      businessHours: operational.businessHours,
      timeSlotCapacities: operational.timeSlotCapacities,
      slotPolicy: operational.slotPolicy,
      paymentStatuses: paymentStatuses.rows.map(sanitizePaymentStatus),
      paymentMethods: paymentMethods.rows.map(sanitizePaymentMethod),
      petTypes: petOptions.types,
      petSizes: petOptions.sizes,
      serviceTypes: operational.serviceTypes.filter(st => st.isActive)
    });
  } catch (error) { next(error); }
});

app.get('/api/agenda', requireAuth, async (req, res, next) => {
  try {
    const view = cleanText(req.query.view) || 'day';
    const baseDate = cleanText(req.query.date) || new Date().toISOString().slice(0, 10);
    const status = cleanText(req.query.status) || 'all';
    const collaboratorId = cleanText(req.query.collaboratorId) || 'all';
    let startExpr = '$1::date';
    let endExpr = '$1::date + INTERVAL \'1 day\'';
    if (view === 'week') endExpr = '$1::date + INTERVAL \'7 days\'';
    if (view === 'month') {
      startExpr = 'date_trunc(\'month\', $1::date)';
      endExpr = 'date_trunc(\'month\', $1::date) + INTERVAL \'1 month\'';
    }
    const params = [baseDate];
    const where = [`a.starts_at >= ${startExpr}`, `a.starts_at < ${endExpr}`, 'a.deleted_at IS NULL'];
    if (status !== 'all') { params.push(status); where.push(`a.status = $${params.length}::text`); }
    if (collaboratorId !== 'all') { params.push(collaboratorId); where.push(`a.collaborator_id = $${params.length}::uuid`); }
    const result = await query(`
      SELECT a.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, p.size AS pet_size,
             c.name AS collaborator_name, s.name AS status_name, s.color AS status_color, pm.name AS payment_method_name,
             COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services
      FROM appointments a
      LEFT JOIN tutors t ON t.id = a.tutor_id
      LEFT JOIN pets p ON p.id = a.pet_id
      LEFT JOIN collaborators c ON c.id = a.collaborator_id
      LEFT JOIN appointment_statuses s ON s.code = a.status
    LEFT JOIN payment_methods pm ON pm.id = a.payment_method_id
      LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
      WHERE ${where.join(' AND ')}
      GROUP BY a.id, t.name, t.whatsapp, p.name, p.size, c.name, s.name, s.color, pm.name
      ORDER BY a.starts_at ASC
    `, params);
    res.json({ items: result.rows.map(sanitizeAppointment), view, date: baseDate, total: result.rowCount });
  } catch (error) { next(error); }
});


app.get('/api/agenda/client-lookup', requireAuth, async (req, res, next) => {
  try {
    const whatsapp = normalizeWhatsapp(req.query.whatsapp);
    if (!whatsapp) return res.status(400).json({ error: 'Informe o WhatsApp para buscar o cliente.' });
    const tutorResult = await query(`
      SELECT t.*,
             COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL)::int AS pets_count,
             COALESCE(MAX(a.starts_at), NULL) AS last_appointment_at
      FROM tutors t
      LEFT JOIN pets p ON p.tutor_id = t.id AND p.deleted_at IS NULL
      LEFT JOIN appointments a ON a.tutor_id = t.id AND a.deleted_at IS NULL
      WHERE t.whatsapp = $1::text
        AND t.deleted_at IS NULL
      GROUP BY t.id
      LIMIT 1
    `, [whatsapp]);
    const tutor = tutorResult.rows[0] || null;
    if (!tutor) return res.json({ found: false, whatsapp, tutor: null, pets: [] });
    const pets = await query(`
      SELECT p.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp
      FROM pets p
      INNER JOIN tutors t ON t.id = p.tutor_id
      WHERE p.tutor_id = $1::uuid
        AND p.deleted_at IS NULL
        AND p.status = 'active'
      ORDER BY p.name ASC
    `, [tutor.id]);
    res.json({ found: true, whatsapp, tutor: sanitizeTutor(tutor), pets: pets.rows.map(sanitizePet) });
  } catch (error) { next(error); }
});

app.get('/api/agenda/:id', requireAuth, async (req, res, next) => {
  try {
    const appointment = await getAppointmentById(req.params.id);
    if (!appointment) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    res.json({ appointment: sanitizeAppointment(appointment) });
  } catch (error) { next(error); }
});

app.post('/api/agenda', requireAuth, async (req, res, next) => {
  try {
    const tutorId = cleanText(req.body?.tutorId);
    const petId = cleanText(req.body?.petId);
    const collaboratorId = cleanText(req.body?.collaboratorId);
    const startsAt = toIsoOrNull(req.body?.startsAt);
    const status = cleanText(req.body?.status) || 'agendado';
    const discountPercent = Number(req.body?.discountPercent || 0);
    const paymentStatus = cleanText(req.body?.paymentStatus) || 'pending';
    const paymentMethodId = cleanText(req.body?.paymentMethodId);
    const serviceIds = Array.isArray(req.body?.serviceIds) ? req.body.serviceIds.filter(Boolean) : [];
    if (!tutorId) return res.status(400).json({ error: 'Selecione o tutor.' });
    if (!petId) return res.status(400).json({ error: 'Selecione o pet.' });
    if (!startsAt) return res.status(400).json({ error: 'Informe data e horário válidos.' });
    if (!serviceIds.length) return res.status(400).json({ error: 'Selecione ao menos um serviço.' });
    await assertSlotAvailable(req.body?.startsAt || startsAt, status, null);

    const services = await query(`SELECT id, name, price_cents, duration_minutes FROM services WHERE id = ANY($1::uuid[]) AND deleted_at IS NULL AND is_active = TRUE`, [serviceIds]);
    if (!services.rowCount) return res.status(400).json({ error: 'Nenhum serviço ativo encontrado para o agendamento.' });
    const duration = services.rows.reduce((sum, row) => sum + Number(row.duration_minutes || 60), 0);
    const endsAt = new Date(new Date(startsAt).getTime() + duration * 60000).toISOString();
    const items = services.rows.map((row) => ({ serviceId: row.id, description: row.name, quantity: 1, unitPriceCents: Number(row.price_cents || 0) }));
    const totals = centsFromServices(items, discountPercent);

    const created = await query(`
      INSERT INTO appointments (tutor_id, pet_id, collaborator_id, starts_at, ends_at, status, source, subtotal_cents, discount_percent, discount_cents, total_cents, notes, payment_status, payment_method_id)
      VALUES ($1::uuid, $2::uuid, NULLIF($3::text,'')::uuid, $4::timestamptz, $5::timestamptz, $6::text, 'manual', $7::integer, $8::numeric, $9::integer, $10::integer, $11::text, $12::text, NULLIF($13::text,'')::uuid)
      RETURNING id
    `, [tutorId, petId, collaboratorId || '', startsAt, endsAt, status, totals.subtotalCents, discountPercent, totals.discountCents, totals.totalCents, cleanText(req.body?.notes), paymentStatus, paymentMethodId || '']);

    for (const item of items) {
      await query(`
        INSERT INTO appointment_items (appointment_id, pet_id, service_id, description, quantity, unit_price_cents, discount_percent, total_cents)
        VALUES ($1::uuid, $2::uuid, $3::uuid, $4::text, $5::integer, $6::integer, 0, $7::integer)
      `, [created.rows[0].id, petId, item.serviceId, item.description, item.quantity, item.unitPriceCents, item.unitPriceCents]);
    }
    const appointment = await getAppointmentById(created.rows[0].id);
    res.status(201).json({ appointment: sanitizeAppointment(appointment), message: 'Agendamento criado com sucesso.' });
  } catch (error) { next(error); }
});

app.put('/api/agenda/:id', requireAuth, async (req, res, next) => {
  try {
    const current = await getAppointmentById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    const tutorId = cleanText(req.body?.tutorId);
    const petId = cleanText(req.body?.petId);
    const collaboratorId = cleanText(req.body?.collaboratorId);
    const startsAt = toIsoOrNull(req.body?.startsAt);
    const status = cleanText(req.body?.status) || current.status;
    const discountPercent = Number(req.body?.discountPercent || 0);
    const paymentStatus = cleanText(req.body?.paymentStatus) || current.payment_status || 'pending';
    const paymentMethodId = cleanText(req.body?.paymentMethodId);
    const serviceIds = Array.isArray(req.body?.serviceIds) ? req.body.serviceIds.filter(Boolean) : [];
    if (!tutorId || !petId || !startsAt || !serviceIds.length) return res.status(400).json({ error: 'Preencha tutor, pet, data/hora e serviços.' });
    await assertSlotAvailable(req.body?.startsAt || startsAt, status, req.params.id);

    const services = await query(`SELECT id, name, price_cents, duration_minutes FROM services WHERE id = ANY($1::uuid[]) AND deleted_at IS NULL AND is_active = TRUE`, [serviceIds]);
    const duration = services.rows.reduce((sum, row) => sum + Number(row.duration_minutes || 60), 0);
    const endsAt = new Date(new Date(startsAt).getTime() + duration * 60000).toISOString();
    const items = services.rows.map((row) => ({ serviceId: row.id, description: row.name, quantity: 1, unitPriceCents: Number(row.price_cents || 0) }));
    const totals = centsFromServices(items, discountPercent);

    await query(`
      UPDATE appointments
      SET tutor_id=$2::uuid, pet_id=$3::uuid, collaborator_id=NULLIF($4::text,'')::uuid, starts_at=$5::timestamptz, ends_at=$6::timestamptz, status=$7::text,
          subtotal_cents=$8::integer, discount_percent=$9::numeric, discount_cents=$10::integer, total_cents=$11::integer, notes=$12::text,
          payment_status=$13::text, payment_method_id=NULLIF($14::text,'')::uuid, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
    `, [req.params.id, tutorId, petId, collaboratorId || '', startsAt, endsAt, status, totals.subtotalCents, discountPercent, totals.discountCents, totals.totalCents, cleanText(req.body?.notes), paymentStatus, paymentMethodId || '']);
    await query('DELETE FROM appointment_items WHERE appointment_id = $1::uuid', [req.params.id]);
    for (const item of items) {
      await query(`INSERT INTO appointment_items (appointment_id, pet_id, service_id, description, quantity, unit_price_cents, discount_percent, total_cents) VALUES ($1::uuid,$2::uuid,$3::uuid,$4::text,$5::integer,$6::integer,0,$7::integer)`, [req.params.id, petId, item.serviceId, item.description, item.quantity, item.unitPriceCents, item.unitPriceCents]);
    }
    const appointment = await getAppointmentById(req.params.id);
    res.json({ appointment: sanitizeAppointment(appointment), message: 'Agendamento atualizado com sucesso.' });
  } catch (error) { next(error); }
});

app.patch('/api/agenda/:id/status', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.body?.status);
    if (!status) return res.status(400).json({ error: 'Informe o status.' });
    const exists = await query('SELECT code FROM appointment_statuses WHERE code=$1::text AND deleted_at IS NULL AND is_active=TRUE LIMIT 1', [status]);
    if (!exists.rowCount) return res.status(400).json({ error: 'Status inválido. Configure os status da agenda em Configurações.' });
    const result = await query(`
      UPDATE appointments
      SET status=$2::text,
          checked_in_at = CASE WHEN $2::text = 'em_atendimento' THEN COALESCE(checked_in_at, NOW()) ELSE checked_in_at END,
          checked_out_at = CASE WHEN $2::text = 'finalizado' THEN COALESCE(checked_out_at, NOW()) ELSE checked_out_at END,
          updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING id
    `, [req.params.id, status]);
    if (!result.rowCount) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    const appointment = await getAppointmentById(req.params.id);
    if (status === 'finalizado') await ensureFinancialTransactionForAppointment(req.params.id);
    res.json({ appointment: sanitizeAppointment(appointment), message: 'Status atualizado.' });
  } catch (error) { next(error); }
});


app.patch('/api/agenda/:id/reschedule', requireAuth, async (req, res, next) => {
  try {
    const current = await getAppointmentById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    const startsAt = toIsoOrNull(req.body?.startsAt);
    if (!startsAt) return res.status(400).json({ error: 'Informe a nova data e horário.' });
    await assertSlotAvailable(req.body?.startsAt || startsAt, current.status, req.params.id);
    const previousStart = current.starts_at ? new Date(current.starts_at) : null;
    const previousEnd = current.ends_at ? new Date(current.ends_at) : null;
    const durationMs = previousStart && previousEnd && previousEnd > previousStart ? previousEnd - previousStart : 60 * 60000;
    const endsAt = new Date(new Date(startsAt).getTime() + durationMs).toISOString();
    await query(`
      UPDATE appointments
      SET starts_at=$2::timestamptz, ends_at=$3::timestamptz, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
    `, [req.params.id, startsAt, endsAt]);
    const appointment = await getAppointmentById(req.params.id);
    res.json({ appointment: sanitizeAppointment(appointment), message: 'Agendamento reagendado com sucesso.' });
  } catch (error) { next(error); }
});

app.delete('/api/agenda/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE appointments SET deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    res.json({ ok: true, message: 'Agendamento removido.' });
  } catch (error) { next(error); }
});



function sanitizePackage(row = {}) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    sessionsCount: Number(row.sessions_count || 0),
    appointmentsPerMonth: Number(row.appointments_per_month || 0),
    discountPercent: Number(row.discount_percent || 0),
    priceCents: Number(row.price_cents || 0),
    isActive: Boolean(row.is_active),
    services: row.services || [],
    servicesText: row.services_text || '',
    customersCount: Number(row.customers_count || 0),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function sanitizeCustomerPackage(row = {}) {
  return {
    id: row.id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name,
    tutorWhatsapp: row.tutor_whatsapp,
    petId: row.pet_id,
    petName: row.pet_name,
    packageId: row.package_id,
    packageName: row.package_name,
    status: row.status,
    startsOn: row.starts_on,
    endsOn: row.ends_on,
    totalSessions: Number(row.total_sessions || 0),
    usedSessions: Number(row.used_sessions || 0),
    remainingSessions: Math.max(0, Number(row.total_sessions || 0) - Number(row.used_sessions || 0)),
    amountCents: Number(row.amount_cents || 0),
    paymentStatus: row.payment_status || 'pending',
    progressLabel: `${Number(row.used_sessions || 0)} de ${Number(row.total_sessions || 0)}`,
    recurrenceRule: row.recurrence_rule || {},
    createdAt: row.created_at
  };
}

function sanitizeSubscription(row = {}) {
  return {
    id: row.id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name,
    tutorWhatsapp: row.tutor_whatsapp,
    petId: row.pet_id,
    petName: row.pet_name,
    packageId: row.package_id,
    packageName: row.package_name,
    name: row.name,
    status: row.status,
    recurrence: row.recurrence,
    amountCents: Number(row.amount_cents || 0),
    startsOn: row.starts_on,
    nextBillingOn: row.next_billing_on,
    paymentMethod: row.payment_method,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}


function sanitizeFinancialTransaction(row = {}) {
  return {
    id: row.id,
    appointmentId: row.appointment_id,
    customerPackageId: row.customer_package_id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name,
    tutorWhatsapp: row.tutor_whatsapp,
    petName: row.pet_name,
    packageName: row.package_name,
    type: row.type,
    category: row.category,
    description: row.description,
    amountCents: Number(row.amount_cents || 0),
    dueDate: row.due_date,
    paidAt: row.paid_at,
    status: row.status,
    paymentMethodName: row.payment_method_name,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

async function getFinancialTransactionById(id) {
  const result = await query(`
    SELECT ft.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name,
           pk.name AS package_name, pm.name AS payment_method_name
    FROM financial_transactions ft
    LEFT JOIN tutors t ON t.id = ft.tutor_id
    LEFT JOIN appointments a ON a.id = ft.appointment_id
    LEFT JOIN pets p ON p.id = a.pet_id
    LEFT JOIN customer_packages cp ON cp.id = ft.customer_package_id
    LEFT JOIN packages pk ON pk.id = cp.package_id
    LEFT JOIN payments pay ON pay.financial_transaction_id = ft.id
    LEFT JOIN payment_methods pm ON pm.id = pay.payment_method_id
    WHERE ft.id = $1::uuid AND ft.deleted_at IS NULL
    ORDER BY pay.paid_at DESC NULLS LAST
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}

async function getPackageById(id) {
  const result = await query(`
    SELECT p.*,
           COALESCE(json_agg(json_build_object('serviceId', pi.service_id, 'serviceName', s.name, 'quantity', pi.quantity, 'priceCents', s.price_cents, 'petSize', s.pet_size) ORDER BY s.name) FILTER (WHERE pi.id IS NOT NULL), '[]'::json) AS services,
           COALESCE(string_agg(s.name, ', ' ORDER BY s.name), '') AS services_text,
           COUNT(DISTINCT cp.id) FILTER (WHERE cp.deleted_at IS NULL) AS customers_count
    FROM packages p
    LEFT JOIN package_items pi ON pi.package_id = p.id
    LEFT JOIN services s ON s.id = pi.service_id
    LEFT JOIN customer_packages cp ON cp.package_id = p.id
    WHERE p.id = $1::uuid AND p.deleted_at IS NULL
    GROUP BY p.id
    LIMIT 1
  `, [id]);
  return result.rows[0] || null;
}

app.get('/api/pacotes/options', requireAuth, async (req, res, next) => {
  try {
    const services = await query(`
      SELECT s.id, s.name, s.price_cents, s.duration_minutes, s.pet_size, ps.name AS pet_size_name, sc.name AS category_name
      FROM services s
      LEFT JOIN pet_sizes ps ON ps.code = s.pet_size
      LEFT JOIN service_categories sc ON sc.id = s.category_id
      WHERE s.deleted_at IS NULL AND s.is_active = TRUE
      ORDER BY sc.sort_order ASC NULLS LAST, s.name ASC
    `);
    const tutors = await query(`
      SELECT id, name, whatsapp FROM tutors
      WHERE deleted_at IS NULL AND status = 'active'
      ORDER BY name ASC
      LIMIT 300
    `);
    const pets = await query(`
      SELECT p.id, p.name, p.tutor_id, p.size, ps.name AS size_name
      FROM pets p
      LEFT JOIN pet_sizes ps ON ps.code = p.size
      WHERE p.deleted_at IS NULL AND p.status = 'active'
      ORDER BY p.name ASC
      LIMIT 500
    `);
    const packages = await query(`
      SELECT id, name, sessions_count, appointments_per_month, price_cents, discount_percent
      FROM packages
      WHERE deleted_at IS NULL AND is_active = TRUE
      ORDER BY name ASC
    `);
    res.json({
      services: services.rows.map((row) => ({ id: row.id, name: row.name, priceCents: Number(row.price_cents || 0), durationMinutes: Number(row.duration_minutes || 0), petSize: row.pet_size, petSizeName: row.pet_size_name, categoryName: row.category_name })),
      tutors: tutors.rows.map((row) => ({ id: row.id, name: row.name, whatsapp: row.whatsapp })),
      pets: pets.rows.map((row) => ({ id: row.id, name: row.name, tutorId: row.tutor_id, size: row.size, sizeName: row.size_name })),
      packages: packages.rows.map((row) => ({ id: row.id, name: row.name, sessionsCount: Number(row.sessions_count || 0), appointmentsPerMonth: Number(row.appointments_per_month || 0), priceCents: Number(row.price_cents || 0), discountPercent: Number(row.discount_percent || 0) }))
    });
  } catch (error) { next(error); }
});

app.get('/api/pacotes', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const status = cleanText(req.query.status) || 'active';
    const params = [];
    const where = ['p.deleted_at IS NULL'];
    if (status !== 'all') {
      params.push(status === 'active');
      where.push(`p.is_active = $${params.length}::boolean`);
    }
    if (search) {
      params.push(`%${search.replace(/\s+/g, '%')}%`);
      where.push(`(unaccent(lower(p.name)) ILIKE unaccent(lower($${params.length})) OR unaccent(lower(COALESCE(p.description,''))) ILIKE unaccent(lower($${params.length})))`);
    }
    const result = await query(`
      SELECT p.*,
             COALESCE(json_agg(json_build_object('serviceId', pi.service_id, 'serviceName', s.name, 'quantity', pi.quantity, 'priceCents', s.price_cents, 'petSize', s.pet_size) ORDER BY s.name) FILTER (WHERE pi.id IS NOT NULL), '[]'::json) AS services,
             COALESCE(string_agg(s.name, ', ' ORDER BY s.name), '') AS services_text,
             COUNT(DISTINCT cp.id) FILTER (WHERE cp.deleted_at IS NULL) AS customers_count
      FROM packages p
      LEFT JOIN package_items pi ON pi.package_id = p.id
      LEFT JOIN services s ON s.id = pi.service_id
      LEFT JOIN customer_packages cp ON cp.package_id = p.id
      WHERE ${where.join(' AND ')}
      GROUP BY p.id
      ORDER BY p.is_active DESC, p.updated_at DESC, p.name ASC
      LIMIT 150
    `, params);
    const summary = await query(`
      SELECT COUNT(*) FILTER (WHERE deleted_at IS NULL)::int AS total,
             COUNT(*) FILTER (WHERE deleted_at IS NULL AND is_active = TRUE)::int AS active,
             COALESCE(SUM(price_cents) FILTER (WHERE deleted_at IS NULL AND is_active = TRUE),0)::int AS portfolio_cents
      FROM packages
    `);
    res.json({ items: result.rows.map(sanitizePackage), summary: summary.rows[0] || {} });
  } catch (error) { next(error); }
});

app.get('/api/pacotes/clientes', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.query.status) || 'active';
    const params = [];
    const where = ['cp.deleted_at IS NULL'];
    if (status !== 'all') {
      params.push(status);
      where.push(`cp.status = $${params.length}::text`);
    }
    const result = await query(`
      SELECT cp.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, pt.name AS pet_name, p.name AS package_name
      FROM customer_packages cp
      INNER JOIN tutors t ON t.id = cp.tutor_id
      LEFT JOIN pets pt ON pt.id = cp.pet_id
      INNER JOIN packages p ON p.id = cp.package_id
      WHERE ${where.join(' AND ')}
      ORDER BY cp.created_at DESC
      LIMIT 200
    `, params);
    res.json({ items: result.rows.map(sanitizeCustomerPackage) });
  } catch (error) { next(error); }
});

app.post('/api/pacotes', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    const description = cleanText(req.body?.description);
    const sessionsCount = Math.max(1, Number.parseInt(req.body?.sessionsCount || '4', 10));
    const appointmentsPerMonth = Math.max(1, Number.parseInt(req.body?.appointmentsPerMonth || '4', 10));
    const discountPercent = Math.max(0, Math.min(100, Number(req.body?.discountPercent || 0)));
    const priceCents = moneyToCents(req.body?.priceCents ?? req.body?.price);
    const serviceItems = Array.isArray(req.body?.services) ? req.body.services : [];
    if (!name) return res.status(400).json({ error: 'Informe o nome do pacote.' });
    if (!serviceItems.length) return res.status(400).json({ error: 'Selecione ao menos um serviço para o pacote.' });
    await query('BEGIN');
    const created = await query(`
      INSERT INTO packages (name, description, sessions_count, appointments_per_month, discount_percent, price_cents, is_active)
      VALUES ($1::text, $2::text, $3::integer, $4::integer, $5::numeric, $6::integer, $7::boolean)
      ON CONFLICT (name) DO UPDATE
      SET description=EXCLUDED.description, sessions_count=EXCLUDED.sessions_count, appointments_per_month=EXCLUDED.appointments_per_month,
          discount_percent=EXCLUDED.discount_percent, price_cents=EXCLUDED.price_cents, is_active=EXCLUDED.is_active, deleted_at=NULL, updated_at=NOW()
      RETURNING id
    `, [name, description, sessionsCount, appointmentsPerMonth, discountPercent, priceCents, parseBool(req.body?.isActive, true)]);
    const packageId = created.rows[0].id;
    await query('DELETE FROM package_items WHERE package_id = $1::uuid', [packageId]);
    for (const item of serviceItems) {
      const serviceId = cleanText(item.serviceId || item.id);
      const quantity = Math.max(1, Number.parseInt(item.quantity || '1', 10));
      if (!serviceId) continue;
      await query(`INSERT INTO package_items (package_id, service_id, quantity) VALUES ($1::uuid, $2::uuid, $3::integer) ON CONFLICT (package_id, service_id) DO UPDATE SET quantity = EXCLUDED.quantity, updated_at = NOW()`, [packageId, serviceId, quantity]);
    }
    await query('COMMIT');
    const pack = await getPackageById(packageId);
    res.status(201).json({ package: sanitizePackage(pack), message: 'Pacote salvo com sucesso.' });
  } catch (error) { try { await query('ROLLBACK'); } catch {} next(error); }
});

app.put('/api/pacotes/:id', requireAuth, async (req, res, next) => {
  try {
    const current = await getPackageById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Pacote não encontrado.' });
    const name = cleanText(req.body?.name);
    const serviceItems = Array.isArray(req.body?.services) ? req.body.services : [];
    if (!name) return res.status(400).json({ error: 'Informe o nome do pacote.' });
    await query('BEGIN');
    await query(`
      UPDATE packages
      SET name=$2::text, description=$3::text, sessions_count=$4::integer, appointments_per_month=$5::integer, discount_percent=$6::numeric, price_cents=$7::integer, is_active=$8::boolean, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
    `, [req.params.id, name, cleanText(req.body?.description), Math.max(1, Number.parseInt(req.body?.sessionsCount || '4', 10)), Math.max(1, Number.parseInt(req.body?.appointmentsPerMonth || '4', 10)), Math.max(0, Math.min(100, Number(req.body?.discountPercent || 0))), moneyToCents(req.body?.priceCents ?? req.body?.price), parseBool(req.body?.isActive, true)]);
    await query('DELETE FROM package_items WHERE package_id = $1::uuid', [req.params.id]);
    for (const item of serviceItems) {
      const serviceId = cleanText(item.serviceId || item.id);
      const quantity = Math.max(1, Number.parseInt(item.quantity || '1', 10));
      if (!serviceId) continue;
      await query(`INSERT INTO package_items (package_id, service_id, quantity) VALUES ($1::uuid, $2::uuid, $3::integer) ON CONFLICT (package_id, service_id) DO UPDATE SET quantity = EXCLUDED.quantity, updated_at = NOW()`, [req.params.id, serviceId, quantity]);
    }
    await query('COMMIT');
    const pack = await getPackageById(req.params.id);
    res.json({ package: sanitizePackage(pack), message: 'Pacote atualizado.' });
  } catch (error) { try { await query('ROLLBACK'); } catch {} next(error); }
});

app.delete('/api/pacotes/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE packages SET is_active=FALSE, deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Pacote não encontrado.' });
    res.json({ ok: true, message: 'Pacote inativado.' });
  } catch (error) { next(error); }
});

app.post('/api/pacotes/clientes', requireAuth, async (req, res, next) => {
  try {
    const tutorId = cleanText(req.body?.tutorId);
    const petId = cleanText(req.body?.petId);
    const packageId = cleanText(req.body?.packageId);
    const startsOn = cleanText(req.body?.startsOn) || new Date().toISOString().slice(0, 10);
    const firstTime = cleanText(req.body?.firstTime) || '09:00';
    const generateAppointments = parseBool(req.body?.generateAppointments, true);
    if (!tutorId || !packageId) return res.status(400).json({ error: 'Selecione tutor e pacote.' });
    const pack = await query('SELECT * FROM packages WHERE id=$1::uuid AND deleted_at IS NULL AND is_active=TRUE LIMIT 1', [packageId]);
    if (!pack.rowCount) return res.status(404).json({ error: 'Pacote ativo não encontrado.' });
    const packageRow = pack.rows[0];
    const intervalDays = Number(packageRow.appointments_per_month || 4) >= 4 ? 7 : 15;
    await query('BEGIN');
    const sold = await query(`
      INSERT INTO customer_packages (tutor_id, pet_id, package_id, status, starts_on, ends_on, total_sessions, used_sessions, amount_cents, payment_status, recurrence_rule)
      VALUES ($1::uuid, NULLIF($2::text,'')::uuid, $3::uuid, 'active', $4::date, ($4::date + (($5::integer - 1) * $6::integer || ' days')::interval)::date, $5::integer, 0, $7::integer, $8::text, jsonb_build_object('appointmentsPerMonth', $9::integer, 'intervalDays', $6::integer))
      RETURNING *
    `, [tutorId, petId || '', packageId, startsOn, Number(packageRow.sessions_count || 1), intervalDays, Number(packageRow.price_cents || 0), cleanText(req.body?.paymentStatus) || 'pending', Number(packageRow.appointments_per_month || 4)]);
    await query(`
      INSERT INTO financial_transactions (tutor_id, customer_package_id, type, category, description, amount_cents, due_date, status)
      VALUES ($1::uuid, $2::uuid, 'income', 'pacote', $3::text, $4::integer, $5::date, $6::text)
      ON CONFLICT DO NOTHING
    `, [tutorId, sold.rows[0].id, `Pacote ${packageRow.name}`, Number(packageRow.price_cents || 0), startsOn, cleanText(req.body?.paymentStatus) === 'paid' ? 'paid' : 'pending']);

    if (generateAppointments && petId) {
      const services = await query(`
        SELECT s.id, s.name, s.price_cents, s.duration_minutes
        FROM package_items pi
        INNER JOIN services s ON s.id = pi.service_id
        WHERE pi.package_id = $1::uuid AND s.deleted_at IS NULL
        ORDER BY s.name ASC
      `, [packageId]);
      const duration = Math.max(60, services.rows.reduce((sum, row) => sum + Number(row.duration_minutes || 60), 0));
      for (let i = 0; i < Number(packageRow.sessions_count || 1); i += 1) {
        const appointmentDate = new Date(`${startsOn}T${firstTime}:00`);
        appointmentDate.setDate(appointmentDate.getDate() + (i + 1) * intervalDays);
        const startsAt = appointmentDate.toISOString();
        const endsAt = new Date(appointmentDate.getTime() + duration * 60000).toISOString();
        const subtotal = services.rows.reduce((sum, row) => sum + Number(row.price_cents || 0), 0);
        const discount = Math.round(subtotal * Number(packageRow.discount_percent || 0) / 100);
        const total = Math.max(0, subtotal - discount);
        const appt = await query(`
          INSERT INTO appointments (tutor_id, pet_id, starts_at, ends_at, status, source, subtotal_cents, discount_percent, discount_cents, total_cents, package_session_label, notes)
          VALUES ($1::uuid, $2::uuid, $3::timestamptz, $4::timestamptz, 'agendado', 'package', $5::integer, $6::numeric, $7::integer, $8::integer, $9::text, $10::text)
          RETURNING id
        `, [tutorId, petId, startsAt, endsAt, subtotal, Number(packageRow.discount_percent || 0), discount, total, `${i + 1} de ${Number(packageRow.sessions_count || 1)}`, `Gerado automaticamente pelo pacote ${packageRow.name}. Cobrança do pacote registrada no Financeiro pelo valor total de ${(Number(packageRow.price_cents || 0) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}.`]);
        for (const service of services.rows) {
          await query(`INSERT INTO appointment_items (appointment_id, pet_id, service_id, description, quantity, unit_price_cents, discount_percent, total_cents) VALUES ($1::uuid,$2::uuid,$3::uuid,$4::text,1,$5::integer,0,$5::integer)`, [appt.rows[0].id, petId, service.id, service.name, Number(service.price_cents || 0)]);
        }
      }
    }
    await query('COMMIT');
    res.status(201).json({ customerPackage: sanitizeCustomerPackage({ ...sold.rows[0], package_name: packageRow.name }), message: generateAppointments ? 'Pacote vendido e agenda gerada.' : 'Pacote vendido com sucesso.' });
  } catch (error) { try { await query('ROLLBACK'); } catch {} next(error); }
});

app.patch('/api/pacotes/clientes/:id/status', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.body?.status) || 'active';
    const result = await query(`UPDATE customer_packages SET status=$2::text, updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING *`, [req.params.id, status]);
    if (!result.rowCount) return res.status(404).json({ error: 'Pacote do cliente não encontrado.' });
    res.json({ item: sanitizeCustomerPackage(result.rows[0]), message: 'Status do pacote atualizado.' });
  } catch (error) { next(error); }
});

app.get('/api/assinaturas', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.query.status) || 'all';
    const params = [];
    const where = ['s.deleted_at IS NULL'];
    if (status !== 'all') { params.push(status); where.push(`s.status = $${params.length}::text`); }
    const result = await query(`
      SELECT s.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, pk.name AS package_name
      FROM subscriptions s
      INNER JOIN tutors t ON t.id = s.tutor_id
      LEFT JOIN pets p ON p.id = s.pet_id
      LEFT JOIN packages pk ON pk.id = s.package_id
      WHERE ${where.join(' AND ')}
      ORDER BY s.status = 'active' DESC, s.next_billing_on ASC NULLS LAST, s.created_at DESC
      LIMIT 200
    `, params);
    const summary = await query(`
      SELECT COUNT(*) FILTER (WHERE deleted_at IS NULL)::int AS total,
             COUNT(*) FILTER (WHERE deleted_at IS NULL AND status='active')::int AS active,
             COALESCE(SUM(amount_cents) FILTER (WHERE deleted_at IS NULL AND status='active'),0)::int AS monthly_recurring_cents
      FROM subscriptions
    `);
    res.json({ items: result.rows.map(sanitizeSubscription), summary: summary.rows[0] || {} });
  } catch (error) { next(error); }
});

app.post('/api/assinaturas', requireAuth, async (req, res, next) => {
  try {
    const tutorId = cleanText(req.body?.tutorId);
    const petId = cleanText(req.body?.petId);
    const packageId = cleanText(req.body?.packageId);
    const name = cleanText(req.body?.name);
    if (!tutorId || !name) return res.status(400).json({ error: 'Informe tutor e nome da assinatura.' });
    const amountCents = moneyToCents(req.body?.amountCents ?? req.body?.amount);
    const result = await query(`
      INSERT INTO subscriptions (tutor_id, pet_id, package_id, name, status, recurrence, amount_cents, starts_on, next_billing_on, payment_method, notes)
      VALUES ($1::uuid, NULLIF($2::text,'')::uuid, NULLIF($3::text,'')::uuid, $4::text, $5::text, $6::text, $7::integer, $8::date, NULLIF($9::text,'')::date, $10::text, $11::text)
      RETURNING *
    `, [tutorId, petId || '', packageId || '', name, cleanText(req.body?.status) || 'active', cleanText(req.body?.recurrence) || 'monthly', amountCents, cleanText(req.body?.startsOn) || new Date().toISOString().slice(0,10), cleanText(req.body?.nextBillingOn) || '', cleanText(req.body?.paymentMethod), cleanText(req.body?.notes)]);
    res.status(201).json({ subscription: sanitizeSubscription(result.rows[0]), message: 'Assinatura criada.' });
  } catch (error) { next(error); }
});

app.put('/api/assinaturas/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      UPDATE subscriptions
      SET name=$2::text, status=$3::text, recurrence=$4::text, amount_cents=$5::integer, starts_on=$6::date, next_billing_on=NULLIF($7::text,'')::date, payment_method=$8::text, notes=$9::text, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING *
    `, [req.params.id, cleanText(req.body?.name), cleanText(req.body?.status) || 'active', cleanText(req.body?.recurrence) || 'monthly', moneyToCents(req.body?.amountCents ?? req.body?.amount), cleanText(req.body?.startsOn) || new Date().toISOString().slice(0,10), cleanText(req.body?.nextBillingOn) || '', cleanText(req.body?.paymentMethod), cleanText(req.body?.notes)]);
    if (!result.rowCount) return res.status(404).json({ error: 'Assinatura não encontrada.' });
    res.json({ subscription: sanitizeSubscription(result.rows[0]), message: 'Assinatura atualizada.' });
  } catch (error) { next(error); }
});

app.delete('/api/assinaturas/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE subscriptions SET status='canceled', deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Assinatura não encontrada.' });
    res.json({ ok: true, message: 'Assinatura cancelada.' });
  } catch (error) { next(error); }
});



function buildDocumentNumber(prefix = 'REC') {
  const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  return `${prefix}-${stamp}-${Math.random().toString(16).slice(2, 6).toUpperCase()}`;
}

function normalizeReceiptPayload(row = {}) {
  return {
    id: row.id,
    appointmentId: row.appointment_id,
    paymentId: row.payment_id,
    publicToken: row.public_token,
    documentNumber: row.document_number,
    subtotalCents: Number(row.subtotal_cents || 0),
    discountCents: Number(row.discount_cents || 0),
    totalCents: Number(row.total_cents || 0),
    payload: row.payload || {},
    issuedAt: row.issued_at,
    publicUrl: row.public_token ? `/public/recibos/${row.public_token}` : null,
    printUrl: row.public_token ? `/documentos/recibo/${row.public_token}` : null
  };
}

async function getBusinessDocumentPayload() {
  const fallback = {
    name: 'PetFunny - Banho e Tosa',
    legalName: 'PetFunny - Banho e Tosa',
    document: '',
    whatsapp: '5516981535338',
    city: 'Ribeirão Preto',
    state: 'SP',
    address: '',
    email: '',
    instagram: ''
  };

  try {
    const result = await query(`
      SELECT *
      FROM business_settings
      ORDER BY created_at ASC
      LIMIT 1
    `);

    const row = result.rows[0];
    if (!row) return fallback;

    const addressParts = [
      row.address_street,
      row.address_number,
      row.address_neighborhood,
      row.address_city,
      row.address_state
    ].filter(Boolean);

    return {
      name: row.business_name || fallback.name,
      legalName: row.legal_name || row.business_name || fallback.legalName,
      document: row.document_number || fallback.document,
      whatsapp: row.whatsapp || fallback.whatsapp,
      city: row.address_city || fallback.city,
      state: row.address_state || fallback.state,
      address: addressParts.length ? addressParts.join(', ') : fallback.address,
      email: row.email || fallback.email,
      instagram: row.instagram_url || cleanJsonObject(row.social_links).instagram || fallback.instagram
    };
  } catch (error) {
    console.warn('[documentos] falha ao carregar business_settings; usando fallback PetFunny:', error.message);
    return fallback;
  }
}

async function getAppointmentDocumentData(appointmentId) {
  const appointment = await getAppointmentById(appointmentId);
  if (!appointment) return null;
  const business = await getBusinessDocumentPayload();
  const finance = await query(`
    SELECT ft.*, pay.id AS payment_id, pay.paid_at AS payment_paid_at, pay.amount_cents AS payment_amount_cents, pm.name AS payment_method_name
    FROM financial_transactions ft
    LEFT JOIN payments pay ON pay.financial_transaction_id = ft.id
    LEFT JOIN payment_methods pm ON pm.id = pay.payment_method_id
    WHERE ft.appointment_id = $1::uuid AND ft.deleted_at IS NULL
    ORDER BY pay.paid_at DESC NULLS LAST, ft.created_at DESC
    LIMIT 1
  `, [appointmentId]);
  const payment = finance.rows[0] || null;
  return {
    business,
    appointment: sanitizeAppointment(appointment),
    payment: payment ? sanitizeFinancialTransaction(payment) : null,
    paymentRaw: payment,
    totals: {
      subtotalCents: Number(appointment.subtotal_cents || 0),
      discountPercent: Number(appointment.discount_percent || 0),
      discountCents: Number(appointment.discount_cents || 0),
      totalCents: Number(appointment.total_cents || 0)
    }
  };
}

async function ensureFinancialTransactionForAppointment(appointmentId) {
  const appointment = await getAppointmentById(appointmentId);
  if (!appointment) return null;
  if (Number(appointment.total_cents || 0) <= 0) return null;
  const existing = await query(`
    SELECT id FROM financial_transactions
    WHERE appointment_id=$1::uuid AND deleted_at IS NULL AND type='income'
    ORDER BY created_at DESC
    LIMIT 1
  `, [appointmentId]);
  if (existing.rowCount) return getFinancialTransactionById(existing.rows[0].id);
  const inserted = await query(`
    INSERT INTO financial_transactions (appointment_id, tutor_id, type, category, description, amount_cents, due_date, status)
    VALUES ($1::uuid, $2::uuid, 'income', 'atendimento', $3::text, $4::integer, CURRENT_DATE, 'pending')
    RETURNING id
  `, [appointmentId, appointment.tutor_id, `Atendimento ${appointment.pet_name || ''}`.trim(), Number(appointment.total_cents || 0)]);
  return getFinancialTransactionById(inserted.rows[0].id);
}

async function createOrUpdateReceiptForAppointment(appointmentId, paymentId = null) {
  const data = await getAppointmentDocumentData(appointmentId);
  if (!data) return null;
  const payload = {
    type: 'receipt',
    business: data.business,
    appointment: data.appointment,
    payment: data.payment,
    totals: data.totals,
    generatedAt: new Date().toISOString()
  };
  const existing = await query('SELECT * FROM receipts WHERE appointment_id=$1::uuid ORDER BY issued_at DESC LIMIT 1', [appointmentId]);
  if (existing.rowCount) {
    const updated = await query(`
      UPDATE receipts
      SET payment_id = COALESCE(NULLIF($2::text,'')::uuid, payment_id), subtotal_cents=$3::integer, discount_cents=$4::integer, total_cents=$5::integer, payload=$6::jsonb, updated_at=NOW()
      WHERE id=$1::uuid
      RETURNING *
    `, [existing.rows[0].id, paymentId || '', data.totals.subtotalCents, data.totals.discountCents, data.totals.totalCents, JSON.stringify(payload)]);
    return normalizeReceiptPayload(updated.rows[0]);
  }
  const created = await query(`
    INSERT INTO receipts (appointment_id, payment_id, document_number, subtotal_cents, discount_cents, total_cents, payload)
    VALUES ($1::uuid, NULLIF($2::text,'')::uuid, $3::text, $4::integer, $5::integer, $6::integer, $7::jsonb)
    RETURNING *
  `, [appointmentId, paymentId || '', buildDocumentNumber('REC'), data.totals.subtotalCents, data.totals.discountCents, data.totals.totalCents, JSON.stringify(payload)]);
  return normalizeReceiptPayload(created.rows[0]);
}

app.get('/api/documentos/appointments', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const params = [];
    const where = ['a.deleted_at IS NULL'];
    if (search) {
      params.push(`%${search}%`);
      where.push(`(t.name ILIKE $${params.length} OR p.name ILIKE $${params.length} OR t.whatsapp ILIKE $${params.length})`);
    }
    const result = await query(`
      SELECT a.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, p.size AS pet_size,
             s.name AS status_name, s.color AS status_color,
             COALESCE(string_agg(ai.description, ', ' ORDER BY ai.created_at), '') AS services,
             ft.status AS financial_status,
             r.public_token AS receipt_token,
             r.document_number AS receipt_number
      FROM appointments a
      LEFT JOIN tutors t ON t.id = a.tutor_id
      LEFT JOIN pets p ON p.id = a.pet_id
      LEFT JOIN appointment_statuses s ON s.code = a.status
    LEFT JOIN payment_methods pm ON pm.id = a.payment_method_id
      LEFT JOIN appointment_items ai ON ai.appointment_id = a.id
      LEFT JOIN financial_transactions ft ON ft.appointment_id = a.id AND ft.deleted_at IS NULL
      LEFT JOIN receipts r ON r.appointment_id = a.id
      WHERE ${where.join(' AND ')}
      GROUP BY a.id, t.name, t.whatsapp, p.name, p.size, s.name, s.color, ft.status, r.public_token, r.document_number
      ORDER BY a.starts_at DESC
      LIMIT 120
    `, params);
    res.json({ items: result.rows.map((row) => ({
      ...sanitizeAppointment(row),
      financialStatus: row.financial_status || null,
      receiptToken: row.receipt_token || null,
      receiptNumber: row.receipt_number || null
    })) });
  } catch (error) { next(error); }
});

app.get('/api/documentos/comanda/:appointmentId', requireAuth, async (req, res, next) => {
  try {
    const data = await getAppointmentDocumentData(req.params.appointmentId);
    if (!data) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    res.json({ document: { type: 'command', ...data, publicUrl: `/documentos/comanda/${req.params.appointmentId}` } });
  } catch (error) { next(error); }
});

app.post('/api/documentos/recibos/:appointmentId/generate', requireAuth, async (req, res, next) => {
  try {
    const finance = await ensureFinancialTransactionForAppointment(req.params.appointmentId);
    const receipt = await createOrUpdateReceiptForAppointment(req.params.appointmentId, null);
    if (!receipt) return res.status(404).json({ error: 'Agendamento não encontrado.' });
    res.status(201).json({ receipt, financialTransaction: finance ? sanitizeFinancialTransaction(finance) : null, message: 'Recibo preparado.' });
  } catch (error) { next(error); }
});

app.get('/api/public/recibos/:token', async (req, res, next) => {
  try {
    const result = await query('SELECT * FROM receipts WHERE public_token=$1::text LIMIT 1', [req.params.token]);
    if (!result.rowCount) return res.status(404).json({ error: 'Recibo não encontrado.' });
    res.json({ receipt: normalizeReceiptPayload(result.rows[0]) });
  } catch (error) { next(error); }
});



function sanitizeCrmLead(row = {}) {
  return {
    id: row.id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name || null,
    name: row.name,
    whatsapp: row.whatsapp,
    email: row.email,
    stage: row.stage,
    source: row.source,
    lastContactAt: row.last_contact_at,
    notes: row.notes,
    interactionsCount: Number(row.interactions_count || 0),
    petsCount: Number(row.pets_count || 0),
    lastAppointmentAt: row.last_appointment_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function sanitizeCrmInteraction(row = {}) {
  return {
    id: row.id,
    leadId: row.lead_id,
    tutorId: row.tutor_id,
    channel: row.channel,
    direction: row.direction,
    subject: row.subject,
    message: row.message,
    occurredAt: row.occurred_at,
    createdAt: row.created_at
  };
}

const CRM_STAGES = [
  { code: 'lead_entrou', name: 'Lead entrou', color: '#00a9b7' },
  { code: 'diagnostico_enviado', name: 'Diagnóstico enviado', color: '#7c3aed' },
  { code: 'conversa_iniciada', name: 'Conversa iniciada', color: '#ff9d98' },
  { code: 'proposta_enviada', name: 'Proposta enviada', color: '#f59e0b' },
  { code: 'fechado', name: 'Fechado', color: '#12a876' },
  { code: 'perdido', name: 'Perdido', color: '#94a3b8' }
];

app.get('/api/crm/options', requireAuth, async (req, res, next) => {
  try {
    const tutors = await query(`
      SELECT id, name, whatsapp, email
      FROM tutors
      WHERE deleted_at IS NULL
      ORDER BY name ASC
      LIMIT 500
    `);
    res.json({
      stages: CRM_STAGES,
      sources: ['manual','whatsapp','instagram','landing_page','indicacao','google','cliente_inativo'],
      channels: ['whatsapp','telefone','instagram','email','presencial'],
      tutors: tutors.rows.map(sanitizeTutor)
    });
  } catch (error) { next(error); }
});

app.get('/api/crm/summary', requireAuth, async (req, res, next) => {
  try {
    const summary = await query(`
      SELECT
        COUNT(*) FILTER (WHERE deleted_at IS NULL)::int AS total_leads,
        COUNT(*) FILTER (WHERE deleted_at IS NULL AND stage = 'fechado')::int AS closed_leads,
        COUNT(*) FILTER (WHERE deleted_at IS NULL AND stage NOT IN ('fechado','perdido'))::int AS open_leads,
        COUNT(*) FILTER (WHERE deleted_at IS NULL AND (last_contact_at IS NULL OR last_contact_at < NOW() - INTERVAL '7 days'))::int AS without_recent_contact
      FROM crm_leads
    `);
    const byStage = await query(`
      SELECT stage, COUNT(*)::int AS count
      FROM crm_leads
      WHERE deleted_at IS NULL
      GROUP BY stage
    `);
    const inactiveCustomers = await query(`
      SELECT t.id, t.name, t.whatsapp, MAX(a.starts_at) AS last_appointment_at, COUNT(p.id)::int AS pets_count
      FROM tutors t
      LEFT JOIN pets p ON p.tutor_id = t.id AND p.deleted_at IS NULL
      LEFT JOIN appointments a ON a.tutor_id = t.id AND a.deleted_at IS NULL
      WHERE t.deleted_at IS NULL
      GROUP BY t.id
      HAVING MAX(a.starts_at) IS NULL OR MAX(a.starts_at) < NOW() - INTERVAL '45 days'
      ORDER BY last_appointment_at ASC NULLS FIRST, t.name ASC
      LIMIT 20
    `);
    const stageMap = Object.fromEntries(byStage.rows.map((row) => [row.stage, Number(row.count || 0)]));
    res.json({
      summary: summary.rows[0] || {},
      stages: CRM_STAGES.map((stage) => ({ ...stage, count: stageMap[stage.code] || 0 })),
      inactiveCustomers: inactiveCustomers.rows.map((row) => ({
        id: row.id,
        name: row.name,
        whatsapp: row.whatsapp,
        lastAppointmentAt: row.last_appointment_at,
        petsCount: Number(row.pets_count || 0)
      }))
    });
  } catch (error) { next(error); }
});

app.get('/api/crm/leads', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const stage = cleanText(req.query.stage) || 'all';
    const source = cleanText(req.query.source) || 'all';
    const params = [];
    const where = ['cl.deleted_at IS NULL'];
    if (stage !== 'all') { params.push(stage); where.push(`cl.stage = $${params.length}::text`); }
    if (source !== 'all') { params.push(source); where.push(`cl.source = $${params.length}::text`); }
    if (search) {
      params.push(`%${search}%`);
      where.push(`(cl.name ILIKE $${params.length} OR cl.whatsapp ILIKE $${params.length} OR cl.email ILIKE $${params.length} OR t.name ILIKE $${params.length})`);
    }
    const result = await query(`
      SELECT cl.*, t.name AS tutor_name,
             COUNT(ci.id)::int AS interactions_count,
             COUNT(DISTINCT p.id)::int AS pets_count,
             MAX(a.starts_at) AS last_appointment_at
      FROM crm_leads cl
      LEFT JOIN tutors t ON t.id = cl.tutor_id
      LEFT JOIN crm_interactions ci ON ci.lead_id = cl.id
      LEFT JOIN pets p ON p.tutor_id = cl.tutor_id AND p.deleted_at IS NULL
      LEFT JOIN appointments a ON a.tutor_id = cl.tutor_id AND a.deleted_at IS NULL
      WHERE ${where.join(' AND ')}
      GROUP BY cl.id, t.name
      ORDER BY cl.updated_at DESC, cl.created_at DESC
      LIMIT 200
    `, params);
    res.json({ items: result.rows.map(sanitizeCrmLead) });
  } catch (error) { next(error); }
});

app.post('/api/crm/leads', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do lead.' });
    const result = await query(`
      INSERT INTO crm_leads (tutor_id, name, whatsapp, email, stage, source, last_contact_at, notes)
      VALUES (NULLIF($1::text,'')::uuid, $2::text, $3::text, $4::text, $5::text, $6::text, NULLIF($7::text,'')::timestamptz, $8::text)
      RETURNING *
    `, [cleanText(req.body?.tutorId) || '', name, normalizeWhatsapp(req.body?.whatsapp), cleanText(req.body?.email), cleanText(req.body?.stage) || 'lead_entrou', cleanText(req.body?.source) || 'manual', cleanText(req.body?.lastContactAt) || '', cleanText(req.body?.notes)]);
    res.status(201).json({ lead: sanitizeCrmLead(result.rows[0]), message: 'Lead criado.' });
  } catch (error) { next(error); }
});

app.put('/api/crm/leads/:id', requireAuth, async (req, res, next) => {
  try {
    const name = cleanText(req.body?.name);
    if (!name) return res.status(400).json({ error: 'Informe o nome do lead.' });
    const result = await query(`
      UPDATE crm_leads
      SET tutor_id=NULLIF($2::text,'')::uuid, name=$3::text, whatsapp=$4::text, email=$5::text, stage=$6::text, source=$7::text,
          last_contact_at=NULLIF($8::text,'')::timestamptz, notes=$9::text, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING *
    `, [req.params.id, cleanText(req.body?.tutorId) || '', name, normalizeWhatsapp(req.body?.whatsapp), cleanText(req.body?.email), cleanText(req.body?.stage) || 'lead_entrou', cleanText(req.body?.source) || 'manual', cleanText(req.body?.lastContactAt) || '', cleanText(req.body?.notes)]);
    if (!result.rowCount) return res.status(404).json({ error: 'Lead não encontrado.' });
    res.json({ lead: sanitizeCrmLead(result.rows[0]), message: 'Lead atualizado.' });
  } catch (error) { next(error); }
});

app.patch('/api/crm/leads/:id/stage', requireAuth, async (req, res, next) => {
  try {
    const stage = cleanText(req.body?.stage);
    if (!CRM_STAGES.some((item) => item.code === stage)) return res.status(400).json({ error: 'Etapa inválida.' });
    const result = await query(`
      UPDATE crm_leads SET stage=$2::text, updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING *
    `, [req.params.id, stage]);
    if (!result.rowCount) return res.status(404).json({ error: 'Lead não encontrado.' });
    res.json({ lead: sanitizeCrmLead(result.rows[0]), message: 'Etapa atualizada.' });
  } catch (error) { next(error); }
});

app.delete('/api/crm/leads/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE crm_leads SET deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Lead não encontrado.' });
    res.json({ ok: true, message: 'Lead removido.' });
  } catch (error) { next(error); }
});

app.get('/api/crm/leads/:id/interactions', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      SELECT * FROM crm_interactions
      WHERE lead_id=$1::uuid
      ORDER BY occurred_at DESC, created_at DESC
      LIMIT 120
    `, [req.params.id]);
    res.json({ items: result.rows.map(sanitizeCrmInteraction) });
  } catch (error) { next(error); }
});

app.post('/api/crm/leads/:id/interactions', requireAuth, async (req, res, next) => {
  try {
    const message = cleanText(req.body?.message);
    if (!message) return res.status(400).json({ error: 'Informe a mensagem/interação.' });
    const lead = await query('SELECT * FROM crm_leads WHERE id=$1::uuid AND deleted_at IS NULL LIMIT 1', [req.params.id]);
    if (!lead.rowCount) return res.status(404).json({ error: 'Lead não encontrado.' });
    const result = await query(`
      INSERT INTO crm_interactions (lead_id, tutor_id, channel, direction, subject, message, occurred_at)
      VALUES ($1::uuid, NULLIF($2::text,'')::uuid, $3::text, $4::text, $5::text, $6::text, COALESCE(NULLIF($7::text,'')::timestamptz, NOW()))
      RETURNING *
    `, [req.params.id, lead.rows[0].tutor_id || '', cleanText(req.body?.channel) || 'whatsapp', cleanText(req.body?.direction) || 'outbound', cleanText(req.body?.subject), message, cleanText(req.body?.occurredAt) || '']);
    await query('UPDATE crm_leads SET last_contact_at=NOW(), updated_at=NOW() WHERE id=$1::uuid', [req.params.id]);
    res.status(201).json({ interaction: sanitizeCrmInteraction(result.rows[0]), message: 'Interação registrada.' });
  } catch (error) { next(error); }
});

app.get('/api/crm/messages/templates', requireAuth, async (req, res) => {
  res.json({ items: [
    { id: 'retorno', title: 'Cliente inativo', text: 'Oi, {{nome}}! Sentimos falta do seu pet aqui no PetFunny. Quer reservar um horário esta semana?' },
    { id: 'aniversario_pet', title: 'Aniversário do pet', text: 'Hoje é um dia especial para o {{pet}}! Que tal comemorar com um banho caprichado e mimo PetFunny?' },
    { id: 'pacote', title: 'Oferta de pacote', text: 'Oi, {{nome}}! Temos pacotes mensais para manter o {{pet}} sempre limpinho com economia. Quer que eu te envie as opções?' },
    { id: 'pos_atendimento', title: 'Pós-atendimento', text: 'Oi, {{nome}}! Como ficou o {{pet}} depois do atendimento? Sua opinião ajuda muito o PetFunny.' }
  ] });
});


function sanitizeGift(row = {}) {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    startsOn: row.starts_on,
    endsOn: row.ends_on,
    probabilityWeight: Number(row.probability_weight || 1),
    estimatedCostCents: Number(row.estimated_cost_cents || 0),
    status: row.status || 'active',
    aiReport: row.ai_report || null,
    spinsCount: Number(row.spins_count || 0),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function sanitizeGiftSpin(row = {}) {
  return {
    id: row.id,
    giftId: row.gift_id,
    tutorId: row.tutor_id,
    tutorName: row.tutor_name,
    petId: row.pet_id,
    petName: row.pet_name,
    resultTitle: row.result_title,
    spinContext: row.spin_context || {},
    spunAt: row.spun_at,
    createdAt: row.created_at
  };
}

function pickWeightedGift(gifts = []) {
  const active = gifts.filter((gift) => Number(gift.probability_weight || 0) > 0);
  const total = active.reduce((sum, gift) => sum + Number(gift.probability_weight || 0), 0);
  if (!active.length || total <= 0) return null;
  let cursor = Math.random() * total;
  for (const gift of active) {
    cursor -= Number(gift.probability_weight || 0);
    if (cursor <= 0) return gift;
  }
  return active[active.length - 1];
}

app.get('/api/roleta/options', requireAuth, async (req, res, next) => {
  try {
    const tutors = await query(`
      SELECT id, name, whatsapp
      FROM tutors
      WHERE deleted_at IS NULL
      ORDER BY name ASC
      LIMIT 500
    `);
    const pets = await query(`
      SELECT p.id, p.name, p.tutor_id, t.name AS tutor_name
      FROM pets p
      LEFT JOIN tutors t ON t.id = p.tutor_id
      WHERE p.deleted_at IS NULL
      ORDER BY p.name ASC
      LIMIT 500
    `);
    res.json({
      tutors: tutors.rows.map(sanitizeTutor),
      pets: pets.rows.map((pet) => ({ id: pet.id, name: pet.name, tutorId: pet.tutor_id, tutorName: pet.tutor_name })),
      statuses: [
        { code: 'active', name: 'Ativo' },
        { code: 'inactive', name: 'Inativo' },
        { code: 'expired', name: 'Encerrado' }
      ]
    });
  } catch (error) { next(error); }
});

app.get('/api/roleta/summary', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      WITH active_gifts AS (
        SELECT * FROM gifts
        WHERE deleted_at IS NULL
          AND status = 'active'
          AND (starts_on IS NULL OR starts_on <= CURRENT_DATE)
          AND (ends_on IS NULL OR ends_on >= CURRENT_DATE)
      ), spins_today AS (
        SELECT COUNT(*)::int AS total FROM gift_spins WHERE spun_at::date = CURRENT_DATE
      ), spins_month AS (
        SELECT COUNT(*)::int AS total FROM gift_spins WHERE date_trunc('month', spun_at) = date_trunc('month', NOW())
      ), cost_month AS (
        SELECT COALESCE(SUM(COALESCE(g.estimated_cost_cents,0)),0)::int AS total
        FROM gift_spins gs
        LEFT JOIN gifts g ON g.id = gs.gift_id
        WHERE date_trunc('month', gs.spun_at) = date_trunc('month', NOW())
      )
      SELECT
        (SELECT COUNT(*)::int FROM gifts WHERE deleted_at IS NULL) AS total_gifts,
        (SELECT COUNT(*)::int FROM active_gifts) AS active_gifts,
        (SELECT total FROM spins_today) AS spins_today,
        (SELECT total FROM spins_month) AS spins_month,
        (SELECT total FROM cost_month) AS estimated_cost_month_cents
    `);
    const recent = await query(`
      SELECT gs.*, t.name AS tutor_name, p.name AS pet_name
      FROM gift_spins gs
      LEFT JOIN tutors t ON t.id = gs.tutor_id
      LEFT JOIN pets p ON p.id = gs.pet_id
      ORDER BY gs.spun_at DESC
      LIMIT 12
    `);
    res.json({ summary: result.rows[0] || {}, recentSpins: recent.rows.map(sanitizeGiftSpin) });
  } catch (error) { next(error); }
});

app.get('/api/roleta/gifts', requireAuth, async (req, res, next) => {
  try {
    const search = `%${cleanText(req.query.search || '')}%`;
    const status = cleanText(req.query.status || 'all');
    const result = await query(`
      SELECT g.*, COUNT(gs.id)::int AS spins_count
      FROM gifts g
      LEFT JOIN gift_spins gs ON gs.gift_id = g.id
      WHERE g.deleted_at IS NULL
        AND ($1::text = '%%' OR g.title ILIKE $1::text OR COALESCE(g.description,'') ILIKE $1::text)
        AND ($2::text = 'all' OR g.status = $2::text)
      GROUP BY g.id
      ORDER BY g.status ASC, g.probability_weight DESC, g.title ASC
      LIMIT 300
    `, [search, status]);
    res.json({ items: result.rows.map(sanitizeGift) });
  } catch (error) { next(error); }
});

app.post('/api/roleta/gifts', requireAuth, async (req, res, next) => {
  try {
    const title = cleanText(req.body?.title);
    if (!title) return res.status(400).json({ error: 'Informe o título do mimo.' });
    const result = await query(`
      INSERT INTO gifts (title, description, starts_on, ends_on, probability_weight, estimated_cost_cents, status, ai_report)
      VALUES ($1::text, $2::text, NULLIF($3::text,'')::date, NULLIF($4::text,'')::date, GREATEST($5::int, 1), GREATEST($6::int, 0), COALESCE(NULLIF($7::text,''),'active'), $8::jsonb)
      RETURNING *
    `, [
      title,
      cleanText(req.body?.description),
      cleanText(req.body?.startsOn),
      cleanText(req.body?.endsOn),
      Number(req.body?.probabilityWeight || 1),
      moneyToCents(req.body?.estimatedCostCents ?? req.body?.estimatedCost),
      cleanText(req.body?.status || 'active'),
      JSON.stringify(req.body?.aiReport || null)
    ]);
    res.status(201).json({ gift: sanitizeGift(result.rows[0]), message: 'Mimo cadastrado.' });
  } catch (error) { next(error); }
});

app.put('/api/roleta/gifts/:id', requireAuth, async (req, res, next) => {
  try {
    const title = cleanText(req.body?.title);
    if (!title) return res.status(400).json({ error: 'Informe o título do mimo.' });
    const result = await query(`
      UPDATE gifts
      SET title=$2::text,
          description=$3::text,
          starts_on=NULLIF($4::text,'')::date,
          ends_on=NULLIF($5::text,'')::date,
          probability_weight=GREATEST($6::int, 1),
          estimated_cost_cents=GREATEST($7::int, 0),
          status=COALESCE(NULLIF($8::text,''),'active'),
          ai_report=$9::jsonb,
          updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING *
    `, [
      req.params.id,
      title,
      cleanText(req.body?.description),
      cleanText(req.body?.startsOn),
      cleanText(req.body?.endsOn),
      Number(req.body?.probabilityWeight || 1),
      moneyToCents(req.body?.estimatedCostCents ?? req.body?.estimatedCost),
      cleanText(req.body?.status || 'active'),
      JSON.stringify(req.body?.aiReport || null)
    ]);
    if (!result.rowCount) return res.status(404).json({ error: 'Mimo não encontrado.' });
    res.json({ gift: sanitizeGift(result.rows[0]), message: 'Mimo atualizado.' });
  } catch (error) { next(error); }
});

app.patch('/api/roleta/gifts/:id/status', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.body?.status || 'active');
    const result = await query(`
      UPDATE gifts SET status=$2::text, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING *
    `, [req.params.id, status]);
    if (!result.rowCount) return res.status(404).json({ error: 'Mimo não encontrado.' });
    res.json({ gift: sanitizeGift(result.rows[0]), message: 'Status do mimo atualizado.' });
  } catch (error) { next(error); }
});

app.delete('/api/roleta/gifts/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE gifts SET deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Mimo não encontrado.' });
    res.json({ ok: true, message: 'Mimo removido.' });
  } catch (error) { next(error); }
});

app.post('/api/roleta/spin', requireAuth, async (req, res, next) => {
  try {
    const available = await query(`
      SELECT * FROM gifts
      WHERE deleted_at IS NULL
        AND status = 'active'
        AND probability_weight > 0
        AND (starts_on IS NULL OR starts_on <= CURRENT_DATE)
        AND (ends_on IS NULL OR ends_on >= CURRENT_DATE)
      ORDER BY probability_weight DESC, title ASC
    `);
    const gift = pickWeightedGift(available.rows);
    if (!gift) return res.status(400).json({ error: 'Nenhum mimo ativo disponível para sortear.' });
    const result = await query(`
      INSERT INTO gift_spins (gift_id, tutor_id, pet_id, result_title, spin_context)
      VALUES ($1::uuid, NULLIF($2::text,'')::uuid, NULLIF($3::text,'')::uuid, $4::text, $5::jsonb)
      RETURNING *
    `, [
      gift.id,
      cleanText(req.body?.tutorId),
      cleanText(req.body?.petId),
      gift.title,
      JSON.stringify({ source: 'admin_simulation', weightsTotal: available.rows.reduce((sum, item) => sum + Number(item.probability_weight || 0), 0) })
    ]);
    res.status(201).json({ spin: sanitizeGiftSpin(result.rows[0]), gift: sanitizeGift(gift), message: `Resultado: ${gift.title}` });
  } catch (error) { next(error); }
});

app.get('/api/roleta/spins', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      SELECT gs.*, t.name AS tutor_name, p.name AS pet_name
      FROM gift_spins gs
      LEFT JOIN tutors t ON t.id = gs.tutor_id
      LEFT JOIN pets p ON p.id = gs.pet_id
      ORDER BY gs.spun_at DESC
      LIMIT 100
    `);
    res.json({ items: result.rows.map(sanitizeGiftSpin) });
  } catch (error) { next(error); }
});

app.post('/api/roleta/ai-suggestions', requireAuth, async (req, res) => {
  const durationDays = Math.max(7, Number(req.body?.durationDays || 30));
  const monthlySpins = Math.max(20, Number(req.body?.monthlySpins || 80));
  const suggestions = [
    { title: 'Laço especial', description: 'Mimo barato, visual e recorrente para aumentar percepção de cuidado.', probabilityWeight: 10, estimatedCostCents: 350, suggestedQuantity: Math.ceil(monthlySpins * 0.35) },
    { title: 'Bandana temática', description: 'Brinde com alto potencial de foto e divulgação espontânea.', probabilityWeight: 5, estimatedCostCents: 950, suggestedQuantity: Math.ceil(monthlySpins * 0.16) },
    { title: '10% OFF no próximo banho', description: 'Incentivo de retorno sem impacto imediato no caixa.', probabilityWeight: 8, estimatedCostCents: 0, suggestedQuantity: Math.ceil(monthlySpins * 0.25) },
    { title: 'Hidratação com desconto', description: 'Upsell controlado para serviços premium.', probabilityWeight: 4, estimatedCostCents: 0, suggestedQuantity: Math.ceil(monthlySpins * 0.12) },
    { title: 'Banho grátis hoje', description: 'Prêmio raro para gerar encantamento, com probabilidade baixa pelo custo.', probabilityWeight: 1, estimatedCostCents: 6500, suggestedQuantity: Math.max(1, Math.ceil(monthlySpins * 0.02)) }
  ];
  const estimatedCostCents = suggestions.reduce((sum, item) => sum + (item.estimatedCostCents * item.suggestedQuantity), 0);
  res.json({
    report: {
      title: 'Sugestões de mimos para Roleta PetFunny',
      durationDays,
      monthlySpins,
      estimatedCostCents,
      strategy: 'Misturar mimos baratos de alta frequência com prêmios raros de alto impacto para controlar custo e aumentar encantamento.',
      suggestions
    }
  });
});

app.get('/api/financeiro/options', requireAuth, async (req, res, next) => {
  try {
    const paymentMethods = await query(`
      SELECT * FROM payment_methods
      WHERE is_active = TRUE
        AND deleted_at IS NULL
      ORDER BY sort_order ASC, name ASC
    `);
    const paymentStatuses = await query(`
      SELECT * FROM payment_statuses
      WHERE is_active = TRUE
        AND deleted_at IS NULL
      ORDER BY sort_order ASC, name ASC
    `);
    const tutors = await query(`
      SELECT id, name, whatsapp
      FROM tutors
      WHERE deleted_at IS NULL
      ORDER BY name ASC
      LIMIT 500
    `);
    res.json({
      paymentMethods: paymentMethods.rows.map(sanitizePaymentMethod),
      paymentStatuses: paymentStatuses.rows.map(sanitizePaymentStatus),
      tutors: tutors.rows.map(sanitizeTutor),
      categories: [
        'atendimento', 'pacote', 'assinatura', 'produto', 'taxa', 'aluguel', 'fornecedor', 'salario', 'marketing', 'outros'
      ],
      statuses: paymentStatuses.rows.map(row => row.code),
      types: ['income', 'expense']
    });
  } catch (error) { next(error); }
});

app.get('/api/financeiro/summary', requireAuth, async (req, res, next) => {
  try {
    const today = await query(`
      WITH base AS (
        SELECT * FROM financial_transactions WHERE deleted_at IS NULL
      ), payments_today AS (
        SELECT COALESCE(SUM(amount_cents),0)::int AS total FROM payments WHERE paid_at::date = CURRENT_DATE
      )
      SELECT
        (SELECT total FROM payments_today) AS revenue_today_cents,
        COALESCE(SUM(amount_cents) FILTER (WHERE type='income' AND status <> 'paid'),0)::int AS pending_income_cents,
        COUNT(*) FILTER (WHERE type='income' AND status <> 'paid')::int AS pending_income_count,
        COALESCE(SUM(amount_cents) FILTER (WHERE type='expense' AND status <> 'paid'),0)::int AS pending_expense_cents,
        COUNT(*) FILTER (WHERE type='expense' AND status <> 'paid')::int AS pending_expense_count,
        COALESCE(SUM(amount_cents) FILTER (WHERE type='income' AND status='paid' AND paid_at::date = CURRENT_DATE),0)::int AS paid_income_today_cents,
        COALESCE(SUM(amount_cents) FILTER (WHERE type='expense' AND status='paid' AND paid_at::date = CURRENT_DATE),0)::int AS paid_expense_today_cents,
        COALESCE(SUM(amount_cents) FILTER (WHERE type='income' AND status <> 'paid' AND due_date < CURRENT_DATE),0)::int AS overdue_income_cents,
        COUNT(*) FILTER (WHERE type='income' AND status <> 'paid' AND due_date < CURRENT_DATE)::int AS overdue_income_count
      FROM base
    `);
    const flow = await query(`
      SELECT to_char(day, 'DD/MM') AS label,
             COALESCE(SUM(amount_cents) FILTER (WHERE type='income'),0)::int AS income_cents,
             COALESCE(SUM(amount_cents) FILTER (WHERE type='expense'),0)::int AS expense_cents
      FROM generate_series(CURRENT_DATE - INTERVAL '6 days', CURRENT_DATE, INTERVAL '1 day') day
      LEFT JOIN financial_transactions ft ON ft.deleted_at IS NULL AND COALESCE(ft.paid_at::date, ft.due_date) = day::date AND ft.status <> 'canceled'
      GROUP BY day
      ORDER BY day ASC
    `);
    const byCategory = await query(`
      SELECT category, type, COALESCE(SUM(amount_cents),0)::int AS total_cents, COUNT(*)::int AS count
      FROM financial_transactions
      WHERE deleted_at IS NULL AND status <> 'canceled'
      GROUP BY category, type
      ORDER BY total_cents DESC
      LIMIT 12
    `);
    res.json({ summary: today.rows[0] || {}, flow: flow.rows, byCategory: byCategory.rows });
  } catch (error) { next(error); }
});

app.get('/api/financeiro/transactions', requireAuth, async (req, res, next) => {
  try {
    const search = cleanText(req.query.search);
    const status = cleanText(req.query.status) || 'all';
    const type = cleanText(req.query.type) || 'all';
    const category = cleanText(req.query.category) || 'all';
    const limit = parseLimit(req.query.limit, 30, 100);
    const offset = parseOffset(req.query.page, limit);
    const params = [];
    const where = ['ft.deleted_at IS NULL'];
    if (status !== 'all') { params.push(status); where.push(`ft.status = $${params.length}::text`); }
    if (type !== 'all') { params.push(type); where.push(`ft.type = $${params.length}::text`); }
    if (category !== 'all') { params.push(category); where.push(`ft.category = $${params.length}::text`); }
    if (search) {
      params.push(`%${search}%`);
      where.push(`(ft.description ILIKE $${params.length} OR t.name ILIKE $${params.length} OR t.whatsapp ILIKE $${params.length})`);
    }
    const result = await query(`
      SELECT ft.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp,
             p.name AS pet_name, pk.name AS package_name, pm.name AS payment_method_name
      FROM financial_transactions ft
      LEFT JOIN tutors t ON t.id = ft.tutor_id
      LEFT JOIN appointments a ON a.id = ft.appointment_id
      LEFT JOIN pets p ON p.id = a.pet_id
      LEFT JOIN customer_packages cp ON cp.id = ft.customer_package_id
      LEFT JOIN packages pk ON pk.id = cp.package_id
      LEFT JOIN payments pay ON pay.financial_transaction_id = ft.id
      LEFT JOIN payment_methods pm ON pm.id = pay.payment_method_id
      WHERE ${where.join(' AND ')}
      ORDER BY ft.status = 'pending' DESC, ft.due_date ASC NULLS LAST, ft.created_at DESC
      LIMIT ${limit} OFFSET ${offset}
    `, params);
    const count = await query(`
      SELECT COUNT(*)::int AS total
      FROM financial_transactions ft
      LEFT JOIN tutors t ON t.id = ft.tutor_id
      WHERE ${where.join(' AND ')}
    `, params);
    res.json({ items: result.rows.map(sanitizeFinancialTransaction), total: count.rows[0]?.total || 0, page: Number(req.query.page || 1), limit });
  } catch (error) { next(error); }
});

app.post('/api/financeiro/transactions', requireAuth, async (req, res, next) => {
  try {
    const type = cleanText(req.body?.type) || 'income';
    const category = cleanText(req.body?.category) || 'outros';
    const description = cleanText(req.body?.description);
    const amountCents = moneyToCents(req.body?.amountCents ?? req.body?.amount);
    if (!['income', 'expense'].includes(type)) return res.status(400).json({ error: 'Tipo financeiro inválido.' });
    if (!description || amountCents <= 0) return res.status(400).json({ error: 'Informe descrição e valor maior que zero.' });
    const result = await query(`
      INSERT INTO financial_transactions (tutor_id, type, category, description, amount_cents, due_date, status)
      VALUES (NULLIF($1::text,'')::uuid, $2::text, $3::text, $4::text, $5::integer, NULLIF($6::text,'')::date, $7::text)
      RETURNING *
    `, [cleanText(req.body?.tutorId) || '', type, category, description, amountCents, cleanText(req.body?.dueDate) || new Date().toISOString().slice(0,10), cleanText(req.body?.status) || 'pending']);
    const transaction = await getFinancialTransactionById(result.rows[0].id);
    res.status(201).json({ transaction: sanitizeFinancialTransaction(transaction), message: 'Lançamento financeiro criado.' });
  } catch (error) { next(error); }
});

app.patch('/api/financeiro/transactions/:id/pay', requireAuth, async (req, res, next) => {
  try {
    const current = await getFinancialTransactionById(req.params.id);
    if (!current) return res.status(404).json({ error: 'Lançamento não encontrado.' });
    if (current.status === 'paid') return res.json({ transaction: sanitizeFinancialTransaction(current), message: 'Lançamento já estava baixado.' });
    const amountCents = moneyToCents(req.body?.amountCents ?? req.body?.amount) || Number(current.amount_cents || 0);
    const paymentMethodId = cleanText(req.body?.paymentMethodId);
    await query('BEGIN');
    try {
      await query(`
        UPDATE financial_transactions
        SET status='paid', paid_at=COALESCE(NULLIF($2::text,'')::timestamptz, NOW()), updated_at=NOW()
        WHERE id=$1::uuid AND deleted_at IS NULL
      `, [req.params.id, cleanText(req.body?.paidAt) || '']);
      const paymentInserted = await query(`
        INSERT INTO payments (financial_transaction_id, payment_method_id, amount_cents, paid_at, notes)
        VALUES ($1::uuid, NULLIF($2::text,'')::uuid, $3::integer, COALESCE(NULLIF($4::text,'')::timestamptz, NOW()), $5::text)
        RETURNING id
      `, [req.params.id, paymentMethodId || '', amountCents, cleanText(req.body?.paidAt) || '', cleanText(req.body?.notes)]);
      if (current.appointment_id) await createOrUpdateReceiptForAppointment(current.appointment_id, paymentInserted.rows[0].id);
      await query('COMMIT');
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
    const transaction = await getFinancialTransactionById(req.params.id);
    res.json({ transaction: sanitizeFinancialTransaction(transaction), message: 'Pagamento baixado com sucesso.' });
  } catch (error) { next(error); }
});

app.patch('/api/financeiro/transactions/:id/status', requireAuth, async (req, res, next) => {
  try {
    const status = cleanText(req.body?.status);
    if (!['pending','paid','overdue','canceled'].includes(status)) return res.status(400).json({ error: 'Status inválido.' });
    const result = await query(`
      UPDATE financial_transactions
      SET status=$2::text, updated_at=NOW()
      WHERE id=$1::uuid AND deleted_at IS NULL
      RETURNING id
    `, [req.params.id, status]);
    if (!result.rowCount) return res.status(404).json({ error: 'Lançamento não encontrado.' });
    const transaction = await getFinancialTransactionById(req.params.id);
    res.json({ transaction: sanitizeFinancialTransaction(transaction), message: 'Status financeiro atualizado.' });
  } catch (error) { next(error); }
});

app.delete('/api/financeiro/transactions/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE financial_transactions SET status='canceled', deleted_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING id`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Lançamento não encontrado.' });
    res.json({ ok: true, message: 'Lançamento cancelado.' });
  } catch (error) { next(error); }
});

app.get('/api/dashboard/summary', requireAuth, async (req, res, next) => {
  try {
    const summary = await getDashboardSummary();
    res.json(summary);
  } catch (error) {
    next(error);
  }
});


app.get('/api/notificacoes/summary', requireAuth, async (req, res, next) => {
  try {
    await generateRealtimeNotifications();
    const unread = await query(`SELECT COUNT(*)::int AS total FROM system_notifications WHERE deleted_at IS NULL AND is_read = FALSE`);
    const latest = await query(`
      SELECT * FROM system_notifications
      WHERE deleted_at IS NULL
      ORDER BY is_read ASC, created_at DESC
      LIMIT 6
    `);
    res.json({ unread: unread.rows[0]?.total || 0, latest: latest.rows.map(sanitizeSystemNotification) });
  } catch (error) { next(error); }
});

app.get('/api/notificacoes', requireAuth, async (req, res, next) => {
  try {
    await generateRealtimeNotifications();
    const status = cleanText(req.query.status) || 'all';
    const where = ['deleted_at IS NULL'];
    if (status === 'unread') where.push('is_read = FALSE');
    if (status === 'read') where.push('is_read = TRUE');
    const result = await query(`
      SELECT * FROM system_notifications
      WHERE ${where.join(' AND ')}
      ORDER BY is_read ASC, created_at DESC
      LIMIT 120
    `);
    res.json({ items: result.rows.map(sanitizeSystemNotification), total: result.rowCount });
  } catch (error) { next(error); }
});

app.patch('/api/notificacoes/:id/read', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`UPDATE system_notifications SET is_read=TRUE, read_at=NOW(), updated_at=NOW() WHERE id=$1::uuid AND deleted_at IS NULL RETURNING *`, [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Notificação não encontrada.' });
    res.json({ notification: sanitizeSystemNotification(result.rows[0]) });
  } catch (error) { next(error); }
});

app.patch('/api/notificacoes/read-all', requireAuth, async (req, res, next) => {
  try {
    await query(`UPDATE system_notifications SET is_read=TRUE, read_at=COALESCE(read_at, NOW()), updated_at=NOW() WHERE deleted_at IS NULL AND is_read=FALSE`);
    res.json({ ok: true, message: 'Notificações marcadas como lidas.' });
  } catch (error) { next(error); }
});

app.get('/api/financeiro/inadimplentes', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      SELECT ft.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp,
             p.name AS pet_name, pm.name AS payment_method_name
      FROM financial_transactions ft
      LEFT JOIN tutors t ON t.id = ft.tutor_id
      LEFT JOIN appointments a ON a.id = ft.appointment_id
      LEFT JOIN pets p ON p.id = a.pet_id
      LEFT JOIN payments pay ON pay.financial_transaction_id = ft.id
      LEFT JOIN payment_methods pm ON pm.id = pay.payment_method_id
      WHERE ft.deleted_at IS NULL
        AND ft.type='income'
        AND ft.status <> 'paid'
        AND ft.due_date < CURRENT_DATE
      ORDER BY ft.due_date ASC, ft.amount_cents DESC
      LIMIT 200
    `);
    const total = result.rows.reduce((sum, row) => sum + Number(row.amount_cents || 0), 0);
    res.json({ items: result.rows.map(sanitizeFinancialTransaction), totalCents: total, total: result.rowCount });
  } catch (error) { next(error); }
});

async function safeInsightTask(label, task, fallback) {
  try {
    return await task();
  } catch (error) {
    console.warn(`[relatorios] bloco ${label} ignorado: ${error.message}`);
    return fallback;
  }
}

app.get('/api/relatorios/insights', requireAuth, async (req, res, next) => {
  try {
    const [dashboard, overdue, packages, services, crm] = await Promise.all([
      safeInsightTask('dashboard', () => getDashboardSummary(), { cards: {} }),
      safeInsightTask('inadimplencia', () => query(`
        SELECT COUNT(*)::int AS count, COALESCE(SUM(amount_cents),0)::int AS total_cents
        FROM financial_transactions
        WHERE deleted_at IS NULL
          AND type='income'
          AND status <> 'paid'
          AND due_date < CURRENT_DATE
      `), { rows: [{ count: 0, total_cents: 0 }] }),
      safeInsightTask('pacotes', () => query(`
        SELECT COUNT(*)::int AS count
        FROM customer_packages
        WHERE deleted_at IS NULL
          AND status='active'
          AND (COALESCE(total_sessions, 0) - COALESCE(used_sessions, 0)) <= 1
      `), { rows: [{ count: 0 }] }),
      safeInsightTask('servicos', () => query(`
        SELECT s.name, COUNT(ai.id)::int AS sold_count, COALESCE(SUM(ai.total_cents),0)::int AS total_cents
        FROM appointment_items ai
        LEFT JOIN services s ON s.id=ai.service_id
        GROUP BY s.name
        ORDER BY total_cents DESC NULLS LAST
        LIMIT 5
      `), { rows: [] }),
      safeInsightTask('crm', () => query(`
        SELECT COUNT(*)::int AS open_leads
        FROM crm_leads
        WHERE deleted_at IS NULL
          AND stage NOT IN ('fechado', 'perdido', 'closed')
      `), { rows: [{ open_leads: 0 }] })
    ]);

    const overdueRow = overdue.rows?.[0] || {};
    const insights = [];
    insights.push({ title: 'Agenda de hoje', diagnosis: `Hoje existem ${dashboard.cards?.appointmentsToday?.value || 0} agendamento(s).`, impact: 'A agenda define ocupação, equipe e previsão de faturamento do dia.', action: 'Confirme presença dos tutores pelo WhatsApp e acompanhe check-in/check-out.' });
    if (Number(overdueRow.count || 0) > 0) insights.push({ title: 'Inadimplência ativa', diagnosis: `Há ${overdueRow.count} cobrança(s) vencida(s), somando ${(Number(overdueRow.total_cents || 0)/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}.`, impact: 'Valores vencidos reduzem previsibilidade de caixa.', action: 'Acesse Financeiro > Inadimplentes e envie cobrança amigável.' });
    if (Number(packages.rows?.[0]?.count || 0) > 0) insights.push({ title: 'Pacotes perto do fim', diagnosis: `${packages.rows[0].count} pacote(s) ativo(s) têm uma sessão ou menos.`, impact: 'É uma oportunidade direta de renovação antes do cliente encerrar a recorrência.', action: 'Aborde o tutor antes do último atendimento com oferta de renovação.' });
    insights.push({ title: 'Serviços mais fortes', diagnosis: services.rows?.length ? `Serviço com maior receita: ${services.rows[0].name || 'não identificado'}.` : 'Ainda não há volume suficiente de serviços vendidos.', impact: 'Entender serviços fortes ajuda a criar combos e campanhas.', action: 'Use os serviços com melhor desempenho como base para pacotes e promoções.' });
    insights.push({ title: 'CRM e oportunidades', diagnosis: `Existem ${crm.rows?.[0]?.open_leads || 0} lead(s) em aberto no CRM.`, impact: 'Leads parados representam faturamento que ainda não virou agenda.', action: 'Priorize leads com WhatsApp e histórico recente.' });
    res.json({ generatedAt: new Date().toISOString(), insights, dashboard, topServices: services.rows || [] });
  } catch (error) { next(error); }
});

app.get('/api/db/status', async (req, res, next) => {
  try {
    const health = await healthcheckDb();
    if (!health.connected) {
      return res.status(503).json({
        status: 'unavailable',
        service: 'PetFunny OS Database',
        database: health,
        tenant: false
      });
    }

    const tables = await query(`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
        AND table_type = 'BASE TABLE'
        AND table_name NOT LIKE 'tenant_%'
      ORDER BY table_name
    `);

    res.json({
      status: 'ok',
      service: 'PetFunny OS Database',
      tenant: false,
      tables: tables.rows.map((row) => row.table_name),
      totalTables: tables.rowCount,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    next(error);
  }
});




// WhatsApp híbrido: IA/sistema gera mensagem, atendente revisa e envia manualmente.
function onlyDigits(value = '') {
  return String(value || '').replace(/\D/g, '');
}

function formatDateTimePt(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function buildWhatsAppUrl(phone, message) {
  const digits = onlyDigits(phone);
  if (!digits) return '';
  const normalized = digits.startsWith('55') ? digits : `55${digits}`;
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message || '')}`;
}

async function getWhatsAppContext({ type, appointmentId, tutorId, transactionId, leadId, customerPackageId, receiptToken }) {
  const business = await getBusinessPayload().catch(() => ({ name: env.petfunnyName, whatsapp: env.petfunnyWhatsapp, city: env.petfunnyCity, state: env.petfunnyState }));
  const context = { business, type };

  if (appointmentId) {
    const appointment = await getAppointmentById(appointmentId);
    if (appointment) context.appointment = sanitizeAppointment(appointment);
  }

  if (tutorId) {
    const tutor = await query('SELECT id, name, whatsapp, email FROM tutors WHERE id = $1::uuid AND deleted_at IS NULL LIMIT 1', [tutorId]);
    if (tutor.rows[0]) context.tutor = sanitizeTutor(tutor.rows[0]);
  }

  if (transactionId) {
    const transaction = await query(`
      SELECT ft.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, pm.name AS payment_method_name
      FROM financial_transactions ft
      LEFT JOIN tutors t ON t.id = ft.tutor_id
      LEFT JOIN pets p ON p.id = ft.pet_id
      LEFT JOIN payment_methods pm ON pm.id = ft.payment_method_id
      WHERE ft.id = $1::uuid AND ft.deleted_at IS NULL
      LIMIT 1
    `, [transactionId]);
    if (transaction.rows[0]) context.transaction = sanitizeFinancialTransaction(transaction.rows[0]);
  }

  if (leadId) {
    const lead = await query('SELECT id, name, whatsapp, source, stage, notes FROM crm_leads WHERE id = $1::uuid AND deleted_at IS NULL LIMIT 1', [leadId]);
    if (lead.rows[0]) context.lead = sanitizeCrmLead(lead.rows[0]);
  }

  if (customerPackageId) {
    const pkg = await query(`
      SELECT cp.*, t.name AS tutor_name, t.whatsapp AS tutor_whatsapp, p.name AS pet_name, pk.name AS package_name
      FROM customer_packages cp
      LEFT JOIN tutors t ON t.id = cp.tutor_id
      LEFT JOIN pets p ON p.id = cp.pet_id
      LEFT JOIN packages pk ON pk.id = cp.package_id
      WHERE cp.id = $1::uuid AND cp.deleted_at IS NULL
      LIMIT 1
    `, [customerPackageId]);
    if (pkg.rows[0]) context.customerPackage = sanitizeCustomerPackage(pkg.rows[0]);
  }

  if (receiptToken) {
    context.receiptUrl = `${env.appUrl || 'http://localhost:3000'}/documentos/recibo/${receiptToken}`;
  }

  return context;
}

function inferWhatsAppTarget(context = {}) {
  const appointment = context.appointment || {};
  const transaction = context.transaction || {};
  const lead = context.lead || {};
  const pkg = context.customerPackage || {};
  const tutor = context.tutor || {};
  const phone = appointment.tutorWhatsapp || transaction.tutorWhatsapp || lead.whatsapp || pkg.tutorWhatsapp || tutor.whatsapp || '';
  const name = appointment.tutorName || transaction.tutorName || lead.name || pkg.tutorName || tutor.name || 'tudo bem';
  return { phone, name };
}

function makeWhatsAppMessage(type, context = {}, custom = {}) {
  const target = inferWhatsAppTarget(context);
  const appointment = context.appointment || {};
  const transaction = context.transaction || {};
  const pkg = context.customerPackage || {};
  const petName = appointment.petName || transaction.petName || pkg.petName || custom.petName || 'seu pet';
  const service = appointment.services || custom.service || 'banho e tosa';
  const when = appointment.startsAt ? formatDateTimePt(appointment.startsAt) : (custom.when || '');
  const total = ((Number(appointment.totalCents || transaction.amountCents || 0) || 0) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const sessions = pkg.remainingSessions != null ? pkg.remainingSessions : custom.sessionsRemaining;
  const receipt = context.receiptUrl || custom.receiptUrl || '';
  const firstName = String(target.name || '').split(' ')[0] || 'tudo bem';

  const templates = {
    confirmacao_agendamento: `Oi, ${firstName}! Tudo bem? Passando para confirmar o horário do ${petName} aqui no PetFunny${when ? `: ${when}` : ''}. O serviço previsto é ${service}. Podemos confirmar?`,
    lembrete_agendamento: `Oi, ${firstName}! Tudo bem? Só passando para lembrar do horário do ${petName} no PetFunny${when ? `: ${when}` : ''}. Se precisar ajustar, me avisa por aqui.`,
    aviso_atraso: `Oi, ${firstName}! Tudo bem? Estamos com um pequeno ajuste na rotina de atendimentos hoje e o horário do ${petName} pode sofrer um atraso. Vou te mantendo informado por aqui, combinado?`,
    encaixe_disponivel: `Oi, ${firstName}! Tudo bem? Surgiu um horário disponível no PetFunny para cuidar do ${petName}. Quer que eu veja esse encaixe para vocês?`,
    cobranca_amigavel: `Oi, ${firstName}! Tudo bem? Passando para lembrar que ficou uma pendência em aberto no PetFunny${transaction.description ? ` referente a ${transaction.description}` : ''}${transaction.amountCents ? ` no valor de ${total}` : ''}. Pode me chamar por aqui para combinarmos a melhor forma de pagamento.`,
    recibo: `Oi, ${firstName}! Obrigado pela confiança no PetFunny. Segue o recibo do atendimento do ${petName}${receipt ? `: ${receipt}` : '.'}`,
    renovacao_pacote: `Oi, ${firstName}! Tudo bem? O pacote do ${petName} está perto do fim${sessions != null ? `, com ${sessions} sessão(ões) restante(s)` : ''}. Quer que eu veja uma opção de renovação para manter os cuidados em dia?`,
    reativacao_cliente: `Oi, ${firstName}! Tudo bem? Faz um tempinho que não vemos o ${petName || 'seu pet'} por aqui. Quer que eu veja um horário disponível esta semana para deixar ele limpinho e bem cuidado?`,
    pos_atendimento: `Oi, ${firstName}! Tudo bem? O ${petName} passou pelo atendimento no PetFunny e agradecemos pela confiança. Qualquer coisa que precisar, é só me chamar por aqui.`,
    promocao: `Oi, ${firstName}! Tudo bem? Temos uma condição especial no PetFunny para banho e tosa. Quer que eu veja os horários disponíveis para o ${petName}?`,
    mimo_roleta: `Oi, ${firstName}! Tudo bem? Temos uma novidade no PetFunny: uma ação especial com mimos para os pets. Quer participar no próximo atendimento do ${petName}?`,
    personalizada: custom.message || `Oi, ${firstName}! Tudo bem? Aqui é do PetFunny - Banho e Tosa. Posso te ajudar com o agendamento do ${petName}?`
  };

  return templates[type] || templates.personalizada;
}

app.get('/api/whatsapp/templates', requireAuth, async (req, res) => {
  res.json({
    templates: [
      { code: 'confirmacao_agendamento', name: 'Confirmação de agendamento', module: 'Agenda' },
      { code: 'lembrete_agendamento', name: 'Lembrete de horário', module: 'Agenda' },
      { code: 'aviso_atraso', name: 'Aviso de atraso', module: 'Agenda' },
      { code: 'encaixe_disponivel', name: 'Encaixe disponível', module: 'Agenda' },
      { code: 'cobranca_amigavel', name: 'Cobrança amigável', module: 'Financeiro' },
      { code: 'recibo', name: 'Envio de recibo', module: 'Comandas e Recibos' },
      { code: 'renovacao_pacote', name: 'Renovação de pacote', module: 'Pacotes' },
      { code: 'reativacao_cliente', name: 'Reativação de cliente', module: 'CRM' },
      { code: 'pos_atendimento', name: 'Pós-atendimento', module: 'CRM' },
      { code: 'promocao', name: 'Promoção', module: 'Marketing' },
      { code: 'mimo_roleta', name: 'Roleta de Mimos', module: 'Roleta' },
      { code: 'personalizada', name: 'Mensagem personalizada', module: 'Geral' }
    ]
  });
});

app.post('/api/whatsapp/message', requireAuth, async (req, res, next) => {
  try {
    const type = cleanText(req.body?.type) || 'personalizada';
    const context = await getWhatsAppContext({
      type,
      appointmentId: cleanText(req.body?.appointmentId),
      tutorId: cleanText(req.body?.tutorId),
      transactionId: cleanText(req.body?.transactionId),
      leadId: cleanText(req.body?.leadId),
      customerPackageId: cleanText(req.body?.customerPackageId),
      receiptToken: cleanText(req.body?.receiptToken)
    });
    const custom = req.body?.custom && typeof req.body.custom === 'object' ? req.body.custom : {};
    const target = inferWhatsAppTarget(context);
    const phone = onlyDigits(cleanText(req.body?.phone) || target.phone || custom.phone || '');
    const message = makeWhatsAppMessage(type, context, custom);
    res.json({ phone, message, url: buildWhatsAppUrl(phone, message), mode: 'hybrid_manual_send' });
  } catch (error) { next(error); }
});

app.get('/api/assistente-ia/prompt', requireAuth, async (req, res) => {
  const prompt = getPetFunnyAiSystemPrompt();
  res.json({
    status: 'ok',
    metadata: getPetFunnyAiPromptMetadata(),
    systemPrompt: prompt
  });
});

app.get('/api/assistente-ia/status', requireAuth, async (req, res) => {
  res.json({
    status: 'ok',
    service: 'Assistente Inteligente PetFunny',
    mode: 'petfunny_single',
    tenant: false,
    openaiConfigured: Boolean(env.openaiApiKey),
    prompt: getPetFunnyAiPromptMetadata(),
    message: env.openaiApiKey
      ? 'Prompt global configurado. Integração OpenAI pronta para uso controlado.'
      : 'Prompt global configurado. API OpenAI não configurada; o sistema continua funcionando normalmente.'
  });
});

app.post('/api/assistente-ia/analyze', requireAuth, async (req, res) => {
  const { module = 'geral', question = '', context = {} } = req.body || {};
  const normalizedQuestion = String(question || '').trim();
  const moduleName = String(module || 'geral').trim();
  const contextKeys = context && typeof context === 'object' ? Object.keys(context) : [];

  if (!normalizedQuestion) {
    return res.status(400).json({
      error: 'Informe uma pergunta ou solicitação para o Assistente Inteligente PetFunny.'
    });
  }

  // v1.4.1: resposta local segura. A chamada real para OpenAI fica opcional para uma próxima etapa,
  // sem impedir login, dashboard, agenda, financeiro ou demais módulos quando a chave não existir.
  return res.json({
    status: 'ok',
    assistant: 'Assistente Inteligente PetFunny',
    openaiConfigured: Boolean(env.openaiApiKey),
    module: moduleName,
    answer: {
      title: `Análise inicial para ${moduleName}`,
      diagnosis: contextKeys.length
        ? `Recebi contexto com os campos: ${contextKeys.join(', ')}. Com esses dados, consigo fazer uma análise preliminar sem inventar informações.`
        : 'Com os dados disponíveis, consigo analisar parcialmente. Para uma recomendação mais precisa, envie também dados reais do módulo, como agenda, valores, tutor, pet, status ou histórico.',
      impact: 'Essa camada já padroniza o comportamento da IA para responder de forma operacional, comercial e analítica dentro do PetFunny OS.',
      recommendedAction: 'Conecte esta chamada aos dados reais do módulo aberto e envie o contexto junto da pergunta. A IA deve responder sem inventar dados e sempre sugerir uma próxima ação prática.',
      readyMessage: normalizedQuestion.toLowerCase().includes('whatsapp')
        ? 'Oi, {{nome_cliente}}! Tudo bem? Passando para falar sobre o {{nome_pet}} aqui no PetFunny. Quer que eu veja uma opção de horário para vocês?'
        : null
    },
    systemPromptVersion: 'petfunny-global-v1.4.1'
  });
});

app.use(express.static(frontendRoot, {
  etag: false,
  lastModified: false,
  maxAge: 0,
  setHeaders: (res, filePath) => {
    if (/\.(html|js|css)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'no-store, must-revalidate');
    }
  }
}));

app.get('/', (req, res) => sendFrontendFile(res, 'index.html'));
app.get(['/login', '/admin/login'], (req, res) => sendFrontendFile(res, 'pages/login/index.html'));
app.get(['/dashboard', '/admin', '/admin/dashboard'], (req, res) => sendFrontendFile(res, 'pages/dashboard/index.html'));
app.get(['/app/login', '/cliente/login'], (req, res) => sendFrontendFile(res, 'pages/app/login/index.html'));
app.get(['/app/primeiro-acesso', '/cliente/primeiro-acesso'], (req, res) => sendFrontendFile(res, 'pages/app/primeiro-acesso/index.html'));
app.get(['/app', '/app/home', '/cliente'], (req, res) => sendFrontendFile(res, 'pages/app/home/index.html'));
app.get(['/documentos/recibo/:token', '/public/recibos/:token'], (req, res) => sendFrontendFile(res, 'pages/public/recibo/index.html'));

const modulePages = {
  agenda: 'agenda',
  tutores: 'tutores',
  pets: 'pets',
  servicos: 'servicos',
  pacotes: 'pacotes',
  assinaturas: 'assinaturas',
  financeiro: 'financeiro',
  'comandas-recibos': 'comandas-recibos',
  crm: 'crm',
  'roleta-de-mimos': 'roleta-de-mimos',
  relatorios: 'relatorios',
  notificacoes: 'notificacoes',
  'assistente-ia': 'assistente-ia',
  whatsapp: 'whatsapp',
  configuracoes: 'configuracoes'
};

Object.entries(modulePages).forEach(([route, page]) => {
  app.get([`/${route}`, `/admin/${route}`], (req, res) => sendFrontendFile(res, `pages/${page}/index.html`));
});

app.use('/api', notFoundMiddleware);

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  return sendFrontendFile(res, 'index.html');
});

app.use(errorMiddleware);

export default app;
