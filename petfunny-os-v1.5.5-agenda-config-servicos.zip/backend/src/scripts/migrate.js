import { query, closePool } from '../config/db.js';
import { env } from '../config/env.js';

const ddl = `
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS unaccent;

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  permissions JSONB NOT NULL DEFAULT '["full_access"]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS business_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name TEXT NOT NULL DEFAULT 'PetFunny - Banho e Tosa',
  legal_name TEXT,
  document_number TEXT,
  whatsapp TEXT NOT NULL DEFAULT '5516981535338',
  phone TEXT,
  email TEXT,
  address_street TEXT,
  address_number TEXT,
  address_neighborhood TEXT,
  address_city TEXT NOT NULL DEFAULT 'Ribeirão Preto',
  address_state TEXT NOT NULL DEFAULT 'SP',
  address_zipcode TEXT,
  logo_url TEXT,
  theme JSONB NOT NULL DEFAULT '{"primary":"#00A9B7","accent":"#FF9D98"}'::jsonb,
  document_preferences JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS collaborators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'banho_tosa',
  phone TEXT,
  email TEXT,
  color TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS service_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS appointment_statuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT NOT NULL DEFAULT '#00A9B7',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_final BOOLEAN NOT NULL DEFAULT FALSE,
  blocks_slot BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES service_categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  pet_size TEXT NOT NULL DEFAULT 'todos',
  price_cents INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
  duration_minutes INTEGER NOT NULL DEFAULT 60 CHECK (duration_minutes > 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  UNIQUE (name, pet_size)
);

CREATE TABLE IF NOT EXISTS tutors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  whatsapp TEXT NOT NULL UNIQUE,
  phone TEXT,
  email TEXT,
  document_number TEXT,
  address TEXT,
  city TEXT DEFAULT 'Ribeirão Preto',
  state TEXT DEFAULT 'SP',
  photo_url TEXT,
  tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS pets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID NOT NULL REFERENCES tutors(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  photo_url TEXT,
  species TEXT NOT NULL DEFAULT 'dog',
  breed TEXT,
  size TEXT NOT NULL DEFAULT 'pequeno',
  coat_type TEXT,
  birth_date DATE,
  weight_kg NUMERIC(6,2),
  preferences TEXT,
  restrictions TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);


CREATE TABLE IF NOT EXISTS client_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID NOT NULL UNIQUE REFERENCES tutors(id) ON DELETE CASCADE,
  whatsapp TEXT NOT NULL UNIQUE,
  password_hash TEXT,
  first_access_code_hash TEXT,
  first_access_expires_at TIMESTAMPTZ,
  first_access_confirmed_at TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'pending_first_access',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS business_hours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  weekday SMALLINT NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  opens_at TIME,
  closes_at TIME,
  is_open BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (weekday)
);

CREATE TABLE IF NOT EXISTS time_slot_capacities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  weekday SMALLINT CHECK (weekday BETWEEN 0 AND 6),
  slot_time TIME NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 1 CHECK (capacity >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (weekday, slot_time)
);

CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID REFERENCES tutors(id) ON DELETE SET NULL,
  pet_id UUID REFERENCES pets(id) ON DELETE SET NULL,
  collaborator_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'agendado',
  source TEXT NOT NULL DEFAULT 'manual',
  subtotal_cents INTEGER NOT NULL DEFAULT 0 CHECK (subtotal_cents >= 0),
  discount_percent NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100),
  discount_cents INTEGER NOT NULL DEFAULT 0 CHECK (discount_cents >= 0),
  total_cents INTEGER NOT NULL DEFAULT 0 CHECK (total_cents >= 0),
  package_session_label TEXT,
  notes TEXT,
  payment_status TEXT DEFAULT 'pending',
  payment_method_id UUID REFERENCES payment_methods(id) ON DELETE SET NULL,
  checked_in_at TIMESTAMPTZ,
  checked_out_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS appointment_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  pet_id UUID REFERENCES pets(id) ON DELETE SET NULL,
  service_id UUID REFERENCES services(id) ON DELETE SET NULL,
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price_cents INTEGER NOT NULL DEFAULT 0 CHECK (unit_price_cents >= 0),
  discount_percent NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100),
  total_cents INTEGER NOT NULL DEFAULT 0 CHECK (total_cents >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  sessions_count INTEGER NOT NULL CHECK (sessions_count > 0),
  appointments_per_month INTEGER NOT NULL DEFAULT 4 CHECK (appointments_per_month > 0),
  discount_percent NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100),
  price_cents INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS package_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id UUID NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
  service_id UUID REFERENCES services(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (package_id, service_id)
);

CREATE TABLE IF NOT EXISTS customer_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID NOT NULL REFERENCES tutors(id) ON DELETE CASCADE,
  pet_id UUID REFERENCES pets(id) ON DELETE SET NULL,
  package_id UUID NOT NULL REFERENCES packages(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'active',
  starts_on DATE NOT NULL DEFAULT CURRENT_DATE,
  ends_on DATE,
  total_sessions INTEGER NOT NULL CHECK (total_sessions > 0),
  used_sessions INTEGER NOT NULL DEFAULT 0 CHECK (used_sessions >= 0),
  amount_cents INTEGER NOT NULL DEFAULT 0 CHECK (amount_cents >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);


ALTER TABLE customer_packages ADD COLUMN IF NOT EXISTS next_session_number INTEGER NOT NULL DEFAULT 1;
ALTER TABLE customer_packages ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE customer_packages ADD COLUMN IF NOT EXISTS recurrence_rule JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID NOT NULL REFERENCES tutors(id) ON DELETE CASCADE,
  pet_id UUID REFERENCES pets(id) ON DELETE SET NULL,
  package_id UUID REFERENCES packages(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  recurrence TEXT NOT NULL DEFAULT 'monthly',
  amount_cents INTEGER NOT NULL DEFAULT 0 CHECK (amount_cents >= 0),
  starts_on DATE NOT NULL DEFAULT CURRENT_DATE,
  next_billing_on DATE,
  payment_method TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS payment_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS sort_order INTEGER NOT NULL DEFAULT 0;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS payment_statuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT NOT NULL DEFAULT '#00A9B7',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS financial_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  customer_package_id UUID REFERENCES customer_packages(id) ON DELETE SET NULL,
  tutor_id UUID REFERENCES tutors(id) ON DELETE SET NULL,
  type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
  due_date DATE,
  paid_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  financial_transaction_id UUID REFERENCES financial_transactions(id) ON DELETE SET NULL,
  payment_method_id UUID REFERENCES payment_methods(id) ON DELETE SET NULL,
  amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
  paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  external_reference TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  payment_id UUID REFERENCES payments(id) ON DELETE SET NULL,
  public_token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
  document_number TEXT UNIQUE,
  subtotal_cents INTEGER NOT NULL DEFAULT 0,
  discount_cents INTEGER NOT NULL DEFAULT 0,
  total_cents INTEGER NOT NULL DEFAULT 0,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS crm_leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tutor_id UUID REFERENCES tutors(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  whatsapp TEXT,
  email TEXT,
  stage TEXT NOT NULL DEFAULT 'lead_entrou',
  source TEXT NOT NULL DEFAULT 'manual',
  last_contact_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS crm_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES crm_leads(id) ON DELETE CASCADE,
  tutor_id UUID REFERENCES tutors(id) ON DELETE SET NULL,
  channel TEXT NOT NULL DEFAULT 'whatsapp',
  direction TEXT NOT NULL DEFAULT 'outbound',
  subject TEXT,
  message TEXT NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL UNIQUE,
  description TEXT,
  starts_on DATE,
  ends_on DATE,
  probability_weight INTEGER NOT NULL DEFAULT 1 CHECK (probability_weight > 0),
  estimated_cost_cents INTEGER NOT NULL DEFAULT 0 CHECK (estimated_cost_cents >= 0),
  status TEXT NOT NULL DEFAULT 'active',
  ai_report JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS gift_spins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  gift_id UUID REFERENCES gifts(id) ON DELETE SET NULL,
  tutor_id UUID REFERENCES tutors(id) ON DELETE SET NULL,
  pet_id UUID REFERENCES pets(id) ON DELETE SET NULL,
  result_title TEXT NOT NULL,
  spin_context JSONB NOT NULL DEFAULT '{}'::jsonb,
  spun_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS website_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS instagram_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS facebook_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS tiktok_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS google_business_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS maps_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS social_links JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS seo_title TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS seo_description TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS seo_keywords TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS seo_image_url TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS seo_settings JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS landing_headline TEXT;
ALTER TABLE business_settings ADD COLUMN IF NOT EXISTS landing_subheadline TEXT;

CREATE TABLE IF NOT EXISTS pet_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pet_sizes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  min_weight_kg NUMERIC(6,2),
  max_weight_kg NUMERIC(6,2),
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pet_breeds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_type_id UUID REFERENCES pet_types(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  suggested_size_code TEXT REFERENCES pet_sizes(code) ON DELETE SET NULL,
  coat_type TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (pet_type_id, name)
);

CREATE INDEX IF NOT EXISTS idx_tutors_whatsapp ON tutors (whatsapp);
CREATE INDEX IF NOT EXISTS idx_tutors_name ON tutors (name);
CREATE INDEX IF NOT EXISTS idx_pets_tutor ON pets (tutor_id);
CREATE INDEX IF NOT EXISTS idx_client_accounts_whatsapp ON client_accounts (whatsapp);
CREATE INDEX IF NOT EXISTS idx_client_accounts_tutor ON client_accounts (tutor_id);
CREATE INDEX IF NOT EXISTS idx_services_active ON services (is_active);

ALTER TABLE service_categories ADD COLUMN IF NOT EXISTS pet_type_code TEXT REFERENCES pet_types(code) ON DELETE SET NULL;
ALTER TABLE service_categories ADD COLUMN IF NOT EXISTS pet_size_code TEXT REFERENCES pet_sizes(code) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_service_categories_pet_filters ON service_categories (pet_type_code, pet_size_code);
CREATE INDEX IF NOT EXISTS idx_service_categories_active ON service_categories (is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_appointment_statuses_active ON appointment_statuses (is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_business_hours_weekday ON business_hours (weekday);
CREATE INDEX IF NOT EXISTS idx_time_slot_capacities_weekday_time ON time_slot_capacities (weekday, slot_time);
ALTER TABLE tutors ADD COLUMN IF NOT EXISTS photo_url TEXT;
ALTER TABLE pets ADD COLUMN IF NOT EXISTS photo_url TEXT;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'pending';
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS payment_method_id UUID REFERENCES payment_methods(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS system_notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL DEFAULT 'info',
  priority TEXT NOT NULL DEFAULT 'medium',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  module TEXT NOT NULL DEFAULT 'dashboard',
  action_url TEXT,
  entity_type TEXT,
  entity_id UUID,
  source_key TEXT UNIQUE,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_system_notifications_read ON system_notifications (is_read, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_system_notifications_module ON system_notifications (module, created_at DESC) WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_appointments_starts_at ON appointments (starts_at);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments (status);
CREATE INDEX IF NOT EXISTS idx_customer_packages_status ON customer_packages (status, tutor_id, pet_id);
CREATE INDEX IF NOT EXISTS idx_package_items_package ON package_items (package_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions (status, tutor_id, next_billing_on);
CREATE INDEX IF NOT EXISTS idx_financial_status ON financial_transactions (status);
CREATE INDEX IF NOT EXISTS idx_gifts_status_dates ON gifts (status, starts_on, ends_on);

DO $$
DECLARE
  table_name_text TEXT;
BEGIN
  FOREACH table_name_text IN ARRAY ARRAY[
    'users','business_settings','collaborators','service_categories','services','tutors','pets','client_accounts',
    'business_hours','time_slot_capacities','appointment_statuses','appointments','appointment_items','packages','package_items',
    'customer_packages','subscriptions','payment_methods','payment_statuses','financial_transactions','payments','receipts','crm_leads',
    'crm_interactions','gifts','settings','pet_types','pet_sizes','pet_breeds','system_notifications'
  ]
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_%I_updated_at ON %I', table_name_text, table_name_text);
    EXECUTE format('CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION set_updated_at()', table_name_text, table_name_text);
  END LOOP;
END $$;
`;

async function main() {
  console.log('[db:migrate] PetFunny OS v0.9 - validando schema com pacotes, sessões e assinaturas.');
  console.log(`[db:migrate] ambiente=${env.nodeEnv} appMode=${env.appMode}`);

  if (!env.databaseUrl) {
    throw new Error('DATABASE_URL não configurada. Crie backend/.env a partir de backend/.env.example antes de rodar npm run db:migrate.');
  }

  await query('BEGIN');
  try {
    await query(ddl);
    await query(`
      INSERT INTO business_settings (business_name, whatsapp, address_city, address_state, seo_title, seo_description, seo_keywords, landing_headline, landing_subheadline)
      SELECT $1::text, $2::text, $3::text, $4::text,
             'PetFunny - Banho e Tosa em Ribeirão Preto'::text,
             'Banho e tosa com carinho, agenda prática, aplicativo do cliente e atendimento pelo WhatsApp em Ribeirão Preto.'::text,
             'banho e tosa Ribeirão Preto, pet shop Ribeirão Preto, PetFunny, banho cachorro, tosa cachorro'::text,
             'O cuidado do seu pet dentro do PetFunny.'::text,
             'Agende banho e tosa, acompanhe histórico e receba novidades pelo aplicativo do cliente.'::text
      WHERE NOT EXISTS (SELECT 1 FROM business_settings)
    `, [env.petfunnyName, env.petfunnyWhatsapp, env.petfunnyCity, env.petfunnyState]);

    await query(`
      INSERT INTO settings (key, value)
      VALUES
        ('app.mode', jsonb_build_object('value', $1::text, 'tenant', false)),
        ('app.identity', jsonb_build_object('name', $2::text, 'city', $3::text, 'state', $4::text, 'whatsapp', $5::text))
      ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
    `, [env.appMode, env.petfunnyName, env.petfunnyCity, env.petfunnyState, env.petfunnyWhatsapp]);

    await query(`
      INSERT INTO appointment_statuses (code, name, description, color, sort_order, is_active, is_final, blocks_slot)
      VALUES
        ('agendado', 'Agendado', 'Atendimento criado e aguardando confirmação.', '#5b7cfa', 1, TRUE, FALSE, TRUE),
        ('confirmado', 'Confirmado', 'Atendimento confirmado com o tutor.', '#00A9B7', 2, TRUE, FALSE, TRUE),
        ('em_atendimento', 'Em atendimento', 'Pet já está em atendimento.', '#f59e0b', 3, TRUE, FALSE, TRUE),
        ('finalizado', 'Finalizado', 'Atendimento concluído.', '#22c55e', 4, TRUE, TRUE, FALSE),
        ('cancelado', 'Cancelado', 'Atendimento cancelado.', '#ef4444', 5, TRUE, TRUE, FALSE),
        ('nao_compareceu', 'Não compareceu', 'Tutor/pet não compareceu ao horário.', '#64748b', 6, TRUE, TRUE, FALSE)
      ON CONFLICT (code) DO UPDATE
      SET name = EXCLUDED.name,
          description = EXCLUDED.description,
          color = EXCLUDED.color,
          sort_order = EXCLUDED.sort_order,
          is_active = TRUE,
          is_final = EXCLUDED.is_final,
          blocks_slot = EXCLUDED.blocks_slot,
          deleted_at = NULL,
          updated_at = NOW()
    `);

    await query('COMMIT');
    console.log('[db:migrate] concluído com sucesso. Tabelas exclusivas PetFunny criadas/validadas.');
  } catch (error) {
    await query('ROLLBACK');
    throw error;
  }
}

main()
  .catch((error) => {
    console.error('[db:migrate] erro:', error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await closePool();
  });
