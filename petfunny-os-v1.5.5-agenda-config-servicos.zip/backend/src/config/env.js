import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const backendRoot = path.resolve(__dirname, '../..');

const envPath = path.resolve(backendRoot, '.env');
let loadedEnvFile = '';

if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath, override: false });
  loadedEnvFile = envPath;
} else {
  dotenv.config({ override: false });
}

export const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT || 3000),
  databaseUrl: String(process.env.DATABASE_URL || '').trim(),
  jwtSecret: String(process.env.JWT_SECRET || 'petfunny-os-dev-secret').trim(),
  jwtExpiresIn: String(process.env.JWT_EXPIRES_IN || '7d').trim(),
  appName: String(process.env.APP_NAME || 'PetFunny OS').trim(),
  appMode: String(process.env.APP_MODE || 'petfunny_single').trim(),
  appUrl: String(process.env.APP_URL || `http://localhost:${process.env.PORT || 3000}`).trim(),
  petfunnyName: String(process.env.PETFUNNY_NAME || 'PetFunny - Banho e Tosa').trim(),
  petfunnyWhatsapp: String(process.env.PETFUNNY_WHATSAPP || '5516981535338').trim(),
  petfunnyCity: String(process.env.PETFUNNY_CITY || 'Ribeirão Preto').trim(),
  petfunnyState: String(process.env.PETFUNNY_STATE || 'SP').trim(),
  openaiApiKey: String(process.env.OPENAI_API_KEY || '').trim(),
  openaiModel: String(process.env.OPENAI_MODEL || 'gpt-4.1-mini').trim(),
  loadedEnvFile
};
